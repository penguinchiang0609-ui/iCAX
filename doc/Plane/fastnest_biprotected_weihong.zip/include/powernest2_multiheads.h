/**
 * @file
 * @author Alma
 * @brief API enabling and controlling Powernest multi-heads capabilities
 */

#ifndef POWERNEST2_MULTIHEADS_H_
#define POWERNEST2_MULTIHEADS_H_

#include "powernest2.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @defgroup MultiHeads Multi-Heads Cutting
     * @brief Some machines can cut many parts simultaneously, using multiple X-aligned cutting heads
     *
     * This is used to reduce the cutting time when a lot of identical parts are present.
     *
     * @{
     */

    /*************************************************************
                        MACHINE CONFIGURATION
    *************************************************************/

    /**
     * @brief Set the maximum number of concurrent cutting heads
     *
     * Setting the heads number here does not activates all heads at all times.
     * On a multi-heads machine, cutting with a lot of heads sometimes
     * degrades too much the nesting and wastes too much material.
     * Powernest2 computes automatically what is more profitable.
     *
     * While nesting usually saves material, cutting with multi-heads saves time.
     * In order to be able to compare and balance those savings, Powernest2 defines
     * costs. The multi-heads time saving is taken into account by differentiating
     * a master-head cutting cost from an parallel head cutting cost. Combined
     * with the definition of a material cost, this allows Powernest2 to balance
     * the activation of heads.

     * @param session the session holding the data
     * @param heads_number maximum number of cutting heads
     *
     * @see PN2_SetCuttingUnitCost() for single or master head cutting cost
     * @see PN2_SetAdditionnalHeadCuttingUnitCost() for additional head cutting cost
     * @see PN2_SetMaterialUnitCost() for the material counterpart
     * @see PN2_SetCuttingHeadsMinimumGap() to set the minimum gap between heads
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetCuttingHeadsNumber(PN2_Session session, int heads_number);

    /**
     * @brief Set the minimum distance between two adjacent cutting heads
     *
     * @param session the session holding the data
     * @param minimum_gap minimum gap between cutting heads
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetCuttingHeadsMinimumGap(PN2_Session session, double minimum_gap);

    /**
    * @brief Set the maximum distance between two adjacent cutting heads
    *
    * Relevant when there is a physical limit on distance between heads,
    * e.g. because of clamping.
    *
    * @param session the session holding the data
    * @param maximum_gap maximum gap between cutting heads
    * @warning if maximum gap value is lower than minimum gap value set by PN2_SetCuttingHeadsMinimumGap, 
    *          maximum gap is set to minimum gap value
    */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetCuttingHeadsMaximumGap(PN2_Session session, double maximum_gap);


    /**
     * @brief Force the use of a specific number of heads
     *
     * In particular, parts which cannot be placed with this constraint will not be placed at all.
     *
     * @param session The session this call should modify.
     * @param heads_number The number of heads to use in [2, max_nb_heads].
     *
     * @see PN2_SetCuttingHeadsNumber()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ForceHeadsNumber(PN2_Session session, int heads_number);


    /*************************************************************
                           COSTS FUNCTIONS
    *************************************************************/

    /**
     * @brief Set the unit cost of cutting with one additional head
     *
     * Set the cost of the cut with one additional head, which is added
     * to standard cost of the cut with one head (PN2_SetCuttingUnitCost())
     * the sum of which is balanced with material consumption cost in
     * order to compute the nesting minimizing the total cost.
     *
     * @param session the current session
     * @param cost the cost for cutting a distance of "1" with additional head
     *
     * @return error code, 0 if there was no error
     *
     * @warning The cost must be greater than or equal to 0
     * @note The cutting cost should also take the lead-in lead-out cost in consideration.
     * @see PN2_SetCuttingUnitCost() in powernest2_objective.h for the cutting cost of master head
     * @see PN2_SetMaterialUnitCost() in powernest2_objective.h for the material counterpart
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetAdditionnalHeadCuttingUnitCost(PN2_Session session, double cost);


    /*************************************************************
                       RESULT INTERPRETATION
    *************************************************************/

    /**
     * @brief Return the number of cutting heads activated when cutting a given part
     *
     * When multiple parts are cut at the same time with a multiple heads configuration,
     * all parts appear in the result, each with its position. Please note that there is 
     * no "master part" in Powernest in order to support any type of master part definition.
     * In order to know if a part is cut in multiheads, one needs to call this function 
     * and check if the \p heads_number is greater than one. 
     * 
     * @param session            the current session
     * @param result             the nesting result where the part is nested
     * @param part               the part for which we want to know the number of heads activated
     * @param[out] heads_number  number of activated heads activated cutting this part. Set to 1 if no multi-heads.
     * @return                   error code, 0 if there was no error.
     *
     * @see  PN2_GetPartMultipleHeadsLinkedPart() to identify all parts cut together with multiple heads.
     *       Using this function and knowing parts positions, one can compute the heads spacing.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetPartMultipleHeadsNumber(PN2_Session session, PN2_Result result, PN2_Part part, int * heads_number);

    /**
     * @brief Return one of the part cut at the same time than a given part in multiple heads configuration
     *
     * When multiple parts are cut at the same time with a multiple heads configuration, one
     * can identify which parts are cut together using this function. 
     * 
     * @param session the current session
     * @param result  the nesting result where the part is nested
     * @param part    the part for which we want to identify a linked part
     * @param index   the index of the linked part. Must be between 0 and heads-number - 1
     *                (see PN2_GetPartMultipleHeadsNumber). The given part is included in
     *                the sisters parts, meaning that there is one index which will set 
     *                \p linked_part to \p part. Parts are sorted by ascending y coordinates,
     *                meaning that a part of greater index will have greater y coordinate.
     * @param[out] linked_part  index-nth part cut at the same time than given part
     * @return        error code, 0 if there was no error.
     *
     * @see PN2_GetPartMultipleHeadsNumber() to get the max index of a linked part
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetPartMultipleHeadsLinkedPart(PN2_Session session, PN2_Result result, PN2_Part part, int index, PN2_Part * linked_part);

    /// @}

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
