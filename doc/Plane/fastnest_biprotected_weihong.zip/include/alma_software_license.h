/**
 * @brief API for software license handling (registration/installation/unregistration/...).
 * 
 * @see @ref AslLib page for a general overview of the ASL library.
 * @addtogroup AslAPI
 */
/**
 * @note The following terms are formally defined in the \ref Glossary below:
 *   - Registration, installation, unregistration, reinstallation, update,
 *   - License, installed_license and license_key,
 *   - License state.
 * 
 * The alma_software_license.h header provides the functions one can use to register, install, unregister
 * (among other possible operations) a license for one of Alma's libraries, such as Powernest2.
 * In order to use Powernest2 on a computer, one must first install a license on this computer.
 * Once installed, the license_key file must be given to Powernest2, using the @ref Pn2LicenseAPI.
 * 
 * @attention The first thing to do on any computer that may receive a license for one or several of Alma's libraries now or in the future is to initialize the 
 * software protection context with ASL_InitializeLicenseContext(). It must only be done once in the lifetime of the computer, with admin privileges.
 * 
 * @subsection QSI Quick Start instructions for registering, installing or unregistering a license:
 *
 * In the instructions below, the following convention is used:
 * - @: Operations that require an internet connection.
 * - C: Operations that must be done on the computer that uses Powernest2.
 * 
 * When one has completed an order for one or several licenses, one will receive 1 NDV file per license ordered.
 * The NDV file roughly represents the unique ID of the license. The registration and installation process is then as follows:
 *   1. (C)  Generate a machine fingerprint file with ASL_GenerateMachineFingerprint().
 *   2. (@)  Register the NDV file with the machine fingerprint file with ASL_RegisterLicense().
 *   3. (@)  Download the installable_license file with ASL_DownloadInstallableLicense().
 *   4. (C)  Install the license with ASL_InstallLicense_Standalone(). It will generate the license_key file.
 *
 * The license is now installed. The file that has been generated at step 4. contains the license_key for this computer.
 * It has to be passed to Powernest2 using PN2_SetLicensePath().
 * 
 * If one wants to change the computer that is allowed to use a license, one must unregister the license from the computer
 * that will no more use it, and register and install it on the new one. The unregistration process is as follows:
 * - I.   (@) Initiate the unregistration process for an NDV license file and download an unregistration request file with ASL_InitiateUnregistrationProcess().
 * - II.  (C) Apply the unregistration request with ASL_ApplyUnregistrationRequest_Standalone(). It will generate an unregistration confirmation file.
 * - III. (@) Upload the unregistration confirmation file with ASL_UploadUnregistrationConfirmation().
 *
 * After step III. is complete, the license represented by the NDV file is now available again for registration and installation.
 * One can just go through steps 1. to 4. to register and install the license on another computer.
 * 
 * @note **What if I do not have an internet connection?**\n
 * The software license can be installed on or unregistered from a computer that has no internet connection.
 * To do so, one must transfer the files generated on steps 1. and II. from the offline computer to a computer that has an internet connection,
 * and transfer the files downloaded on steps 3. and I. from the online computer to the offline computer.
 *
 * 
 * @subsection LC License characteristics
 * 
 * There are two types of licenses: standalone licenses and floating license.
 * 
 * A **standalone license** allows to run Powernest2 on the computer on which the license is installed.
 * 
 * A **floating license** must be installed on a computer (the "server") on which Sentinel RMS License Manager service is running.
 * One floating license allows a specified number of users to run Powernest2 simultaneously. The server will control the number
 * of users running Powernest2 at any time by giving and taking back "tokens". By default, the server owns as many tokens
 * as the allowed number of simultaneous users.
 * Any computer can request a token from the server. If the token has an available token, it will give one token
 * to the computer, and this computer will be allowed to run Powernest2 as long as it owns the token. 
 * When the computer finishes using Powernest2, the token is returned to the server.
 * Thus, the computer that runs Powernest2 does not need any license to be installed on it.
 * Note that the server can run Powernest2 itself just as any other computer, providing that there is an available token.
 * 
 * The process described in the section above (\ref QSI "Quick Start instructions") is specific to standalone licenses.
 * Floating licenses may be registered, installed and unregistered in a similar way, with the following changes:
 * - Registration, installation and unregistration must take place on the server.
 * - In step 4., ASL_InstallLicense_Floating() should be used instead of ASL_InstallLicense_Standalone().
 * - In step II., ASL_ApplyUnregistrationRequest_Floating() should be used instead of ASL_ApplyUnregistrationRequest_Standalone().
 * - More generally, some functions are suffixed with "_Standalone" or "_Floating". Those functions must be used accordingly to the license type.
 * - PN2_SetFloatingLicenseServerInfo() should be used when running Powernest2 instead of PN2_SetLicensePath().
 * 
 * 
 * Regarding the temporal validity of the license, there are three possibilities:
 * - i)    **License limited by a number of days:** This license will be valid for a predefined number of days after its registration.
 * - ii)   **License with an expiration date:** This license will be valid up to its expiration date, independently of when it is registered.
 * - iii)  **Unlimited license:** Once installed, this license will be valid indefinitely.
 *
 * Please observe that licenses limited by a number of days (case 'i)') cannot be unregistered, and therefore cannot be
 * registered and installed later on another computer.
 * 
 * 
 * @subsection Glossary Glossary and concepts:
 *
 * - License, NDV file, installable_license and license_key:
 *   (the following descriptions hold for standalone licenses, but the concept is similar for floating licenses)
 *     - **License:** A license represents the right to use one or several of Alma's libraries on a computer.
 *       A license is identified by an NDV file, and it may be registered, installed, updated and unregistered.
 *       As long as a license is registered for a computer, it is possible to download an installable_license file
 *       that allows to install this license on this computer.
 *     - **NDV file:** one NDV file allows to identify one specific license.
 *       When communicating with Alma's license server, the NDV file is necessary to identify the license
 *       on which an operation must be performed, or for which information must be retrieved.
 *       An NDV file has no other purpose than identifying the corresponding license:
 *          * it does not contain any information about the license, such as its expiration date;
 *          * and it is neither an installable_license file nor a license_key file,
 *            so it cannot be used in place of such files in order to install the license or to run Powernest2.
 *     - **Installable_license:** in order to install a license on the computer for which the license is registered,
 *       one must first download the installable_license file corresponding to this license and this computer.
 *       The installable_license file can then be used to perform the installation, which will generate a license_key file.
 *     - **License_key:** In order to unlock Powernest2, one must give it the path of a license_key file.
 *       Powernest2 will then be able to check that the license_key file corresponds to a valid license.
 *
 * - **Registration:** the process of linking one license to a specific computer.
 *   As long as one license is registered for a computer, this license may be installed on this computer.
 *
 * - **Installation:** the process of making the license actually usable for the computer for which it is registered.
 *   The installation needs an installable_license file, and it generates a license_key file.
 *
 * - **Unregistration:** the process of removing the rights conferred by the license from the computer on which it was installed,
 *   and of detaching the license from the computer to which it was linked.
 *   The unregistration may be performed on any registered license, even if the license has only been registered,
 *   without having been actually installed.
 *
 * - **Reinstallation:** the process of unregistering a license (thus making it available again),
 *   and then to register and install the license again. This is needed in somes cases in order to update a license.
 *
 * - **Update:** the process of updating the license_key file when the rights associated with the license have changed.
 *   In order to update a license, it is sometimes sufficient to download the installable_license and install the license again,
 *   or it might be required to reinstall the license (ie. to unregister the license, and then to register and install it).
 *   The license state indicates which of the update procedure must be followed.
 *
 * - **License state:** this is the state of the license as viewed by Alma's server.
 *   The license state indicates if the license is available or registered for some computer, if an update is available,
 *   if some unregistration process has been initiated or if the license is expired.\n
 *   Note: the license state cannot take into account the operations that are performed locally
 *   (ie. by functions that do not require an internet connection).
 *   Thus, there is no state corresponding to the fact that a registered license has been successfully installed.
 *   As soon as a license might have been installed on a computer (ie. if the license has been registered)
 *   the state will be ::ASL_LICENSE_REGISTERED, irrespectively of the actual installation of the license.\n
 *   Some utility functions may be used to check:
 *     - That there is a valid license_key file, meaning that the license has actually been installed on the computer.
 *     - And that the license_key grants the same rights (expiration date in particular) as the rights
 *       associated with the license according to Alma's server.
 *       Such comparison may be used to make sure that the license_key file is up-to-date.
 *
 * @note File paths are expected to be encoded in UTF-8.
 * @addtogroup AslUM
 */
/**
 * @addtogroup AslAPI 
 * @{
 */

/**
 * @file
 * @brief API for software license handling (registration/installation/unregistration/...).
 */

#ifndef ALMA_SOFTWARE_LICENSE_H
#define ALMA_SOFTWARE_LICENSE_H

/**
 * @def ASL_EXPORTS
 * @brief Internal directives to expose the API through a shared library
 */

/**
 * @def ASL_API
 * @brief The calling convention to use
 *
 * It primarily matters when calling the library API "by hand", typicially when using a
 * programing language which is not C/C++. Otherwise the linker will take care of those
 * details.
 *
 * @see https://en.wikipedia.org/wiki/X86_calling_conventions
 */

#ifdef _WIN32
#define ASL_EXPORTS 
#define ASL_API __stdcall
#else
#define ASL_EXPORTS __attribute__ ((visibility ("default")))
#define ASL_API
#endif


/**
 * @brief Bool type for this API.
 *
 * 0 means false.
 * A non-zero value means true.
 */
typedef int ASL_Bool;

/**
 * @brief Error type for this API.
 *
 * 0 means "no error": the function returning the ASL_ErrorCode behaved correctly.
 * Any non-zero value means that the function has failed. If so, an error message
 * may be retrieved using ASL_GetErrorMessage().
 */
typedef int ASL_ErrorCode;

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Logs all API calls in a file so that Alma support may investigate any problem.
     *
     * In order to create an exhaustive log file, please call this function before any other.
     *
     * @param file File path in which calls will be logged.
     *        If the file already exists, it will be overwritten.
     *        NULL can be used to stop the logging and close the file.
     */
    ASL_EXPORTS void ASL_API ASL_LogFunctionCalls(const char * file);

    /**
     * @brief Error management utility: retrieve a descriptive string associated to an error code.
     *
     * Any software license related function that may fail returns an integer ::ASL_ErrorCode.
     * If the returned code is 0, then the function has behaved properly.
     * If it has failed, then a non-zero code has been returned.
     * ASL_GetErrorMessage() allows to get a error message corresponding
     * to the error code returned by this function.
     * 
     * @param error_code the error code that has been returned by a function.
     * @return Message explaining the error. If error_code is not valid or is 0, returns NULL.
     */
    ASL_EXPORTS const char * ASL_API ASL_GetErrorMessage(ASL_ErrorCode error_code);

    /**
     * @brief Initializes the software license context on the computer.
     *
     * One must have admin privileges to run this function. It initializes private structures and documents for software license handling.
     * This function must be called before calling any other function of this API.
     * It is enough to call it once in the lifetime of any computer.
     *
     * This function helps integrators of Powernest2 to keep the need for admin privileges to the bare minimum.
     * Generally, this function will be called when installing the software in which Powernest2 is embeded.
     * Thus, if the user only gets a license for Powernest2 later on, they will be able to register and install it,
     * as the requirement that ASL_InitializeLicenseContext() shall have already been called will be met.
     *
     * @pre One must have admin privileges to run this function.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_InitializeLicenseContext();

    /**
     * @brief Sets the timeout for the functions that require an internet connection.
     *
     * If not used, the default value is 30 seconds. If the value is negative, the default value is set instead.
     *
     * @param timeout_in_seconds The timeout in seconds for the HTTP requests.
     */
    ASL_EXPORTS void ASL_API ASL_SetLicenseFunctionsTimeout(int timeout_in_seconds);

    /**
     * @brief Sets the proxy information for the functions that require an internet connection.
     *
     * If not used, an automatic detection of the proxy information from the computer's settings will be attempted.
     *
     * @param proxy_address The address of the proxy.
     * @param server_port The port of the proxy.
     */
    ASL_EXPORTS void ASL_API ASL_SetLicenseFunctionsProxy(const char* proxy_address, int server_port);

    /**
     * @brief Resets the proxy information for the functions that require an internet connection.
     *
     * If ASL_SetLicenseFunctionsProxy() has been used before, this function reset this information to the default
     * one, with automatic detection of the proxy information.
     */
    ASL_EXPORTS void ASL_API ASL_ResetLicenseFunctionsProxy();

    /**
     * @brief License states
     */
    typedef enum
    {
        ASL_LICENSE_AVAILABLE = 0,            ///< The license is available.
        ASL_LICENSE_REGISTERED = 1,           ///< The license is currently linked to some computer. It may be installed on this computer.
        ASL_LICENSE_UPDATE_AVAILABLE = 2,     ///< An update is available (for instance if the validity of the license has been extended).
        ASL_LICENSE_MUST_BE_REINSTALLED = 3,  ///< An update is available but the license needs to be unregistered, then registered and installed again to be updated.
        ASL_LICENSE_BEING_UNREGISTERED = 4,   ///< An unregistration request has been issued for this license, the unregistration shall now be finalized.
        ASL_LICENSE_EXPIRED = 5               ///< The license is expired.
    } ASL_LICENSE_STATE;

    /**
     * @brief Gets the current state of the license.
     * 
     * This is the state of the license according to our license server.
     *
     * The base state of a license is ::ASL_LICENSE_AVAILABLE.
     * After ASL_RegisterLicense() is called, the state changes to ::ASL_LICENSE_REGISTERED.
     * As long as the state of a license in ASL_LICENSE_REGISTERED, the license may be installed on the computer for which it is registered.
     * Then, if ASL_InitiateUnregistrationProcess() is called, the state changes to ::ASL_LICENSE_BEING_UNREGISTERED.
     * It goes back to ASL_LICENSE_AVAILABLE after a successful call to ASL_UploadUnregistrationConfirmation().
     * 
     * The state of a license may also be ::ASL_LICENSE_UPDATE_AVAILABLE and ::ASL_LICENSE_MUST_BE_REINSTALLED if an update of the license is available,
     * for instance if its validity has been extended or if a new product or functionality has been added to a license. \n 
     * If the state is ASL_LICENSE_UPDATE_AVAILABLE, then one must call ASL_DownloadInstallableLicense() and ASL_InstallLicense_Standalone() to update the license. \n 
     * If the state is ASL_LICENSE_MUST_BE_REINSTALLED, then it is required to unregister the license and then to register and install it again in order to update the license.
     * 
     * More formally, the state of a license may change when the license expires or is modified by Alma, or when one of the following functions is successfully called:
     *   - ASL_RegisterLicense(): changes state from ASL_LICENSE_AVAILABLE to ASL_LICENSE_REGISTERED,
     *   - ASL_DownloadInstallableLicense(): changes state from ASL_LICENSE_UPDATE_AVAILABLE to ASL_LICENSE_REGISTERED,
     *   - ASL_InitiateUnregistrationProcess(): changes state from ASL_LICENSE_REGISTERED, ASL_LICENSE_UPDATE_AVAILABLE or ASL_LICENSE_MUST_BE_REINSTALLED to ASL_LICENSE_BEING_UNREGISTERED,
     *   - ASL_UploadUnregistrationConfirmation(): changes state from ASL_LICENSE_BEING_UNREGISTERED to ASL_LICENSE_AVAILABLE.
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param[out] license_out_state location where to store the state of the license. 
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_GetLicenseState(const char * ndv_filepath,
                                                          ASL_LICENSE_STATE * license_out_state);

    /**
     * @brief Tells if the license is registered for the machine with the given fingerprint.
     *
     * A license (represented by a NDV file) becomes registered for a machine as soon as ASL_RegisterLicense() is called
     * with the fingerprint of this machine.
     * As long as a license is registered for a machine, it is possible to download an installable_license file
     * with ASL_DownloadInstallableLicense() and to install the license with ASL_InstallLicense_Standalone().
     *
     * This function compares the given machine fingerprint with the one that has been registered
     * on Alma's license server after a call to ASL_RegisterLicense().
     * Generating a machine fingerprint can differ if one has admin privileges or not, or if some piece of hardware is changed.
     * If the machine fingerprint given to this function has been generated differently than during the registration of the license
     * (in particular if the privileges havec changed), then this function might return false,
     * even if the license is expected to be registered for this computer.
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param machine_fingerprint_filepath The path to the file containing information
     *                                     about the computer to which the license is potentially linked.
     * @param[out] is_license_registered_for_machine_out Location where to store the result.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_IsLicenseRegisteredForMachine(const char * ndv_filepath,
                                                                        const char * machine_fingerprint_filepath,
                                                                        ASL_Bool * is_license_registered_for_machine_out);

    /**
     * @brief Gets the expiration date of the license.
     *
     * This is the expiration date according to our license server. The string representation of the date
     * follows the ISO 8601 standard:
     *   - Licenses limited by a number of days: returns a duration string (e.g. "P60D" for "60 days").
     *   - Licenses with an expiration date: returns a date string (e.g. "2020-02-08" for "February 8th 2020").
     *   - Unlimited licenses: returns a date string with value "2500-12-31".
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param[out] expiration_date_out Expiration date.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_GetLicenseExpirationDate(const char * ndv_filepath,
                                                                   char expiration_date_out[64]);

    /**
     * @brief Gets the expiration date of the license_key for a standalone license.
     *
     * This is the expiration date set in the license_key file.
     * If more than one license is present in the license_key file, the latest date is returned.
     * The string representation of the date follows the ISO 8601 standard ("yyyy-mm-dd").
     * If the license_key file contains an unlimited license, the date "2500-12-31" is returned.
     * If the license_key file represents a license limited by a number of days, it returns the
     * end date that has been computed from the installation date.
     *
     * @param license_key_filepath The path to the installed license_key file.
     * @param[out] expiration_date_out Expiration date.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_GetLicenseKeyExpirationDate_Standalone(const char * license_key_filepath,
                                                                                 char expiration_date_out[64]);

    /**
     * @brief Gets the expiration date of an installed floating license.
     *
     * See ASL_GetLicenseKeyExpirationDate_Standalone() description for exhaustive documentation.
     * 
     * @param license_server_address The address of the license server (for instance "localhost" or and IP address)
     * @param license_server_contact_port The port number to contact the Sentinel RMS License Manager service.
     *                                    By default, the port is 5093 but it may be different in some specific cases.
     * @param[out] expiration_date_out Expiration date.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_GetLicenseKeyExpirationDate_Floating(const char * license_server_address,
                                                                               const int license_server_contact_port,
                                                                               char expiration_date_out[64]);

    /**
     * @brief Writes the file containing local computer information, needed to register a software license for a computer.
     *
     * This function creates a file that represent the computer.
     * It must be called on the computer where the license is to be installed.
     *
     * @note The machine fingerprint must be generated in an environment similar to the environment where Powernest2 will be used.
     * In particular, the privileges must be the same when generating the machine fingerprint as when Powernest2 is used.
     * @note In the case where Powernest2 is likely to be used alternately with and without admin privileges,
     * then the fingerprint must be generated *without* admin privileges.
     *
     * @param machine_fingerprint_out_filepath The full path of the resulting machine fingerprint file. 
     *                                         The file extension is up to the user.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_GenerateMachineFingerprint(const char * machine_fingerprint_out_filepath);

    /**
     * @brief Registers a software license for a specific computer.
     *
     * As long as a license is registered for a computer, it is possible to call ASL_DownloadInstallableLicense()
     * to get an installable_license file. Then, in order to have the license_key available, the installable_license
     * needs to be actually installed on the target computer with ASL_InstallLicense_Standalone() or ASL_InstallLicense_Floating().
     *
     * @param machine_fingerprint_filepath The path to the file containing information
     *                                     about the computer where the license is to be installed.
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     *
     * @return An error code, or 0 if there was no error.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     * @note A license that is already registered for a computer cannot be registered nor installed elsewhere.
     *       In order to register or install the license on another computer, one will need to first unregister the license.
     *       To unregister a license, see the following functions: ASL_InitiateUnregistrationProcess(),
     *       ASL_ApplyUnregistrationRequest_Standalone(), ASL_ApplyUnregistrationRequest_Floating() and ASL_UploadUnregistrationConfirmation().
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_RegisterLicense(const char * machine_fingerprint_filepath,
                                                          const char * ndv_filepath);

    /**
     * @brief Downloads the installable_license file for an already registered license.
     *
     * This function belongs to the registration and installation process of a license.
     * It is expected to be called after having called ASL_RegisterLicense() or if the license state is ::ASL_LICENSE_UPDATE_AVAILABLE,
     * and the installable_license file obtained by calling this function is expected to be passed to
     * ASL_InstallLicense_Standalone() or ASL_InstallLicense_Floating().
     * 
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param installable_license_out_filepath The full path of the resulting installable_license file.
     *                                         The file extension is up to the user.
     *
     * @return An error code, or 0 if there was no error.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_DownloadInstallableLicense(const char * ndv_filepath, const char * installable_license_out_filepath);

     /**
      * @brief Checks whether the installable license file is for a standalone or a floating license.
      *
      * This can be used to decide whether ASL_InstallLicense_Standalone() or ASL_InstallLicense_Floating()
      * should be called with it.
      *
      * @param installable_license_filepath The path to the installable license file.
      * @param[out] is_for_standalone Location where to store whether it is for a standalone license or not.
      *
      * @return An error code, or 0 if there was no error.
      */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_InstallableLicenseIsForStandalone(const char * installable_license_filepath,
                                                                            ASL_Bool * is_for_standalone);

     /**
      * @brief Installs a standalone license on a computer. This generates a license_key file.
      *
      * After completing the installation, one can check if the license is properly
      * installed by calling ASL_GetLicenseKeyExpirationDate_Standalone().
      * 
      * It is also advised to check that the license is properly recognized by Powernest2.
      * This may be done by calling the functions from @ref Pn2LicenseAPI :
      * PN2_SetLicensePath() to tell Powernest2 where to look for the license_key file
      * and PN2_CheckLicense() to perform a license validity check.
      * 
      * @param installable_license_filepath The path to the installable_license file.
      * @param license_key_out_filepath The full path of the resulting license_key file.
      *                             The file extension is up to the user.
      * 
      * @pre ASL_InitializeLicenseContext() must have been called before using this function.
      * @return An error code, or 0 if there was no error.
      */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_InstallLicense_Standalone(const char * installable_license_filepath,
                                                                    const char * license_key_out_filepath);

    /**
     * @brief Installs a floating license on a computer (the "server").
     * 
     * After completing the installation, one can check if the license is properly
     * installed by calling ASL_GetLicenseKeyExpirationDate_Floating().
     *
     * It is also advised to check that the license is properly recognized by Powernest2.
     * This may be done by calling the functions from @ref Pn2LicenseAPI :
     * PN2_SetFloatingLicenseServerInfo() to allow Powernest2 to contact the floating license server
     * and PN2_CheckLicense() to perform a license validity check.
     * 
     * @param installable_license_filepath The path to the installable_license file.
     * @param license_server_contact_port  The port number to contact the Sentinel RMS License Manager service.
     *                                     By default, the port is 5093 but it may be different in some specific cases.
     *
     * @pre ASL_InitializeLicenseContext() must have been called before using this function.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_InstallLicense_Floating(const char * installable_license_filepath,
                                                                  const int license_server_contact_port);


    /**
     * @brief Initiates the process of unregistration for the license, and download an unregistration request file.
     *
     * This function will mark the license as being in an unregistration process (state ::ASL_LICENSE_BEING_UNREGISTERED).
     * The unregistration process shall then be completed as soon as possible, by using functions
     * ASL_ApplyUnregistrationRequest_Standalone() or ASL_ApplyUnregistrationRequest_Floating() and ASL_UploadUnregistrationConfirmation().
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param request_out_filepath The full path of the resulting unregistration request file.
     *                             The file extension is up to the user.
     * 
     * @return An error code, or 0 if there was no error.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     * @note This function requires the license to be registered on a computer in order to succeed.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_InitiateUnregistrationProcess(const char * ndv_filepath,
                                                                        const char * request_out_filepath);

     /**
      * @brief Checks whether the unregistration request file is for a standalone or a floating license.
      *
      * This can be used to decide whether ASL_ApplyUnregistrationRequest_Standalone() or
      * ASL_ApplyUnregistrationRequest_Floating() should be called with it.
      *
      * @param unregistration_request_filepath The path to the unregistration request file.
      * @param[out] is_for_standalone Location where to store whether it is for a standalone license or not.
      *
      * @return An error code, or 0 if there was no error.
      */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_UnregistrationRequestIsForStandalone(const char * unregistration_request_filepath,
                                                                               ASL_Bool * is_for_standalone);

    /**
     * @brief Removes the rights conferred by the license from the computer, and generates an unregistration confirmation.
     *
     * This function requires the unregistration request file issued by ASL_InitiateUnregistrationProcess()
     * and it will write an unregistration confirmation file that must be passed to ASL_UploadUnregistrationConfirmation().
     * 
     * This function will remove the rights conferred by the license:
     *    - If the license is installed, it will invalidate the license contained in the license_key file.
     *    - In all cases (ie. if the license has been installed or if it has only been registered),
     *      the installation of the license will be temporarily blocked.
     *      In order to install the license again, it will be necessary to first complete the unregistration process.
     * 
     * Regarding the second parameter (license_key_filepath), the functions must be used as follows:
     *    - If the license is installed, the corresponding license_key filepath must be given to this function.
     *      This will properly remove the data about the license being unregistered from the license_key file.
     *    - If the license has only been registered, or if the license_key file has been lost or corrupted,
     *      then NULL must be given instead for license_key_filepath.
     * 
     * @param unregistration_request_filepath The path to the unregistration request file.
     * @param license_key_filepath The path to the license_key file, or NULL (if not installed or lost).
     * @param unregistration_confirmation_out_filepath The full path of the resulting unregistration confirmation file.
     *                                                 The file extension is up to the user.
     * 
     * @pre ASL_InitializeLicenseContext() must have been called before using this function.
     * @return An error code, or 0 if there was no error.
     * @note If the machine fingerprint file used to install this license had been generated in a context
     *       with admin privileges (when calling ASL_GenerateMachineFingerprint()),
     *       then this function may have some trouble unregistering it without admin privileges.
     *       In such case, it could return an error about the machine information not being the one linked with the license.
     *       If such error happens, and one knows it is the right computer, then 
     *       one can try to run again this function with admin privileges.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_ApplyUnregistrationRequest_Standalone(const char * unregistration_request_filepath, 
                                                                                const char * license_key_filepath,
                                                                                const char * unregistration_confirmation_out_filepath);

    /**
     * @brief Same as ASL_ApplyUnregistrationRequest_Standalone() but for a floating license.
     *
     * See ASL_ApplyUnregistrationRequest_Standalone() description for exhaustive documentation.
     *
     * @param unregistration_request_filepath The path to the unregistration request file.
     * @param license_server_contact_port The port number to contact the Sentinel RMS License Manager service.
     *                                    By default, the port is 5093 but it may be different in some specific cases.
     * @param unregistration_confirmation_out_filepath The full path of the resulting unregistration confirmation file.
     *                                                 The file extension is up to the user.
     *
     * @pre ASL_InitializeLicenseContext() must have been called before using this function.
     * @return An error code, or 0 if there was no error.
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_ApplyUnregistrationRequest_Floating(const char * unregistration_request_filepath,
                                                                              const int license_server_contact_port,
                                                                              const char * unregistration_confirmation_out_filepath);

    /**
     * @brief Uploads the unregistration confirmation in order the actually unregister the license, thus making it available again.
     * 
     * @param unregistration_confirmation_filepath The path to the unregistration confirmation file.
     * @return An error code, or 0 if there was no error.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by ASL_SetLicenseFunctionsTimeout().
     */
    ASL_EXPORTS ASL_ErrorCode ASL_API ASL_UploadUnregistrationConfirmation(const char * unregistration_confirmation_filepath);

/// @}

#ifdef __cplusplus
}

#endif /* __cplusplus */

#endif /* ALMA_SOFTWARE_LICENSE_H */

