/**
 * @file
 * @author Alma
 * @brief Fast, interactive, incremental, semi-manual nesting features
 *
 * Those functions are intended to be used in real-time, such as mouse
 * move event attached to a part.
 * 
 * There are two kind of functions: the one to create/modify/delete an
 * interactive nesting, and the one to query possible positions for a
 * particular part in an existing nesting.
 */

#ifndef POWERNEST2_INTERACTIVE_H_
#define POWERNEST2_INTERACTIVE_H_

#include "powernest2.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief A PN2I_Nesting is a fast incremental data-structure for interactive nesting.
     */ 
    typedef struct PN2I_NestingInternal * PN2I_Nesting;

    /**
     * @brief Creates a new PN2I_Nesting for a particular sheet
     *
     * @param session the session where the PN2I_Nesting belongs to
     * @param sheet the sheet used for this PN2I_Nesting
     *
     * @return a new PN2I_Nesting ready to be used or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     */
    PN2_EXPORTS PN2I_Nesting PN2API PN2I_CreateNesting(PN2_Session session, PN2_Sheet sheet);

    /**
     * @brief Delete an interactive nesting
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2I_DeleteNesting(PN2_Session session, PN2I_Nesting nesting);

    /**
     * @brief Nest a part within an existing interactive nesting
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting in which the part must be nested
     * @param part the part to nest
     * @param orientation the orientation in which the part must be nested
     * @param position the position where the part must be nested
     *
     * @return 0 if there is no error
     *
     * @note There are no checking when using this function, a part
     * can be nested at any place, even if it overlaps with another
     * part, this function will succeed
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2I_NestPart(PN2_Session session, PN2I_Nesting nesting,
                                                   PN2_Part part, PN2_Orientation orientation, PN2_Point position);

    /**
     * @brief Nest many parts within an existing interactive nesting
     *
     * @see PN2I_NestPart()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2I_NestParts(PN2_Session session, PN2I_Nesting nesting,
                                                    const PN2_Part * parts, const PN2_Orientation * ors,
                                                    const PN2_Point * pos, int nb_parts);

    /**
     * @brief Remove a nested part from an interactive nesting
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting from which the part must be removed
     * @param part the part to remove
     *
     * @return 0 if there is no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2I_RemovePart(PN2_Session session, PN2I_Nesting nesting, PN2_Part part);

    /**
     * @brief Remove many nested parts from an interactive nesting
     *
     * @see PN2I_RemovePart()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2I_RemoveParts(PN2_Session session, PN2I_Nesting nesting,
                                                      const PN2_Part * parts, int nb_parts);


    /**
     * @brief Check if a part can be nested at a given position and orientation
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting where to try to nest the part
     * @param part the part to nest
     * @param orientation the orientation in which the part must be nested
     * @param position the position where the part must be nested
     *
     * @return 1 if the part can be nested using this position and
     * orientation on this interactive nesting (ie there is no
     * overlapping), 0 if it cannot, a negative value if an error occurred.
     */
    PN2_EXPORTS PN2_Bool PN2API PN2I_TryNestPart(PN2_Session session, PN2I_Nesting nesting,
                                                 PN2_Part part, PN2_Orientation orientation,
                                                 PN2_Point position);

    /**
     * @brief Check if a part can be nested around a given position using a particular orientation
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting where to try to nest the part
     * @param part the part to nest
     * @param orientation the orientation in which the part must be nested
     * @param position the position close to where the part must be nested
     * @param[out] found_position the first valid position found, if any
     *
     * @return 1 if a valid position was found, 0 if it was not, a negative value if an error occurred.
     */
    PN2_EXPORTS PN2_Bool PN2API PN2I_TryNestPartAround(PN2_Session session, PN2I_Nesting nesting,
                                                       PN2_Part part, PN2_Orientation orientation,
                                                       PN2_Point position, PN2_Point * found_position);

    /**
     * @brief Check if a part can be squeezed in a nesting in a given
     * direction starting from a given position
     *
     * The start position must be valid
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting where to try to squeeze the part
     * @param part the part to squeeze
     * @param orientation the orientation in which the part must be nested
     * @param starting_position the initial position of the part to squeeze
     * @param objective_position the position where the part must be heading during the squeeze process
     * @param slide_on_contacts if 0 the squeezing stops as soon as a contact is found, if 1, the part is allowed to slide along others parts
     * @param[out] found_position the first valid position found, if any
     *
     * @return 1 if a valid position was found, 0 if it was not, a negative value if an error occurred.
     */
    PN2_EXPORTS PN2_Bool PN2API PN2I_TrySqueezePart(PN2_Session session, PN2I_Nesting nesting,
                                                    PN2_Part part,  PN2_Orientation orientation,
                                                    PN2_Point starting_position,
                                                    PN2_Point objective_position,
                                                    PN2_Bool slide_on_contacts,
                                                    PN2_Point * found_position);

    /**
     * @brief Draw a SVG image of an interactive nesting
     *
     * @param session the session owning the data currently used
     * @param nesting the interactive nesting to draw
     * @param filename the path where to draw the SVG file
     * 
     * @warning for debugging purpose only
     */
    PN2_EXPORTS PN2_Bool PN2API PN2I_DrawSvg(PN2_Session session, PN2I_Nesting nesting, const char * filename);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
