/**
 * @file
 * @author Alma
 * @brief API enabling and controlling Powernest L Offcut capabilities
 */

#ifndef POWERNEST2_L_OFFCUT_H_
#define POWERNEST2_L_OFFCUT_H_

#include "powernest2.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


    /**
     * @addtogroup Objectives
     * @{
     */

    /**
     * @brief Enables L Offcut retrieval
     *
     * This only changes the admissible geometry of an offcut, allowing Powernest to favour
     * a nesting with a large L-offcut instead of minimizing the abscissa of the rightmost part.
     * The considered "L" arms are at the top and right edge of a sheet and it must match the
     * sheet height.
     * The offcut shape is used to nest parts in order to maximize its surface, but its dimension
     * and position may not be queried.
     * The L-offcut is only retrieved on the last sheet of a PN2_MultiNest optimization.
     * This means that, as in the usual case, Powernest will not try to maximize the reusability of
     * the offcuts of all used sheets.
     *
     * @param session current session
     * @param activate true to activate L offcut and false to activate front offcut
     *
     * @return 0 in case of success, an error code otherwise.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ActivateLOffcut(PN2_Session session, PN2_Bool activate);

    /**
     * @brief Set the minimum height of an "arm" of a L-offcut
     *
     * Any part of the L-offcut that is thinner than this parameter will not be considered as reusable.
     *
     * This function should only be used if L-offcut optimization is activated (see PN2_ActivateLOffcut()).
     * Default value is 0, meaning that there is no constraint on the L geometry.
     *
     * @param session current session
     * @param minimum_usable_height value of the minimal height considered
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetLOffcutMinimumUsableHeight(PN2_Session session, double minimum_usable_height);


/// @}


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* POWERNEST2_L_OFFCUT_H_ */
