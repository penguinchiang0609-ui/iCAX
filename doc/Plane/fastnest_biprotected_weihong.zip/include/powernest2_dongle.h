/**
 * @file
 * @author Alma
 * @brief Provides dongle protection management
 */


#ifndef POWERNEST2_DONGLE_H_
#define POWERNEST2_DONGLE_H_

#include "powernest2.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Set the necessary information about the Sentinel protection to check the license.
     *        Powernest2 license is 8 bytes long.
     *
     *      This function must be used only if Powernest is not protected with Sentinel dongles provided by Alma
     *
     * @param vendor_code code provided by Sentinel to each of its client needed to open a session on a dongle
     * @param vendor_code_size the size of vendor_code
     * @param offset the position in the dongle where Powernest2 license is written
     * @param feature_id the feature id to use to connect to the dongle
     */ 
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSentinelDongleInfos(const unsigned char * vendor_code, int vendor_code_size, unsigned int offset, unsigned int feature_id);

     /**
     * @brief Get the id of the dongle on which the protection is checked
     *
     * @param[out] dongle_id the id of the dongle checked
     * @return 0 if reading succeeded, an error code otherwise.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetDongleId(unsigned int * dongle_id);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
