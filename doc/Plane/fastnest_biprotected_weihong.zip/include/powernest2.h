/**
 * @author Alma
 * @brief Automatic 2D Nesting Library
 */

/**
 * @file
 * @brief API of automatic nesting library Powernest2.
 *
 */

#ifndef POWERNEST2_H_
#define POWERNEST2_H_



/**
 * @def PN2_EXPORTS
 * @brief Internal directives to expose the API through a shared library
 */

/**
 * @def PN2API
 * @brief The calling convention to use
 * 
 * It primarily matters when calling the library API "by hand", typically when using a
 * programming language which is not C/C++. Otherwise the linker will take care of those
 * details.
 * 
 * @see https://en.wikipedia.org/wiki/X86_calling_conventions
 *
 * @warning Under Windows, functions use \c __stdcall while callbacks use \c __cdecl
 */

#ifdef _WIN32
#define PN2_EXPORTS 
#define PN2API __stdcall
#else
#define PN2_EXPORTS __attribute__ ((visibility ("default")))
#define PN2API
#endif

/** @brief Silence warnings when possible */
#define PN2_MAYBE_UNUSED
#if defined(__cplusplus)
#if __cplusplus  >= 201703L
#undef PN2_MAYBE_UNUSED
#define PN2_MAYBE_UNUSED [[maybe_unused]]
#endif
#endif

 /**
  * @brief Powernest bool type. 
  *
  * 0 means false.
  * A positive value means true.
  * A negative value refers to an error code (see PN2_ErrorCode).
  */
typedef int PN2_Bool;

/**
 * @brief Powernest error type
 *
 * Actual errors are characterized with negative values
 */
typedef int PN2_ErrorCode;

/**
 * @brief 2D point described by its cartesian coordinates
 */
typedef struct tagPN2_Point
{
    double x, ///< Abscissa 
           y; ///< Ordinate
}
PN2_Point;


/**
 * @defgroup Orientation Orientation
 * @brief All-purpose type, used throughout the Powernest API
 *
 */
/**
 * @brief An angle interval and a a flip used to describre orientations constraints and
 * 2D transfromations
 *
 * Angles are described in degrees.
 *
 * `min_angle` and `max_angle` are values in [0,360[ and define the possible rotation
 * range for the shape and are given counterclockwise.
 *
 * `horizontal_flip` defines if the rotated shape must be symmetrized after the rotation
 *                   (mirror). The symmetry axis is the horizontal line passing through
 *                   the pivot of the shape.
 *
 * For instance, to have a free-orientation, one must use
 * `min_angle = 0.0` and `max_angle = 359.9`. This is what is done in
 * PN2_CreateFreeOrientation()
 * 
 * To allow both flipped and non-flipped free-orientation, two PN2_Orientation are
 * necessary with the same `min_angle` and `max_angle`, one with `horizontal_flip =
 * true`, the other with `horizontal_flip = false`
 *
 * @warning 
 * - `0 <= min_angle <= max_angle <= 359.9` must be respected
 * - Interop: If the library is called with a language which is not C
 *   nor C++, please note that there is a 4-bytes alignment padding
 *   between `horizontal_flip` and `min_angle` (double members are 8-bytes
 *   aligned, and PN2_Bool is a 4-bytes int). Total size of this structure
 *   is thus 24 bytes.
 *
 * @ingroup Orientation
 */
typedef struct tagPN2_Orientation
{
    PN2_Bool horizontal_flip;
    double min_angle;
    double max_angle;
}
PN2_Orientation;


/** @defgroup Session Session
 *  @brief Holds a nesting problem and its results
 */
/**
 * @brief A PN2_Session is an handle on a nesting problem.
 *
 * All PN2_Shape, PN2_Part, PN2_Sheet, ... created are attached to a
 * PN2_Session. And several PN2_Session can coexist, describing
 * different nesting problems.
 *
 * @ingroup Session
 */
typedef struct PN2_SessionInternal * PN2_Session;

/**
 * @defgroup Contour Contour
 * @brief How to describe geometries
 *
 * Used for instance to describe a PN2_Shape, a non-rectangular PN2_Sheet, some defects...
 */
/**
* @brief A PN2_Contour defines a polygon, possibly with arcs.
*
* A contour describes the unique closed outline of a non self-intersecting geometry.
*
* @ingroup Contour
*/
typedef struct PN2_ContourInternal * PN2_Contour;

/**
 * @brief A PN2_MultiContour represents a set of contours.
 *
 * @see PN2_Contour
 *
 * @ingroup Contour
 */
typedef struct PN2_MultiContourInternal * PN2_MultiContour;

/**
 * @defgroup Shape Shape
 * @brief An abstract geometric entity
 */
/**
 * @brief A PN2_Shape represents the geometrical aspects of an object to nest.
 *
 * Its geometry is described by at least one external outline and it may contain holes. A
 * PN2_Shape also holds some properties like a protection offset, some constraints, ...
 * 
 * @ingroup Shape
 */
typedef struct PN2_ShapeInternal * PN2_Shape ;

/**
 * @defgroup Part Part
 * @brief Individual physical entities which must be nested
 */
/**
 * @brief A PN2_Part represents an instance of an oriented PN2_Shape that can be nested on a PN2_Sheet.
 *
 * PN2_Part parts sharing the same geometries and properties should share a unique PN2_Shape.
 *
 * @ingroup Part
 */
typedef struct PN2_PartInternal * PN2_Part;

/**
 * @defgroup Sheet Sheet
 * @brief Surface where parts are nested
 */
/**
 * @brief A PN2_Sheet is a surface where PN2_Parts can be nested, usually rectangular.
 *
 * Unlike PN2_Shape and PN2_Part, there is no distinction between its geometry and its
 * individual representations. Instead, quantities are passed to optimization calls.
 *
 * A PN2_Sheet contains many properties like border gaps, rolling directions, ...
 *
 * @ingroup Sheet
 */
typedef struct PN2_SheetInternal * PN2_Sheet;

/**
 * @defgroup Result Result
 * @brief A sheet with nested parts
 */
/**
 * @brief Contains positions and orientations of all nested parts on a specific sheet.
 *
 * Other properties might also be present depending on the features used.
 *
 * @ingroup Result
 */
typedef struct PN2_ResultInternal * PN2_Result;

/**
 * @defgroup Optimization Optimization
 * @brief Optimization functions
 *
 * The main one is PN2_MultiNest()
 */
/**
 * @defgroup Constraints Constraints
 * @brief Take the material properties or the industrial process into account
 */
/**
 * @defgroup Callbacks Callbacks
 * @brief Interact with an ongoing optimization
 *
 * Give some feedback to the caller concerning the intermediate results found or stop an
 * ongoing optimization gracefully.
 *
 * @warning When Powernest is integrated within a garbage-collected/managed language
 *          (such as C#), the lifetime of callback-related objects must be extended
 *          explicitly to outlive all the optimization calls (in C# typically by calling
 *          GC.KeepAlive() right before deleting a PN2_Session, see
 *          https://learn.microsoft.com/en-us/dotnet/api/system.gc.keepalive)
 */

/**
 * @defgroup Troubleshooting Troubleshooting
 * @brief When things do not work as expected
 *
 * Powernest provides many tools to diagnose unexpected behaviors.
 *
 * 1. Errors checking. Errors must be explicitly checked after any call to the Powernest
 *    API, using PN2_IsObjectError() or directly the value of PN2_ErrorCode. Using
 *    PN2_ErrorMessage() or PN2_ErrorMessageFromObject() allows to get a human-readable
 *    explanation.
 *
 * 2. There were no errors, some optimization has been done and a result has been
 *    returned. However the result displayed in your software seems odd. In this case you
 *    can compare your result with what Powernest sees internally using PN2_DrawSvg() or
 *    PN2_DrawMultiSvg().
 * 
 * 3. Diagnostics. Powernest can detect valid but unexpected or unwise inputs. In this
 *    case no errors are returned but a human readable log may be generated. For this,
 *    one can use PN2_LogWarnings() which is aimed at developpers integrating
 *    Powernest. PN2_LogInternalWarnings() is aimed at Alma, if any log is generated by
 *    this, it means that something went wrong internally (which should remain unnoticed
 *    from the caller point of view). Please send us such a log file.
 *
 * 4. User warnings. Powernest can generate structured warnings aimed at the
 *    end-user. See PN2_GenerateNestWarnings()
 *
 * 5. Finally, if the error remains without explanation, please get in touch with us. You
 *    will need to isolate the issue and generate the corresponding log file using
 *    PN2_LogFunctionCalls() (make sure to call it before PN2_CreateSession()). This log
 *    file will allow us to reproduce the exact same API calls. Send it to us along with
 *    explanations on the issue and we will investigate.
 */


/**
 * @brief Behaviors of pre-nested parts during subsequent optimization algorithms.
 *
 * @see PN2_SetPreNestedGlueMode()
 * @ingroup Part
 */
typedef enum {
    ALWAYS_GLUE,           ///< Pre-nested parts cannot move at all.
    NEVER_GLUE,            ///< Pre-nested parts can be moved on the sheet without restriction.
    GLUE_ON_NEST_MORE_ONLY ///< Default mode, the parts can only be moved during
                           /// PN2_Shake(), PN2_PostOptimize(), PN2_Compact(),
                           /// PN2_Scatter(), ... but not during PN2_NestMore() nor
                           /// PN2_MultiNestMore()
} PN2_PRE_NESTED_GLUE_MODE;

/**
 * @brief Check if a value returned by a Powernest API call is an error
 *
 * All functions can return errors as a result of incorrect input.  Whatever the return
 * type of a function is (PN2_Bool, PN2_ErrorCode, PN2_Session, PN2_Part ...) it can be
 * casted to a signed integer value. A negative value indicates an error. For PN2 objects,
 * it is highly recommended to use PN2_IsObjectError() instead of this macro.
 *
 * If PN2_IS_ERROR() is true, PN2_ErrorMessage() or PN2_ErrorMessageFromObject() can be
 * used to get a human-readable error message.
 *
 * @ingroup Troubleshooting
 */
#define PN2_IS_ERROR(value) (((long)(value) < 0) ? 1 : 0)


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Creates a new PN2_Session.
     *
     * @return A new PN2_Session
     * The returned PN2_Session must be deleted with PN2_DeleteSession()
     *
     * @ingroup Session
     */
    PN2_EXPORTS PN2_Session PN2API PN2_CreateSession();

    /**
     * @brief Logs all API calls in a file
     *
     * This log contains everything Alma's team needs to reproduce and diagnose any
     * issue.
     * It is also used to gather data from the field and create benchmarks usable
     * for quality assurance.
     *
     * A first call to PN2_LogFunctionCalls() shall be done before anything else (in
     * particular before PN2_CreateSession())
     *
     * A second PN2_LogFunctionCalls() call will close the first log file and write all
     * following API calls in the new file if a new path has been given.
     *
     * @param file File path in which calls will be logged. If the file already exists,
     *        it will be overwritten. NULL can be used to stop the logging and close the
     *        file.
     *
     * @return 0 or a negative value if the operation failed, a positive value if it was a success.
     *
     * @warning Calling this after PN2_CreateSession() will result in an incomplete and
     * unusable log.
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_LogFunctionCalls(const char * file);

    /** 
     * @brief Appends some extra information concerning the host hardware to the pn2 log file.
     *
     * Such as the CPU model, memory available, ... This is useful in particular when
     * Powernest yields inconsistent results across different hardware.
     *
     * @note Must be called after PN2_LogFunctionCalls()
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_LogHostSpecs();

    /**
     * @brief Logs warnings readable by the caller.
     *
     * They might be of any kind:
     * - Hints to improve performances
     * - Dangerous parameters
     * - Shape descriptions issues
     * - Over-constrained problems
     * - unplaceable parts, for known or unknown reasons
     * - hardware limitations
     * - harmful user-callbacks
     * - ...
     *
     * They are written in english to help diagnose issues and improve Powernest
     * integration. They are not guaranteed to be stable across Powernest versions. They
     * are only aimed at developpers integrating Powernest within their application.
     *
     * The file is not created if nothing has been detected.
     *
     * Like PN2_LogFunctionCalls() it must be called before creating a PN2_Session.
     *
     * @param file_path the file path where to write the content. nullptr can be used to close an existing file.
     *
     * @return 0 or a negative value if the operation failed, a positive value if it was a success.
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_LogWarnings(const char * file_path);

    /**
      * @brief Logs internal issues, to be reported to Powernest's developers team.
      *
      * Those log files are self-contained and are used as part of the continuous
      * improvement of Powernest by its developers team. The content is not intended to
      * be used by anyone else.
      *
      * Most issues reported would otherwise be silent and likely invisible to the
      * end-user, unless the performance impact is too significant.
      *
      * The file is not created if nothing has been detected.
      *
      * Like PN2_LogFunctionCalls() it must be called before creating a PN2_Session.
      *
      * @param file_path the file path where to write the content. nullptr can be used to close an existing file.
      *
      * @return 0 or a negative value if the operation failed, a positive value if it was a success.
      *
      * @ingroup Troubleshooting
      */
    PN2_EXPORTS PN2_Bool PN2API PN2_LogInternalWarnings(const char * file_path);

    /**
     * @brief Deletes a session
     *
     * @param session The session to delete.
     * @return 0 or a negative value if the operation failed, a positive value if it was a success.
     *
     * Memory will be released, any further reference to this session
     * is undefined.
     *
     * @ingroup Session
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_DeleteSession(PN2_Session session);

    /**
     * @addtogroup Contour
     * @{
     */
    
    /**
     * @brief Creates a new polygonal contour, without arcs.
     * 
     * @param session The session which owns the contour.
     * @param points An array of points describing the polygon.
     * @param nb_points The number of points in the contour.
     *
     * @return The PN2_Contour created or an error code if the
     *         operation failed.
     *
     * @see PN2_CreateContourFromArcsSagittas() and PN2_CreateContourFromArcsCenters()
     */
    PN2_EXPORTS PN2_Contour PN2API PN2_CreateContourFromPoints(PN2_Session session, const PN2_Point* points, int nb_points);

    /**
     * @brief Creates a new curved contour described by sagittas.
     *
     * The sagitta is the distance between the middle of the arc and the center of the chord.
     *
     * @param session The session which owns the contour.
     * @param points An array of points describing vertices, between which there are arcs or
     *               segments.
     * @param sagittas Sagitta of arc joining ith and (i+1)th points. Null (<1e-6) if arc is flat (segment).
     *                 The last sagitta corresponds to the arc between the last and the first points. A positive
     *                 sagitta means an arc on the right-hand side of the chord, and a negative sagitta on the 
     *                 left-hand side. A sagitta of half the chord length is a semi-circle.
     * @param nb_points The number of elements in points and sagittas arrays.
     *
     * @return The PN2_Contour created or an error code if the
     *         operation failed.
     *
     * @see PN2_CreateContourFromPoints(), PN2_CreateContourFromArcsBulges() and PN2_CreateContourFromArcsCenters()
     */
    PN2_EXPORTS PN2_Contour PN2API PN2_CreateContourFromArcsSagittas(PN2_Session session, const PN2_Point* points, const double* sagittas, int nb_points);

    /**
    * @brief Creates a new curved contour described by bulges.
    *
    * The bulge is the ratio of the sagitta to half the chord length. It is equal to the tangent of one quarter
    * of the included angle of the arc.
    *
    * @param session The session which owns the contour.
    * @param points An array of points describing vertices, between which there are arcs or
    *               segments.
    * @param bulges Bulge of arc joining ith and (i+1)th points. Null (<1e-6) if arc is flat (segment).
    *               The last bulge corresponds to the arc between the last and the first points. A positive
    *               bulge means an arc on the right-hand side of the chord, and a negative bulge on the
    *               left-hand side. A bulge of 1 is a semi-circle.
    * @param nb_points The number of elements in points and bulges arrays.
    *
    * @return The PN2_Contour created or an error code if the
    *         operation failed.
    *
    * @see PN2_CreateContourFromPoints(), PN2_CreateContourFromArcsSagittas() and PN2_CreateContourFromArcsCenters()
    */
    PN2_EXPORTS PN2_Contour PN2API PN2_CreateContourFromArcsBulges(PN2_Session session, const PN2_Point* points, const double* bulges, int nb_points);

    /**
     * @brief Creates a new curved contour described by arcs centers.
     *
     * @param session The session which owns the contour.
     * @param points An array of points describing vertices, between which there are arcs or
     *               segments.
     * @param arcs_centers Center of arc joining ith and (i+1)th points. If ith arc is flat
     *                     (segment), center must be equal to the (i+1)th point. The last center
     *                     corresponds to the arc between the last and the first points.
     * @param arcs_dirs Direction of arc joining ith and (i+1)th points.
     *                  False (0) is anti-trigo, true (1) is trigo. Unused if arc is flat (segment).
     *                  The last direction corresponds to the arc between the last and the first points.
     * @param nb_points Number of elements in points, arcs_centers and arcs_dirs arrays.
     *
     * @return The PN2_Contour created or an error code if the
     *         operation failed.
     *
     * @warning The contour must contain at least two points. To describe a circle, one must use at least two arcs.
     *
     * @see PN2_CreateContourFromPoints(), PN2_CreateContourFromArcsBulges() and PN2_CreateContourFromArcsSagittas()
     */
    PN2_EXPORTS PN2_Contour PN2API PN2_CreateContourFromArcsCenters(PN2_Session session, const PN2_Point* points, const PN2_Point * arcs_centers, const PN2_Bool * arcs_dirs, int nb_points);


    /**
     * @}
     */

    /**
     * @addtogroup Shape
     * @{
     */
    
    /**
     * @brief Creates a new polygonal Shape
     *
     * @param session The session which owns the Shape.
     * @param p An array of points describing the polygon.
     *          If the last point is not the same as the first point, the outline 
     *          is closed by a segment between these two.
     * @param nb_points The number of points in the array p
     * @param pivot The pivot of the shape. Any reference to the
     *              position of a part using this shape will be given
     *              according to this particular pivot.
     *              It must be located inside the bounding box of the shape
     *
     * @return The new PN2_Shape or an error code if the
     *         operation failed.
     *
     * @see PN2_ShapeAddHole() and PN2_AddComplexShape()
     */
    PN2_EXPORTS PN2_Shape PN2API PN2_AddShape(PN2_Session session, const PN2_Point* p, int nb_points, PN2_Point pivot);

    /**
     * @brief Creates a new Shape from a contour.
     *
     * @param session Session owning the Shape.
     * @param contour The contour describing the outline of the shape.
     * @param pivot The pivot of the shape. Any reference to the
     *              position of a part using this shape will be given
     *              according to this particular pivot.
     *              It must be located inside the bounding box of the shape
     *
     * @return The PN2_Shape created or an error code if the operation failed.
     *
     * @see PN2_AddShape(), PN2_AddComplexShape(), PN2_ShapeAddHole(),
     *      PN2_AddComplexShapeFromContours() and PN2_ShapeAddHoleFromContour()
     */
    PN2_EXPORTS PN2_Shape PN2API PN2_AddShapeFromContour(PN2_Session session, PN2_Contour contour, PN2_Point pivot);


    /**
     * @brief Creates a complex polygon shape, ie one that has several
     *        disjoints external outlines
     *
     * @param session The session which owns the Shape.
     * @param all_points Concatenation of all points of each external outlines
     * @param nb_outline_point For each outline of all_points, the nb of points
     *                         composing it.
     * @param nb_outlines The number of outlines
     * @param pivot The pivot of the shape. It must be located inside the bounding box of the geometries
     *
     * @return A new PN2_Shape if no problem, else error code.
     *
     * @see PN2_AddShape() and PN2_ShapeAddHole()
     */
    PN2_EXPORTS PN2_Shape PN2API PN2_AddComplexShape(PN2_Session session, const PN2_Point* all_points, const int * nb_outline_point, int nb_outlines, PN2_Point pivot);

    /**
     * @brief Creates a complex shape, ie one that has several
     *        disjoints external outlines represented by their contour
     *
     * @param session The session which owns the Shape.
     * @param contours Array of contours of each external outline
     * @param nb_outlines The number of outlines
     * @param pivot The pivot of the shape. It must be located inside the bounding box of the contours
     *
     * @return The PN2_Shape created if no problem, else an error code.
     *
     * @see PN2_AddShape(), PN2_AddComplexShape(), PN2_ShapeAddHole(), PN2_AddShapeFromContour() and PN2_ShapeAddHoleFromContour()
     */
    PN2_EXPORTS PN2_Shape PN2API PN2_AddComplexShapeFromContours(PN2_Session session, const PN2_Contour* contours, int nb_outlines, PN2_Point pivot);

    /**
     * @brief Add a hole in a PN2_Shape
     *
     * This function allows to describe "holes" inside shapes,
     * i.e. polygons where there is no material. The polygon must 
     * be enclosed in the outline of the shape.
     *
     * Several holes can be added on the same shape but they must not
     * intersect each other.
     *
     * @param session The session which owns the Shape.
     * @param shape The shape in which the hole must be added.
     * @param hole_points The outline of the hole.
     *                    If the last point is not the same as the first point, the outline 
     *                    is closed by a segment between these two.
     *                    Coordinates of the points are given relatively to the coordinates of the shape.
     * @param hole_nb_points Number of points in hole_points.
     *
     * @return 0 if the hole was successfully added to the part, an error code otherwise.
     *
     * @see PN2_AddComplexShape() and PN2_AddShape()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeAddHole(PN2_Session session, PN2_Shape shape, const PN2_Point* hole_points, int hole_nb_points);

    /**
     * @brief Add a hole from a contour in a PN2_Shape
     *
     * This function allows to describe "holes" inside shapes,
     * i.e. areas where there is no material. The hole must be
     * enclosed in the outline of the shape.
     *
     * Several holes can be added on the same shape but they must not
     * intersect each other.
     *
     * @param session The session which owns the Shape.
     * @param shape The shape in which the hole must be added.
     * @param hole_contour The contour describing the hole outline.
     *
     * @return 0 if the hole was successfully added to the part, an error code otherwise.
     *
     * @see PN2_AddShape(), PN2_AddComplexShape(), PN2_ShapeAddHole(), PN2_AddShapeFromContour() and PN2_AddComplexShapeFromContours()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeAddHoleFromContour(PN2_Session session, PN2_Shape shape, PN2_Contour hole_contour);

    /**
     * @brief Compute and apply a protection zone at a constant distance around a shape.
     *
     * The protection is also created inside holes if any. This protection zone will not
     * overlap other parts themselves, but may overlap anything else. In particular it
     * may overlap other part protections, sheet defects, sheet border gaps and even be
     * placed outside of the sheet. For complex protection zones, see
     * PN2_ShapeSetProtectionLine().
     *
     * @param session The session owning the Shape.
     * @param shape The shape for which the protection zone is created
     * @param protection_offset The constant distance defining the protection zone around the shape.
     *
     * @return 0 if the protection line was successfully added to the part, an error code otherwise.
     *
     * @warning Protection zones of different parts can overlap. Meaning for instance
     *          that if a part shall be separated by 5mm from any other part, its
     *          PN2_Shape shall define a protection offset of 5mm independently from all
     *          the other PN2_Shape.
     *
     * @see PN2_ShapeSetProtectionLine() and PN2_ComplexShapeSetProtectionLine()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetProtectionOffset(PN2_Session session, PN2_Shape shape, double protection_offset);

    /**
     * @brief Add an arbitrary protection zone to a shape.
     *
     * A part is usually separated from other parts by a small gap to avoid issues during
     * the cutting process. When the gap is non constant around the PN2_Shape, this
     * function allows to set an arbitrary protection line around a part, defining a
     * protection zone inside which no other part material can be placed. Like
     * PN2_ShapeSetProtectionOffset(), this protection may overlap anything else.
     *
     * @note Holes must be handled separately with PN2_HoleSetProtectionLine()
     *
     * @param session The session owning the shape.
     * @param shape The shape for which the protection zone is added
     * @param protection An array of points describing the protection zone.
     *                   If the last point is not the same as the first point, the outline 
     *                   is closed by a segment between these two.
     *                   The real part outline must be included inside protection outline.
     * @param protection_nb_points Number of points in the protection polygon.
     *
     * @return 0 if the protection line was successfully added to the part, an error code otherwise.
     *
     * @see PN2_ShapeSetProtectionOffset(), PN2_HoleSetProtectionLine(),
     * PN2_ComplexShapeSetProtectionLine()
     *
     * @warning The new protection line completely replaces any shape and hole protection lines that have been set before.
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetProtectionLine(PN2_Session session, PN2_Shape shape, const PN2_Point* protection, int protection_nb_points);

    /**
     * @brief Same as PN2_ShapeSetProtectionLine() but for holes.
     * 
     * @note A shape protection line must have been defined prior to calling this function.
     * 
     * @see PN2_ShapeSetProtectionLine()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_HoleSetProtectionLine(PN2_Session session, PN2_Shape shape, const PN2_Point* protection, int protection_nb_points);

    /**
     * @brief Same as PN2_ShapeSetProtectionLine() but for complex parts with several external outlines.
     *
     * @see PN2_ShapeSetProtectionLine() and PN2_AddComplexShape()
     *
     * @warning The new protection line completely replaces any shape and hole protection lines that have been set before.
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ComplexShapeSetProtectionLine(PN2_Session session, PN2_Shape shape,
            const PN2_Point* protections, const int * outlines_nb_points, int nb_polygons);

    /**
     * @brief Add an arbitrary protection zone to a shape.
     *
     * Same as PN2_ShapeSetProtectionLine(), using a contour
     *
     * @param session The session owning the shape.
     * @param shape The shape for which the protection zone is added
     * @param protection The contour describing the protection line.
     *
     * @return 0 if the protection line was successfully added to the part, an error code otherwise.
     *
     * @see PN2_ShapeSetProtectionOffset(), PN2_HoleSetProtectionLineFromContour(),
     * PN2_ComplexShapeSetProtectionLineFromContours()
     * 
     * @warning The new protection line completely replaces any shape and hole protection lines that have been set before.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetProtectionLineFromContour(PN2_Session session, PN2_Shape shape, PN2_Contour protection);

    /**
     * @brief Same as PN2_ShapeSetProtectionLineFromContour() but for holes. 
     * 
     * @note A shape protection line must have been defined prior to calling this function.
     *
     * @see PN2_ShapeSetProtectionLine(), PN2_ShapeSetProtectionLineFromContour(),
     *      PN2_ComplexShapeSetProtectionLine() and PN2_ComplexShapeSetProtectionLineFromContours().
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_HoleSetProtectionLineFromContour(PN2_Session session, PN2_Shape shape, PN2_Contour protection);

    /**
     * @brief Same as PN2_ShapeSetProtectionLineFromContour() but for complex parts with several external outlines.
     *
     * @see PN2_ShapeSetProtectionLineFromContour() and PN2_AddComplexShapeFromContours()
     *
     * @warning The new protection line completely replaces any shape and hole protection lines that have been set before.
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ComplexShapeSetProtectionLineFromContours(PN2_Session session, PN2_Shape shape, const PN2_Contour* protections, int nb_protections);

    /**
     * @}
     */

    /**
     * @addtogroup Orientation
     * @{
     */

    /**
     * @brief Creates a non flipped fixed orientation of rotation "angle" degrees
     */
    PN2_EXPORTS PN2_Orientation PN2API PN2_CreateOrientation(double angle);

    /**
     * @brief Creates a non flipped range of orientations
     *
     * Creates range of orientations [angle - tolerance ; angle + tolerance] (in degrees)
     * 
     * @deprecated in particular it will not work if 0 or 360 are included in the result `[min_angle, max_angle]`
     */
    PN2_EXPORTS PN2_Orientation PN2API PN2_CreateRangeOrientation(double angle, double tolerance);

    /**
     * @brief Creates a flipped orientation of rotation "angle" degrees
     */
    PN2_EXPORTS PN2_Orientation PN2API PN2_CreateXFlippedOrientation(double angle);

    /**
     * @brief Creates a range of orientations with a flip
     * 
     * Creates range of orientations [angle - tolerance ; angle + tolerance] (in degrees) with a flip
     *
     * @deprecated for the same reason than PN2_CreateRangeOrientation()
     */
    PN2_EXPORTS PN2_Orientation PN2API PN2_CreateXFlippedRangeOrientation(double angle, double tolerance);

    /**
     * @brief Creates a free range of orientations (angle [0,360], flipped xor not)
     *
     * @note To allow any angle for both flipped and non flipped part, use the  two PN2_Orientation
     *       given by PN2_CreateFreeOrientation(true) and PN2_CreateFreeOrientation(false)
     * 
     * @param flip: true to create flipped orientations, false otherwise.
     */
    PN2_EXPORTS PN2_Orientation PN2API PN2_CreateFreeOrientation(PN2_Bool flip);

    /**
     * @}
     */

    /**
     * @brief Creates a PN2_Point
     */
    PN2_MAYBE_UNUSED static PN2_Point PN2_CreatePoint(double x, double y)
    {
        PN2_Point res = {x, y};
        return res;
    }


    /**
     * @addtogroup Part
     * @{
     */

    /**
     * @brief Creates a new Part
     *
     * This is where rotations authorizations are set. Each individual part must be
     * created using this function until the desired quantity is obtained.
     *
     * @param session The session owning the part.
     * @param shape The geometry of this part. The shape must have been previously created in the same session.
     * @param ors Array of allowed orientations of the shape in which this part can be nested.
     * @param nb_orientations The number of orientations.
     *
     * @return A new PN2_Part. When casted in int the value is
     * positive if the operation is a success. Negative otherwise.
     */
    PN2_EXPORTS PN2_Part PN2API PN2_AddPart(PN2_Session session, PN2_Shape shape, const PN2_Orientation* ors, int nb_orientations);

    /**
     * @brief Creates several identical parts
     *
     * Creates several parts which share the shape and the orientations. It is equivalent
     * to call PN2_AddPart() N times with the same parameters.
     *
     * @param session The session owning the parts.
     * @param shape The geometry of the created parts.
     * @param ors Allowed orientations for the created parts.
     * @param nb_orientations The number of orientations in ors.
     * @param quantity The number of parts to create.
     *
     * @param[in,out] parts The array which will be filled with all created parts.
     *                      The array must be wide enough to contain "quantity" PN2_Parts.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_AddSeveralParts(PN2_Session session, PN2_Shape shape, const PN2_Orientation* ors, int nb_orientations, int quantity, PN2_Part * parts);

    /**
     * @brief Set the priority on a part so it will be nested "before" other parts with
     *        lower priorities
     *
     * Parts with higher priorities are *consumed* before parts with lower priorities,
     * meaning first sheets will have a *tendency* to include higher priorities and last
     * sheets lower. The default priority is 0. Negative priorities are allowed.
     *
     * This feature is often combined with PN2_PartSetOrderGroup() and
     * PN2_SetMaximumInterleavedGroups() to be actually relevant.
     *
     * @param session The session holding the part
     * @param part The part to set the priority on
     * @param priority Highest priorities are nested first
     *
     * @return 0 if the operation is successful
     *
     * @warning
     * - Use with care, as it might significantly reduce nesting performances.
     * - If there is only one sheet, priorities are irrelevant.  It thus works only with
     *   PN2_MultiNest() and PN2_MultiNestMore(). For one one-sheet nesting with prices
     *   on parts, see PN2_ShapeSetPrice()
     * - There is no constraint on the result, in particular the first sheets may contain
     *   parts with low priority, the last sheets may contain parts with high
     *   priority. If the low priority parts are very small for instance, they may fit
     *   everywhere and will be placed anywhere.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_PartSetPriority(PN2_Session session, PN2_Part part, int priority);

    /**
     * @}
     */

    /**
     * @addtogroup Sheet
     * @{
     */

    /**
     * @brief Creates a new simple rectangular sheet.
     *
     * @param session The session owning the sheet.
     * @param height the height of the sheet.
     * @param length Length of the sheet, -1 for an infinite length
     *
     * @return A new PN2_Sheet or an error code if the operation failed (see
     *         PN2_IsObjectError()).
     *
     * @see PN2_AddPolygonalSheet() for non rectangular sheets
     *
     * @note the word "width" is usually avoided in this context to avoid confusion. By
     * default the offcut is retrieved on the right side of the sheet and thus the sheet
     * is often described horizontally length-wise. The "width" could refer to both the
     * smallest dimension or the distance between the right and left side of the
     * sheet. Using height and length mitigates the confusion.
     *
     * @code{.unparsed}
     *  
     *                 length, possibly infinite
     *               <-------------------------->
     *             ^ +--------------------------+
     *             | |                          |
     *             | |                          |
     *      height | |                          |
     *             | |                          |
     *             | |                          |
     *             v +--------------------------+
     *
     * @endcode
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddSheet(PN2_Session session, double height, double length);

    /**
     * @brief Add a gap around borders of the sheet where no part can be nested
     *
     * For each gap giving a negative or zero value means no gap is
     * added on this side
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet we want to add gaps on (must be a rectangular sheet)
     * @param left_gap gap value on the left of the sheet
     * @param right_gap gap value on the right of the sheet
     * @param bottom_gap gap value on the bottom of the sheet
     * @param top_gap gap value on the top of the sheet
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetAddBorderGaps(PN2_Session session, PN2_Sheet sheet, double left_gap, double right_gap, double bottom_gap, double top_gap);

    /**
     * @brief Adds a defect on a sheet.
     *
     * A defect is a zone on a sheet where parts can not be nested.
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet we want to add a defect on.
     * @param defect_points An array of points describing the polygon of the defect zone.
     *                      If the last point is not the same as the first point, the outline 
     *                      is closed by a segment between these two.
     *                      Positions are absolute coordinates in the sheet, bottom left of the sheet beeing (0,0).
     * @param defect_nb_points number of points in defect_points
     *
     * @return The status of the operation, 0 if the operation succeeded, an error otherwise
     *
     * @note A protection zone around a part can overlap with a defect.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetAddDefect(PN2_Session session, PN2_Sheet sheet, const PN2_Point* defect_points, int defect_nb_points);

    /**
     * @brief Adds a defect on a sheet.
     *
     * A defect is a zone on a sheet where parts can not be nested.
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet we want to add a defect on.
     * @param contour The contour describing the defect outline.
     *
     * @return The status of the operation, 0 if the operation succeeded, an error otherwise
     *
     * @note A protection zone around a part can overlap with a defect.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetAddDefectFromContour(PN2_Session session, PN2_Sheet sheet, PN2_Contour contour);

    /**
     * @brief Adds an offseted defect on a sheet.
     *
     * A defect is a zone on a sheet where parts can not be nested.
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet we want to add a defect on.
     * @param defect_points An array of points describing the polygon of the defect zone.
     *                      If the last point is not the same as the first point, the outline 
     *                      is closed by a segment between these two.
     *                      Positions are absolute coordinates in the sheet, bottom left of the sheet beeing (0,0).
     * @param defect_nb_points number of points in defect_points
     * @param offset a positive value to "grow" the defect, the behavior is identical to the offset of PN2_ShapeSetProtectionOffset().
     *
     * @return The status of the operation, 0 if the operation succeeded, an error otherwise
     *
     * @note A protection zone around a part can overlap with a defect.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetAddDefectWithOffset(PN2_Session session, PN2_Sheet sheet, const PN2_Point* defect_points, int defect_nb_points, double offset);

    /**
     * @brief Adds an offseted defect on a sheet.
     *
     * A defect is a zone on a sheet where parts can not be nested.
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet we want to add a defect on.
     * @param contour The contour describing the defect outline.
     * @param offset a positive value to "grow" the defect, the behavior is identical to the offset of PN2_ShapeSetProtectionOffset().
     *
     * @return The status of the operation, 0 if the operation succeeded, an error otherwise
     *
     * @note A protection zone around a part can overlap with a defect.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetAddDefectFromContourWithOffset(PN2_Session session, PN2_Sheet sheet, PN2_Contour contour, double offset);

    /**
     * @brief Create a new non-rectangular Sheet
     *
     * Adds a sheet that is not a simple rectangle but a polygon.
     *
     * @param session The session owning the sheet.
     * @param points An array of points describing the polygon of the sheet.
     *               If the last point is not the same as the first point, the outline 
     *               is closed by a segment between these two.
     * @param nb_points The number of points
     *
     * @return A new polygonal PN2_Sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @warning The sheet must be described such that the bottom left corner of its
     * bounding box is the point (0, 0).
     *
     * @see PN2_AddPolygonalSheetWithBorderGap()
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddPolygonalSheet(PN2_Session session, const PN2_Point * points, int nb_points);
    
    /**
     * @brief Same as PN2_AddPolygonalSheet(), but with a constant gap on all edges of the sheet.
     *
     * @param session The session owning the sheet.
     * @param points An array of points describing the polygon of the sheet.
     *               If the last point is not the same as the first point, the outline 
     *               is closed by a segment between these two.
     * @param nb_points the number of points of nb_points
     * @param border_gap the fixed width of the gap to apply to all edges of the sheet.
     *
     * @return A new polygonal PN2_Sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @warning The sheet must be described such that the bottom left corner of its
     *          bounding box is the point (0, 0), without considering the border_gap.
     *
     * @see PN2_AddPolygonalSheet() and PN2_ShapeSetProtectionOffset()
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddPolygonalSheetWithBorderGap(PN2_Session session, const PN2_Point * points, int nb_points, double border_gap);
    
    /**
     * @brief Create a new non-rectangular sheet.
     *
     * Adds a sheet that is not a simple rectangle.
     *
     * @param session The session owning the sheet.
     * @param contour The contour describing the outline of the sheet.
     *
     * @return A new non-rectangle PN2_Sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @warning The sheet must be described such that the bottom left corner of its
     *          bounding box is the point (0, 0).
     *
     * @see PN2_AddPolygonalSheet()
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddSheetFromContour(PN2_Session session, PN2_Contour contour);
    
    /**
     * @brief Same as PN2_AddSheetFromContour(), but with a constant gap on all edges of the sheet.
     *
     * @param session The session owning the sheet.
     * @param contour The contour describing the outline of the sheet.
     * @param border_gap The fixed width of the gap to apply to all edges of the sheet.
     *
     * @return A new non-rectangle PN2_Sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @warning The sheet must be described such that the bottom left corner of its
     *          bounding box is the point (0, 0), without considering the border_gap.
     *
     * @see PN2_AddSheetFromContour() and PN2_ShapeSetProtectionOffset()
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddSheetFromContourWithBorderGap(PN2_Session session, PN2_Contour contour, double border_gap);

    /**
     * @}
     */


    /**
     * @addtogroup Optimization
     * @{
     */

    /**
     * @brief Optimize the nesting of many PN2_Part on a single PN2_Sheet.
     *
     * Unless stated otherwise, PN2_MultiNest() should be used by default instead of
     * PN2_Nest(), even for single sheet optimization.
     *
     * The optimization objective is to minimize the material waste:
     * 1) by minimizing the length used on the sheet if all
     *    parts can be nested
     * 2) by maximizing the material yield if not all parts fit in the sheet.
     *
     * @param session The session owning the sheet and the parts.
     * @param sheet The sheet parts will be nested on.
     * @param parts The parts to be nested.
     * @param nb_parts The number of parts.
     * @param time The maximum time that will be used to optimize the nesting, given in seconds
     *
     * @return The PN2_Result containing all positions and orientations of all nested
     *         part on the sheet or an error code if the operation failed (see
     *         PN2_IsObjectError()).
     *
     * @note A strength of Powernest is its ability to automatically and internally
     *       configure itself to any problem to give the best result in a given time and
     *       computing ressources. Concerning the amount of time to give, some seconds
     *       are generally enough to get a first non-optimized result, the more time is
     *       given to PN2_Nest(), the better the result. A couple of minutes are usually
     *       recommended. Many hours might be used for the most extreme cases.
     *
     * @see PN2_SetSessionCallbacks() and PN2_SetSessionNbThreads()
     */
    PN2_EXPORTS PN2_Result PN2API PN2_Nest(PN2_Session session, PN2_Sheet sheet, const PN2_Part* parts, int nb_parts, double time);

    /**
     * @brief Manually pre-nest parts on a sheet.
     *
     * To perform partial manual nestings before applying others automatic algorithms. 
     *
     * Please note that there is no check on the geometric validity of the pre-nested parts:
     * these parts are allowed to be placed outside of the sheet or overlapping each other
     * or a defect.
     * However, the positions and orientations of the pre-nested parts shall
     * meet the constraints that are applied to these parts,
     * otherwise some of the parts will not be placed.
     *
     * @param session The session owning sheet and parts
     * @param sheet The sheet on which to nest parts
     * @param parts The parts to be pre-nested
     * @param ors Orientations of the parts to pre-nest
     * @param pos Positions of the parts to pre-nest
     * @param nb_parts Number of parts to pre-nest
     * @return A PN2_Result with all parts nested on the sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_NestMore()
     */
    PN2_EXPORTS PN2_Result PN2API PN2_PreNest(PN2_Session session, PN2_Sheet sheet, const PN2_Part * parts, const PN2_Orientation * ors, const PN2_Point * pos, int nb_parts);

    /**
     * @brief Automatically complete a previous nesting result with more parts
     *
     * The PN2_Result can come from an automatic algorithm like PN2_Nest() or from an
     * manual nesting like PN2_PreNest().
     * Parts previously nested are not moved, see PN2_SetPreNestedGlueMode() to change
     * this behavior.
     *
     * @param session The session owning the sheet and parts
     * @param result The previous nesting in which new parts must be added.
     * @param parts The array of parts to add
     * @param nb_parts The number of parts to add
     * @param time The maximum time that will be used to optimize the nesting, given in seconds
     * @return A PN2_result with all parts nested on the sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_PreNest(), PN2_Nest() 
     */
    PN2_EXPORTS PN2_Result PN2API PN2_NestMore(PN2_Session session, PN2_Result result, const PN2_Part * parts, int nb_parts, double time);

    /**
     * @}
     */

    /**
     * @addtogroup Result
     * @{
     */

    /**
     * @brief Get general informations on a nesting result.
     *
     * @param session The session owning the result.
     * @param result The nesting result we want to get information about.
     * @param[out] length location where to store the length of this nesting.
     * @param[out] nb_nested location where to store the number of nested parts in this nesting.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetResultInfos(PN2_Session session, PN2_Result result, double * length, int * nb_nested);

    /**
     * @brief Retrieve the position and orientation of the k-th part in the result.
     *
     * @param session The session owning the result and the part.
     * @param result The nesting result where to extract information from.
     * @param index Index of the requested part (0 <= index < number of parts in the result)
     * @param[out] part location where the nested part information are returned by the procedure 
     * @param[out] pos location where the nested part positions are returned by the procedure 
     * @param[out] o location where the nested part orientations are returned by the procedure 
     *
     * @note The orientation o will always have o.min_angle == o.max_angle.
     *
     * @see PN2_Orientation documentation to see how to apply the rotation
     *      transformation. Note that all transformations are related to the pivot of the
     *      shape, given when using PN2_AddShape() or PN2_AddComplexShape(), meaning that
     *      rotation and translation can be applied in any order: either rotate the part
     *      points about the original pivot first and translate or translate the part
     *      points and the pivot and then rotate the part points about the translated
     *      pivot. The symmetry, if any, must be applied immediately after the rotation,
     *      along the line parallel to the X axis, passing through the pivot.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetKthNestedPart(PN2_Session session, PN2_Result result, int index, PN2_Part * part, PN2_Point * pos, PN2_Orientation * o);

    /**
     * @brief Retrieve the position and orientation of a nested PN2_Part.
     *
     * For iterating over a nesting result, using PN2_GetKthNestedPart() should be
     * preferred as it reduces the complexity of iterating over the nested parts.
     *
     * @param session The session owning the result and the part.
     * @param result The nesting result where the part is nested.
     * @param part Retrieve the position and orientation for this part
     * @param[out] pos location where to store the position of the nested part
     * @param[out] o location where to store the orientation of the nested part
     *
     * @note The orientation o will always have o.min_angle == o.max_angle.
     *
     * @return a positive value if the part has been nested in this result, 0 if it has not, 
     *         and a negative value if an error occurred.
     *
     * @see PN2_Orientation documentation to see how to apply the rotation
     *      transformation. Note that all transformations are related to the pivot of the
     *      shape, given when using PN2_AddShape() or PN2_AddComplexShape(), meaning that
     *      rotation and translation can be applied in any order: either rotate the part
     *      points about the original pivot first and translate or translate the part
     *      points and the pivot and then rotate the part points about the translated
     *      pivot. The symmetry, if any, must be applied immediately after the rotation,
     *      along the line parallel to the X axis, passing through the pivot.
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_GetNestedPart(PN2_Session session, PN2_Result result, PN2_Part part, PN2_Point* pos, PN2_Orientation * o);

    /**
     * @}
     */

    /**
     * @addtogroup Troubleshooting
     * @{
     */

    /**
     * @brief Draw a graphical representation of a PN2_Result in a file.
     *
     * The image is in the SVG format. Used only for debug purpose. The SVG is not very
     * precise, in particular it is not suitable when looking for small overlaps.
     *
     * @param session The session owning the result.
     * @param result The nesting result to draw.
     * @param file_name Path of the output file. The .svg extension is not added automatically
     *
     * @return 0 if writing succeeded, an error code otherwise.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_DrawSvg(PN2_Session session, PN2_Result result, const char* file_name);

    /**
     * @brief Retrieve a descriptive string associated to an error code.
     *
     * PN2_ErrorMessageFromObject() should be preferred in case of PN2 objects.
     *
     * @param error_code the error code resulting from the int cast of a returned value.
     * @return Message explaining the error. If error_code is not valid returns NULL.
     *
     * @see PN2_IS_ERROR
     */
    PN2_EXPORTS const char * PN2API PN2_ErrorMessage(int error_code);

    /**
     * @brief Retrieve a descriptive string associated to an error object.
     *
     * @param error_object the object that returned as an error.
     * @return Message explaining the error. If error_object is not valid returns NULL.
     *
     * @see PN2_IsObjectError(), PN2_ErrorCodeFromObject()
     */
    PN2_EXPORTS const char * PN2API PN2_ErrorMessageFromObject(void* error_object);

    /**
     * @brief Error management utility.
     *
     * Many functions used to create objects (PN2_Part with PN2_AddPart, PN2_Shape with PN2_AddShape, etc...)
     * can return an error object when something wrong has happened (wrong user data, ...).
     *
     * If the return value is true, PN2_ErrorMessageFromObject() can be used to get a human-readable error message,
     * and PN2_ErrorCodeFromObject() can be used to retrieve the error code.
     * 
     * @param object the object to check the error status of.
     * @return true if the object is an error, false otherwise.
     *
     * @see PN2_ErrorMessageFromObject(), PN2_ErrorCodeFromObject()
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_IsObjectError(void* object);

    /**
     * @brief Returns the error code associated to an error object.
     *
     * @param error_object the object that returned as an error.
     * @return The error code or 0 if the object is actually valid.
     *
     * @see PN2_ErrorMessageFromObject(), PN2_IsObjectError()
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ErrorCodeFromObject(void* error_object);

    /**
     * @}
     */

    /**
     * @addtogroup Callbacks
     * @{
     */

    /**
     * @brief User-defined informative callback on the automatic nesting progress
     *
     * This callback is called during PN2_Nest(), PN2_NestMore(), ... each time a better
     * nesting if found.
     *
     * @param user_data location of the user defined data
     * @param session The session owning the result
     * @param result The read-only PN2_Result representing the best
     *               solution found so far. Result' data are valid
     *               inside the callback call only. Queries on the
     *               result outside the callback are undefined.
     *
     * @warning This function must return quickly. Calling optimization algorithms (such as
     *   Nest, Shake, Compact, Spread...) inside a callback is prohibited.
     * 
     * @note This function uses the __cdecl ABI convention contrary to the other PN2
     *       functions.
     * 
     * @see PN2_SetSessionCallbacks(), PN2_GetResultInfos(), PN2_GetNestedPart() and PN2_DrawSvg()
     */
    typedef void (*PN2_UpdateBest) (void * user_data, PN2_Session session, PN2_Result result);

    /**
     * @brief User-defined callback to stop an ongoing optimization at any time.
     *
     * An ongoing optimization will stop as soon as possible and gracefully once asked to
     * do so.
     *
     * @param user_data location of user defined data
     *
     * @return A non-zero value when intending to stop current computations
     *
     * @warning This function is called very frequently and shall return as soon as
     *          possible to minimize the impact on performances.
     *
     * @note this function uses the __cdecl ABI convention contrary to the other PN2 
     *       functions. 
     * 
     * @see PN2_SetSessionCallbacks(), PN2_SetSessionMultiCallbacks()
     */
    typedef PN2_Bool (*PN2_StopNesting) (void * user_data);

    /**
     * @brief Assign user-defined callbacks to a session
     *
     * @param session The session where the user-defined callback have to be called.
     * @param fstop user-defined callback to stop an algorithm at any time
     * @param stop_data user-defined location passed to fstop
     * @param fupdate user-defined callback called each time a better result is found
     * @param update_data user-defined location passed to fupdate
     *
     * Even when nesting with multiple threads, callbacks are always executed in mutual exclusion.
     *
     * If one of the callback is not necessary, `fstop` and `fupdate` can be NULL.
     *
     * @return 0 if the operation succeeded
     *
     * @see PN2_SetSessionMultiCallbacks() for multi-sheet optimization callbacks
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSessionCallbacks(PN2_Session session, PN2_StopNesting fstop, void * stop_data, PN2_UpdateBest fupdate, void * update_data);

    /**
     * @}
     */

    /**
     * @brief Set number of threads used during optimization, to improve performances.
     *
     * By default, the library will try te detect the number of concurrent threads
     * supported on the host platform. If the detection fails, it will default to 1 thread.
     *
     * @param session The session where the number of threads is set
     * @param nb_threads The actual number of threads to use.
     *
     * @warning For performances reasons, the number of threads should not be greater
     * than the number available on the host platform.
     *
     * @ingroup Session
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSessionNbThreads(PN2_Session session, int nb_threads);


    /**
     * @brief Create an html report file each time a call to PN2_Nest() is done
     *
     * For debug purpose only.
     *
     * @param session The session which should export its results.
     * @param report_file Path of the .html report file
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetOutputReportFile(PN2_Session session, const char * report_file);

    /**
     * @brief Checks if the current executable/license is allowed to run Powernest
     *
     * @see When using a software license, PN2_CheckLicense() is a dedicated function
     * that provides more accurate information if no valid license is detected.
     * 
     * @param[out] detected_exe the executable path found
     * @return True if the executable is accepted and the license is valid, false otherwise.
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_CheckDetectedExe(char detected_exe[1024]);
    
    /**
     * @brief Get the version number of the current Powernest library
     *
     * @return the version id
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS int PN2API PN2_GetVersion();

    /**
     * @brief Improve a manual nesting
     *
     *  A manual nesting is improved by compressing it toward the left.
     *
     * @param session The session owning the result.
     * @param result The result we want to improve.
     * @param time The maximum time that will be used by the algorithm, given in seconds
     *             (a couple of seconds is usually enough).
     *
     * @return A PN2_result or an error code if the operation failed (see
     *         PN2_IsObjectError()).
     *
     * @note This function is designed to improve manual nestings, a result from
     *       PN2_Nest() should be already "shaked".
     *
     * @see PN2_PreNest()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_Result PN2API PN2_Shake(PN2_Session session, PN2_Result result, double time);


    /**
     * @brief Set the behaviour of a part that has been pre-nested.
     *
     * Default mode is GLUE_ON_NEST_MORE_ONLY.
     *
     * @param session The session owning the data.
     * @param p The PN2_Part to set the behavior.
     * @param glue_mode The glue mode to use, see @ref PN2_PRE_NESTED_GLUE_MODE definition.
     *
     * @return 0 if successful, or a PN2_ErrorCode otherwise.
     *
     * @ingroup Part
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetPreNestedGlueMode(PN2_Session session, PN2_Part p, PN2_PRE_NESTED_GLUE_MODE glue_mode);


    /**
     * @brief Set the PN2_Nest() objective to minimize the bounding box area of the nesting instead of the length.
     *
     * This is only relevant when there are not enough parts to generate a good straight
     * vertical offcut. Otherwise this might decrease the result efficiency.
     * 
     * @param session The usual session to in which the algorithm should be run
     * @param minimize_bbox_area Whether or not PN2_Nest() should minimize the bounding box area.
     *
     * @return 0 if everything went well, an error code otherwise.
     *
     * @warning This feature affect the behavior of PN2_Nest() only (not PN2_MultiNest())
     *
     * @ingroup Session
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSessionMinimizeBoundingBoxArea(PN2_Session session, PN2_Bool minimize_bbox_area);

    /**
     * @brief Define exclusive groups of PN2_Parts which cannot be nested together.
     *
     * PN2 will nest one and only one of these groups at the exclusion of the others.
     *
     * @ingroup Part
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetExclusiveGroups(PN2_Session session, PN2_Part * groups, int * group_sizes, int nb_groups);

    /**
     * @brief Defines the shape price.
     *
     * This is only relevant when all the shapes cannot be placed, Powernest2 will
     * maximize the price nested.
     *
     * The default price is the shape area.
     *
     * @ingroup Shape
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetPrice(PN2_Session session, PN2_Shape shape, double price);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* POWERNEST2_H_ */
