/**
 * @file
 * @author Alma
 * @brief Multi-sheet nesting algorithms.
 */

#ifndef POWERNEST2_METAL_H_
#define POWERNEST2_METAL_H_

#include "powernest2.h"

/**
 * @brief A PN2_MultiResult represents a set of nestings on several sheets.
 *
 * @see PN2_Result
 * @ingroup Result
 */
typedef struct PN2_MultiResultInternal * PN2_MultiResult ;


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Create a simple rectangular sheet
     *
     * @param session the session which will own the sheet
     * @param height Height of the sheet
     * @param length Length of the sheet
     *
     * @return A new PN2_Sheet or an error code if the operation failed (see
     *         PN2_IsObjectError()).
     *
     * @note This function is equivalent to PN2_AddSheet(), see its documentation for
     *       details
     *
     * @ingroup Sheet
     */
    PN2_EXPORTS PN2_Sheet PN2API PN2_AddMetalSheet(PN2_Session session, double height, double length);

    /**
     * @brief Automatic nesting on a single sheet with priced parts
     *
     * @deprecated
     * This function is deprecated, PN2_ShapeSetPrice() should be used instead.
     *
     * Useful when there are more parts than the sheet can
     * contain. Each part has a price and the algorithm will produce a
     * nesting which maximizes the total price of parts nested.
     *
     * @param session The session which owns the sheet and the parts.
     * @param sheet The sheet on which parts will be nested
     * @param parts The parts to be nested.
     * @param prices The price of each part. Prices must be strictly positive.
     * @param nb_parts The total number of parts.
     * @param time The maximum time that will be used by the nesting algorithm, given in seconds.
     *
     * @return A PN2_result containing parts that maximize the total price or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_Nest()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_Result PN2API PN2_PricedNest(PN2_Session session, PN2_Sheet sheet, const PN2_Part* parts, int * prices, int nb_parts, double time);

    /**
     * @brief Nest all parts on several sheets at once.
     *
     * Maximize the material yield by placing as many parts as possible and, if all parts
     * have been nested, considering a single reusable straight vertical offcut on the
     * last sheet.
     *
     * @param session The session which owns sheets and parts.
     * @param sheets Sheets on which parts will be nested
     * @param nb_sheets Number of sheets
     * @param sheet_quantities Quantity available for each sheet
     * @param parts Parts to be nested.
     * @param nb_parts Number of parts.
     * @param time The maximum time that will be used by the nesting algorithm, given in seconds.
     *
     * @return A PN2_MultiResult with parts nested on sheets or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_Nest()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_MultiResult PN2API PN2_MultiNest(PN2_Session session, const PN2_Sheet * sheets, int nb_sheets, const int * sheet_quantities, const PN2_Part* parts, int nb_parts, double time);

    /**
     * @brief Retrieve informations on a PN2_MultiResult
     *
     * Get the number of sheets used in a PN2_MultiResult
     *
     * @param session The session owning the MultiResult
     * @param multi_result The PN2_MultiResult queried
     * @param[out] nb_sheets location where to store the number of sheets used in multi_result
     *
     * @return error code or 0 if there is no error
     *
     * @ingroup Result
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetMultiResultInfos(PN2_Session session, PN2_MultiResult multi_result, int * nb_sheets);

    /**
     * @brief Retrieve a single PN2_Result from a PN2_MultiResult
     *
     * Allow to iterate over all PN2_Result of a PN2_MultiResult. The corresponding
     * PN2_Sheets are also retrieved here.
     *
     * @param session The session which owns the multi-result
     * @param multi_result The multiresult of which we want to get a specific result
     * @param index The index of the sheet in the multiresult
     *                    the value has to be in [0, nb_sheet[, "nb_sheet" beeing given by PN2_GetMultiResultInfos
     * @param[out] sheet_result location where to store the sheet id of the returned result.
     *
     * @return The i-th PN2_Result of this PN2_MultiResult or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_GetMultiResultInfos(), PN2_GetResultInfos() and PN2_GetNestedPart()
     *
     * @ingroup Result
     */
    PN2_EXPORTS PN2_Result PN2API PN2_GetResult(PN2_Session session, PN2_MultiResult multi_result, int index, PN2_Sheet * sheet_result);

    /**
     * @brief Draw a graphical representation of a PN2_MultiResult in a file.
     *
     * The image is in the SVG format. Used only for debug purpose. The SVG is not very
     * precise, in particular it is not suitable when looking for small overlaps.
     *
     * @param session The session owning the result.
     * @param result The multi-result to draw.
     * @param file_name Path of the output file. The .svg extension is not added automatically
     *
     * @return 0 if writing succeeded, an error code otherwise.
     *
     * @ingroup Troubleshooting
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_DrawMultiSvg(PN2_Session session, PN2_MultiResult result, const char* file_name);

    /**
     * @brief User-defined informative callback on the automatic multi-nesting progress
     *
     * This callback is called during PN2_MultiNest(), PN2_MultiNestMore(), ... each time
     * a better nesting if found.
     *
     * @param user_data location of the user defined data
     * @param session The session owning the result
     * @param result The read-only PN2_MultiResult representing the
     *               best solution found so far. Result' data are
     *               valid inside the callback call only. Queries on
     *               the result outside the callback are undefined.
     *
     * @warning This function must return quickly. Calling optimization algorithms (such as
     *          Nest, Shake, Compact, Spread...) inside a callback is prohibited.
     *
     * @note This function uses the __cdecl ABI convention contrary to the other PN2
     *       functions.
     *
     * @see PN2_SetSessionMultiCallbacks(), PN2_GetMultiResultInfos() and PN2_DrawMultiSvg()
     *
     * @ingroup Callbacks
     */
    typedef void (*PN2_MultiUpdateBest) (void * user_data, PN2_Session session, PN2_MultiResult result);

    /**
     * @brief Assign user-defined multi-nesting callbacks to a session
     *
     * @param session The session where the user-defined callback have to be called.
     * @param fstop user-defined callback to stop an algorithm at any time
     * @param stop_data user-defined location passed to fstop
     * @param fupdate user-defined callback called each time a better multi-result is found
     * @param update_data user-defined location passed to fupdate
     *
     * Even when nesting with multiple threads, callbacks are always executed in mutual exclusion.
     *
     * If one of the callback is not necessary, `fstop` and `fupdate` can be NULL.
     *
     * @return 0 if the operation succeeded
     *
     * @see PN2_SetSessionCallbacks() when using single-sheets algorithms
     *
     * @ingroup Callbacks
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSessionMultiCallbacks(PN2_Session session, PN2_StopNesting fstop, void * stop_data, PN2_MultiUpdateBest fupdate, void * update_data);

    /**
     * @brief Check if a result is the same as another
     *
     * Used to compute the multiplicity of a result in a multi-result. Two results are
     * considered identical if they contain the same PN2_Shapes, placed at the same
     * places with the same orientations on the same PN2_Sheet.
     *
     * @param session Session to which belongs both results
     * @param r1 First result to compare
     * @param r2 Second result to compare
     *
     * @return 1 if both results are identical, 0 if they are different, and a negative value if an error occurred.
     * 
     * @ingroup Result
     */
    PN2_EXPORTS PN2_Bool PN2API PN2_IsSameNesting(PN2_Session session, PN2_Result r1, PN2_Result r2);


    /**
     * @brief Runs a nesting on Alma's cloud using Powernest WS.
     *
     * https://doc.powernestlib.com/
     *
     * @param session Current session
     * @param sheets Sheets on which parts will be nested
     * @param nb_sheets Number of sheets
     * @param sheet_quantities Quantity available for each sheet
     * @param parts Parts to be nested
     * @param nb_parts Number of parts
     * @param time Maximum time that will be used by the nesting algorithm, given in seconds. Max is 300 seconds.
     * @param basic_auth Basic HTTP authentication credentials, of the following form: "user:password"
     * @param[out] error_message Error message returned by the server, if any. The array
     *             is user-provided and its size must be at least 1024.
     *
     * @return A PN2_MultiResult with parts nested on sheets or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_MultiNest() for details, the main difference is that computations are
     *      done on our servers instead of your local computer.
     *
     * @note Please note that PN2_SetSessionMultiCallbacks() is not available. The
     * maximum time which can be used is 300 seconds.
     *
     * @note The API compatible with PN2_PWSMultiNest() is limited to:
     * All PN2_Contour creation API
     * All PN2_Shape creation API
     * All PN2_Part creation API
     * All PN2_Sheet creation API
     * All PN2_Result and PN2_MultiResult "read-only" API
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_MultiResult PN2API PN2_PWSMultiNest(PN2_Session session, const PN2_Sheet * sheets,
                                                        int nb_sheets, const int * sheet_quantities,
                                                        const PN2_Part* parts, int nb_parts, double time,
                                                        const char * basic_auth, char error_message[1024]);

    /**
     * @brief Manually pre-nest parts on multiple sheets
     * 
     * Please note that this function allows parts to overlap other parts or the sheet
     * border gaps. However, orientations and positions constraints shall be
     * respected. See PN2_PreNest().
     *
     * @param session Current session
     * @param nb_sheets Number of sheets
     * @param sheets The list of sheets on which to pre-nest parts
     * @param nb_parts_on_sheets The list of number of parts on each sheet
     * @param parts The list of parts to pre-nest
     * @param ors Orientations of the parts to pre-nest
     * @param pos Positions of the parts to pre-nest
     *
     * @return A PN2_MultiResult with the parts nested on sheets at the given
     *         positions and orientations or an error code if the operation
     *         failed (see PN2_IsObjectError()).
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_MultiResult PN2API PN2_MultiPreNest(PN2_Session session, int nb_sheets, const PN2_Sheet * sheets, const int * nb_parts_on_sheets,
                                                        const PN2_Part * parts, const PN2_Orientation * ors, const PN2_Point * pos);

    /**
     * @brief Automatically complete a previous multi-nesting with more parts
     *
     * The PN2_MultiResult can come from an automatic algorithm like PN2_MultiNest() or
     * from an manual nesting like PN2_MultiPreNest(). Parts previously nested are not
     * moved. To change this behavior, see PN2_SetPreNestedGlueMode().
     *
     * @param session The session owning the sheet and parts
     * @param multi_result The previous nestings in which new parts must be added.
     * @param sheets New sheets on which parts will be nested as soon the multi-result is full
     * @param nb_sheets Number of new sheets
     * @param sheet_quantities Quantity available for each new sheet
     * @param parts The array of parts to add
     * @param nb_parts The number of parts to add
     * @param time The maximum time that will be used to optimize the nesting, given in seconds
     *
     * @return A PN2_MultiResult with parts nested on sheets or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_MultiPreNest(), PN2_MultiNest() and PN2_CompleteMultiResultWithFillerParts()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_MultiResult PN2API PN2_MultiNestMore(PN2_Session session, PN2_MultiResult multi_result, const PN2_Sheet * sheets, int nb_sheets, const int * sheet_quantities, PN2_Part * parts, int nb_parts, double time);

    /**
     * @brief Automatically complete a previous (multi-)nesting with more parts, without using the offcut
     *
     * Similar to PN2_MultiNestMore(), the only difference is that no new sheet are used
     * and the previous offcut is kept.
     *
     * @param session The session owning the sheet and parts
     * @param multi_result The previous nestings in which new parts must be added.
     * @param parts The array of parts to add
     * @param nb_parts The number of parts to add
     * @param time The maximum time that will be used to optimize the nesting, given in seconds
     * @return A PN2_MultiResult with parts nested on sheets or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_MultiPreNest(), PN2_MultiNest() and PN2_MultiNestMore()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_MultiResult PN2API PN2_CompleteMultiResultWithFillerParts(PN2_Session session, PN2_MultiResult multi_result, PN2_Part * parts, int nb_parts, double time);

    /**
     * @brief Spread out the parts from a nesting result to move them away from each
     *        other and from the borders of the sheet.
     *
     * With or without decreasing the nesting efficiency.
     *
     * This function spreads parts that still have some freedom when a
     * sheet is complete or when a nesting is finished with a given
     * front line. This is useful to improve cutting conditions for
     * instance.
     *
     * @param session Current session
     * @param result The nesting result to spread
     * @param spread_until_sheet_length If true, the algorithm is allowed to use the whole sheet.
     * @param time Maximum time given to algorithms to spread parts
     *
     * @return A PN2_Result with spread parts or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @see PN2_SpreadIgnoreBorders(), PN2_Scatter()
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_Result PN2API PN2_Spread(PN2_Session session, PN2_Result result, PN2_Bool spread_until_sheet_length, double time);

    /**
     * @brief Same as PN2_Spread() but the parts are not moved away from
     *        the borders of sheet.
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_Result PN2API PN2_SpreadIgnoreBorders(PN2_Session session, PN2_Result result, PN2_Bool spread_until_sheet_length, double time);

    /**
     * @brief Compact a nesting result in order to put the parts in contact toward a
     *        corner of the sheet.
     *
     * @param session The session owning the result
     * @param result Nesting result to compact
     * @param type the compact direction: 1 for toward bottom left, 2 for toward top left
     * @param time Max time given to the compaction
     * @return A PN2_result with parts compacted on the sheet or an error code if the
     *         operation failed (see PN2_IsObjectError()).
     *
     * @note if PN2_SetSessionOffcutSides() has been used, toward bottom left must be
     *       interpreted as away from second side away from main side and toward top left
     *       as toward second side away from main side
     *
     * @ingroup Optimization
     */
    PN2_EXPORTS PN2_Result PN2API PN2_Compact(PN2_Session session, PN2_Result result, int type, double time);

    /**
     * @brief Set a "nesting windows" for a specific PN2_Shape on a list of PN2_Sheet
     *
     * Define a rectangle inside each sheet in which the associated PN2_Part must be
     * placed. This is useful for instance in milling to avoid placing small parts on the
     * borders of the sheet where they cannot be held properly by the table. Other usages
     * include specific cutting or printing processes, manual unloading, ...
     *
     * @param session the session holding the data
     * @param shape the shape to which the window constraint must be applied (all PN2_Parts of
     *        this PN2_Shape will inherit from this constraint)
     * @param sheets list of sheets for which the constraint applies
     * @param window_bottom_lefts a list of bottom-left points of nesting windows, one per sheet
     * @param window_upper_rights a list of upper-right points of nesting windows, one per sheet
     * @param nb_sheets number of sheets in \p sheets, which is obviously also the number of points
     *        in \p window_bottom_lefts and in \p window_upper_rights
     *
     * @note If some sheets are not in the specified list of sheets, parts can be placed
     *       anywhere on those sheets.
     * 
     * @see PN2_PartSetNestingWindows() 
     *
     * @warning When pre-nesting such a part, violating the windows constraint will
     *          result in the corresponding part not beeing placed at all. The area
     *          previously taken by such parts will thus become available and other parts
     *          may be nested there. When mixing pre-nestings and nesting windows
     *          constraints, one must prefer the function PN2_PartSetNestingWindows() and
     *          not apply it to pre-nested parts.
     *
     * @ingroup Constraints
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetNestingWindows(PN2_Session session, PN2_Shape shape, PN2_Sheet * sheets,
                                                                PN2_Point * window_bottom_lefts, PN2_Point * window_upper_rights,
                                                                int nb_sheets);
    
    /**
     * @brief Set nesting windows for a specific PN2_Part on a list of PN2_Sheet
     *
     * Same as PN2_ShapeSetNestingWindows(), but applies to a specific part instead of a
     * PN2_Shape. Useful in particular with pre-nestings.
     *
     * @note If some sheets are not in the specified list of sheets, parts can be placed
     *       anywhere on those sheets.
     *
     * @ingroup Constraints
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_PartSetNestingWindows(PN2_Session session, PN2_Part part, PN2_Sheet * sheets,
                                                               PN2_Point * window_bottom_lefts, PN2_Point * window_upper_rights,
                                                               int nb_sheets);

    /**
     * @brief Force all parts made from a PN2_Shape to be nested with the same orientation
     *        (rotation of 180 degrees and/or symmetry along the x axis can be allowed).
     *
     * When the parts are bent after the cutting, setting up the bending parameters can
     * be tedious. It is possible to use a single set of bending parameters for all
     * instances of a shape if the angle the part makes with the lamination direction of
     * the sheet is always the same.
     *
     * If `allow_180_rotation` and `allow_flip` are false, all the parts will have exactly
     * the same orientation. Otherwise, we allow a 180 rotation and/or a symmetry
     * between any two parts.
     *
     * Requires the orientations of all PN2_Parts made from this shape to be identical.
     * 
     * If the PN2_Shape affected by the bending orientation constraint is sensible to the
     * rolling directions of the sheets (ie. if
     * PN2_SetShapeOrientationsAsRelativeToRollingDirection() has been or is going to be
     * called for this PN2_Shape), then the bending orientation constraints will take the
     * rolling directions of the sheets into consideration. That means that the
     * orientations of the parts of this shape nested on sheets with different rolling
     * directions will be different, but will be identical relative to the rolling
     * directions.
     *
     * @param session The session owning the sheet.
     * @param shape The shape we want to constrain.
     * @param allow_180_rotation True to allow a 180 rotation between two nested parts.
     * @param allow_flip True to allow a horizontal symmetry between two nested parts.
     *
     * If both `allow_180_rotation` and `allow_flip` are true, the additional (180, flip)
     * relative orientation between two parts is also allowed. If `allow_flip` is true,
     * Powernest2 considers that the lamination directions of the sheets are parallel
     * with either the x axis or the y axis.
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     * 
     * @see PN2_SetSheetRollingDirection() and PN2_SetShapeOrientationsAsRelative() if
     * the sheets have different lamination directions.
     *
     * @ingroup Constraints
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetSameOrientationBendingConstraint(PN2_Session session, PN2_Shape shape, PN2_Bool allow_180_rotation, PN2_Bool allow_flip);

    /**
     * @brief Associate a part to a group whose parts should be nested "close" to each other
     *
     * The part will be assigned to the order group `order_group`. Parts of an order group
     * are globally nested together on consecutive sheets. It is allowed for several
     * groups to interleave up to a maximum number of groups, defined by a call to the
     * PN2_SetMaximumInterleavedGroups() function.
     *
     * A new order group is created the first time a part is assigned to it. There is no
     * need to define the groups before assigning parts to them. The specific numbers
     * representing the order groups have no impact on the nesting, order groups having
     * higher or lower numbers will not be nested earlier or later based on this. Using
     * PN2_PartSetPriority() can be used to achieve group ordering.
     *
     * This feature is mainly used for unloading purpose. Let's say there is 10 orders
     * which must be unloaded and stored in 10 separate bins. However it is not possible
     * to have more than 4 bins around the cutting machine to unload the parts. Then
     * defining the 10 order groups along with setting PN2_SetMaximumInterleavedGroups()
     * to 4 will allow to unload flawlessly each group, stowing away completed bins and
     * replacing them with a new empty bin for the next order group.
     *
     * @param session The session owning the part.
     * @param part The part we want to add to the order group order_group.
     * @param order_group The number representing the order group to which we want to set
     *        the part. It must be a positive integer.
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     *
     * @ingroup Constraints
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_PartSetOrderGroup(PN2_Session session, PN2_Part part, int order_group);

    /**
     * @brief Set how many different order groups may be interleaved
     *
     * We define the continuous run of an order group defined by calls of
     * PN2_PartSetOrderGroup() as the set of all sheets, from the first sheet that contains
     * a part of this group up to but excluding the last sheet that contains a part of this group
     * including any gap (sheet not containing any part of this group) that may possibly
     * exist between these two. A group that is nested on a single sheet has no continuous
     * run associated with it and does not count to the maximum.
     *
     * We define the number of interleaving order groups of a sheet as the number of order
     * groups to whose continuous runs the sheet belongs.
     *
     * This function sets the maximum number of interleaving order groups of any sheet. 
     * The default value is 1.
     *
     * @param session The session for which the parameter will be set.
     * @param maximum_interleaved_groups the maximum acceptable interleaved order groups, greater or equal to 1.
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     *
     * @ingroup Constraints
     */

    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetMaximumInterleavedGroups(PN2_Session session, int maximum_interleaved_groups);


    /**
     * @brief Define a rolling direction of a sheet
     *
     * The parts whose orientations are to be considered relative to the rolling direction
     * will use an orientation relative to this rolling direction when placed on this sheet.
     *
     * All sheets have a horizontal (orientation 0 degrees) rolling direction by default.
     *
     * @param session The session owning the sheet.
     * @param sheet The sheet to which we want to attribute a rolling direction.
     * @param angle The angle of the rolling direction of this sheet on the [0,360[ range.
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     *
     * @see PN2_SetShapeOrientationsAsRelativeToRollingDirection() for setting which
     *      shapes will be affected by the rolling direction.
     *
     * @note The "Rolling Direction" name comes from the sheet-metal industry with coiled
     *       sheets. Under those conditions, the material properties might be anisotropic
     *       and the orientation constraints of PN2_Part should be relative to this
     *       rolling direction. The same logic may apply to other industries, for
     *       instance it is called "grain" for wood, "warp and weft" in textile, ...
     *
     * @ingroup Sheet
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSheetRollingDirection(PN2_Session session, PN2_Sheet sheet, double angle);

    /**
     * @brief Make the orientations of the parts of this shape relative to sheet rolling
     *        direction instead of standard sheet direction.
     *
     * Please be aware that while the allowed orientations (as accepted by PN2_AddPart()
     * and PN2_AddSeveralParts()) for this part are to be taken as relative when this
     * function is called, the orientations taken or returned by other functions are
     * absolute. More precisely, \f$AbsoluteOrientation = RollingDirection \circ
     * RelativeOrientation\f$, \f$ \circ \f$ beeing the function composition
     * https://en.wikipedia.org/wiki/Function_composition
     *
     * In particular, the following functions work with absolute orientations:
     *   - functions that define a part position and orientation such as PN2_PreNest()
     *   - all interactive functions
     *   - functions returning the results of a nesting such as PN2_GetNestedPart()
     *   - all textile functions
     *
     * @param session The session of the shape for which the parameter will be set.
     * @param shape The shape whose orientations of parts are relative to sheet rolling direction.
     *
     * @return 0 if the operation succeeded, an error code otherwise.
     *
     * @see PN2_SetSheetRollingDirection() for setting sheet rolling direction.
     *
     * @ingroup Shape
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetShapeOrientationsAsRelativeToRollingDirection(PN2_Session session, PN2_Shape shape);


    /**
     * @brief Force a particular part to be nested on specific sheets
     *
     * @param session the session holding the part and sheets
     * @param part the part which must be nested on these sheets
     * @param sheets the allowed sheets for this part
     * @param nb_sheets the number of sheets
     *
     * @return 0 in case of success, an error code otherwise.
     *
     * @ingroup Constraints
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_AssociatePartToSheets(PN2_Session session, PN2_Part part,
                                                               PN2_Sheet * sheets, int nb_sheets);


    /**
     * @brief Build a PN2_MultiResult from a set of PN2_Result
     *
     * @param session where the results belong
     * @param results, nb_results the results to concatenate, the order is kept
     *
     * @warning No verifications are done
     *
     * @return the concatenation of the result or an error if something wrong did happen
     *
     * @ingroup Result
     */
     PN2_EXPORTS PN2_MultiResult PN2API PN2_ConcatenateResults(PN2_Session session, PN2_Result * results, int nb_results);


    /**
     * @brief Set the priority on a sheet.
     *
     * Sheets with higher priorities are consumed before sheets with lower priorities.
     *
     * @param session The session holding the sheet
     * @param sheet The sheet to set the priority on
     * @param priority The desired sheet priority
     * 
     * @return 0 if the operation was successful, negative if there was some error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SheetSetPriority(PN2_Session session,
                                                          PN2_Sheet   sheet,
                                                          int         priority);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
