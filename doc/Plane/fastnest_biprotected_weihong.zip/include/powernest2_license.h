/**
* @file
* @author Alma
* @brief API for unlocking Powernest2 at run time (the license must have been activated already)
*/

#ifndef POWERNEST2_LICENSE_H_
#define POWERNEST2_LICENSE_H_

#include "powernest2.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Sets the path to the Powernest2 software license_key.
     *
     * If not used, Powernest2 will by default look for the license_key file in the path "%EXE_PATH%/license.lcs".
     * This function must be called prior to the beginning of a nesting operation (PN2_Nest(), PN2_MultiNest(), 
     * PN2_Compact(), etc...).
     *
     * @param license_key_path The path to the license file.
     * 
     * @ingroup Pn2LicenseAPI
     */
    PN2_EXPORTS void PN2API PN2_SetLicensePath(const char* license_key_path);

    /**
     * @brief Sets the address of the server that owns the Powernest2 floating license.
     *
     * This function must be called prior to the beginning of a nesting operation (PN2_Nest(), PN2_MultiNest(),
     * PN2_Compact(), etc...).
     *
     * @param server_license_contact_address The address of the server where the floating license is installed.
     * @param server_license_contact_port The port to contact the server (usual port is 5093)
     *                                    and that has been defined at license installation. 
     * @ingroup Pn2LicenseAPI
     */
    PN2_EXPORTS void PN2API PN2_SetFloatingLicenseServerInfo(const char * server_license_contact_address, int server_license_contact_port);

    /**
     * @brief Check if the provided license is valid for Powernest2.
     *
     * This function performs a license_key check (standalone license case) or contacts the license server (floating license case)
     * in order to indicate if Powernest2 is allowed to be run.
     * It may be used to check that the installation of a license has been successful.
     * 
     * @pre Before calling PN2_CheckLicense(), either PN2_SetLicensePath() or PN2_SetFloatingLicenseServerInfo()
     *      must have been called.
     *
     * This function returns an integer error_code:
     *    - If the returned value is 0, then it means that the license is valid for Powernest2.
     *    - If the returned value is non-zero, then Powernest2 will not be allowed to be run.
     *      In this case, the returned value indicates the cause of the error, accordingly to the error description below.
     * 
     * @warning The non-zero values returned by this function are not guaranteed to have their significations stable in the future.
     * The only guaranteed behaviour for this function is that a zero value means that the license is valid,
     * and that a non-zero value means that Powernest2 could not be activated.
     * 
     * The current possible return values for this function are the following:
     *    - 0    -> No error, Powernest2 is allowed to be run.
     *    - 8    -> (Floating only) the floating license is valid, but no token is currently available.
     *    - 12   -> (Floating only) the license server could not be reached.
     *              Possible causes are an erroneous address or port, or that the Sentinel RMS service is not running.
     *    - 13   -> No valid license has been found. Possible reasons are that the wrong license_key file has been given to PN2_SetLicenseFile(),
     *              or that the file has been corrupted or does not exist, or that the license has not been properly installed,
     *              or that the computer has not been recognized...
     *    - 21   -> (Floating only) The floating server information is invalid (for example, unresolved address or wrong port).
     *    - 33   -> The license used to be valid for this computer but is has expired.
     *    - 1000 -> Unexpected error: no information about this error, please contact the Powernest2 support.
     * 
     * @ingroup Pn2LicenseAPI
     */
    PN2_EXPORTS int PN2API PN2_CheckLicense();



/// @cond DEPRECATED_FUNCTIONS

/**
* Below is the deprecated API for handling software licenses.
* One should rather use the AlmaSoftwareLicense API (alma_software_license.h).
* 
* This header provides the functions one can use to install, uninstall and use the software protection within Powernest2.
* When Powernest2 is protected by software licenses, one must first install the license on the computer that will use it,
* before executing any nesting optimization.
* 
* The first thing to do on any computer that may receive a Powernest2 license now or in the future is to initialize the 
* software protection context with PN2_InitializeLicenseContext(). It must only be done once in the lifetime of the computer.
* 
* When one has completed an order for Powernest2 licenses, one will receive 1 NDV file per license ordered. The NDV file
* roughly represents the unique ID of the license. The installation process is then as follows:
* - 1. (C)  Generate a machine imprint file with PN2_GenerateMachineImprint().
* - 2. (@)  Register the NDV file with the machine imprint file with PN2_RegisterLicense(). It will generate an installable license file.
* - 3. (C)  Install the license with PN2_InstallStandaloneLicense(). It will generate the actual license file.
*
* The Powernest2 software license is now installed. The only license-related action to perform on a regular basis is to tell Powernest2 
* where the license file generated on step 3 is, with PN2_SetLicensePath().
*
* If one wants to change the computer that can use Powernest2, one must uninstall the license from the computer that will no 
* more use it, and install it on the new one. The uninstallation process is as follows:
* - I.   (@) Generate an uninstallation request file for an NDV license file with PN2_GenerateUninstallationRequest().
* - II.  (C) Uninstall the license with PN2_UninstallStandaloneLicense(). It will generate an uninstallation confirmation file.
* - III. (@) Upload the uninstallation confirmation file with PN2_UploadUninstallationConfirmation().
*
* After step III. is complete, the license represented by the NDV file is now available again for installation. One can just go
* through steps 1. to 3. to install the license on another computer.
*
* - @: Operations that require an internet connection.
* - C: Operations that must be done on the computer that uses Powernest2.
* 
* The process described above is for standalone licenses.
* Floating licenses may be installed and uninstalled in a similar way, with the following changes:
* - Installation and uninstallation must take place on a computer (the "server") on which Sentinel RMS License Manager service is running.
* - In step 3., PN2_InstallFloatingLicense() should be used instead of PN2_InstallStandaloneLicense().
* - In step II., PN2_UninstallFloatingLicense() should be used instead of PN2_UninstallStandaloneLicense().
* - The computer that will run Powernest2 needs to have access to the server, and PN2_SetFloatingLicenseServerInfo()
*   should be used instead of PN2_SetLicensePath().
* 
* @note The Powernest2 software license can be installed/uninstalled on a computer that has no internet connection. To do so, one 
* must transfer files generated from the offline computer on steps 1. and II. to a computer that has an internet connection, and 
* files generated from the online computer on steps 2. and I. to the offline computer.
*
* There are three types of licenses :
* i)    Licenses limited by a number of days : This license will be valid for a predefined number of days after its installation
* ii)   Licenses with an expiration date : This license will be valid up to its expiration date, independently of when it is installed
* iii)  Unlimited licenses : Once installed, this license will be valid indefinitely
*
* Please observe that licenses of type "Licenses limited by a number of days" cannot be uninstalled, and therefore cannot be
* installed later on another computer.
*/

    /**
     * @brief Sets the timeout for the functions that require an internet connection.
     *
     * If not used, the default value is 30 seconds. If the value is negative, the default value is set instead.
     *
     * @param timeout_in_seconds The timeout in seconds for the HTTP requests.
     */
    PN2_EXPORTS void PN2API PN2_SetLicenseFunctionsTimeout(int timeout_in_seconds);

    /**
     * @brief Sets the proxy information for the functions that require an internet connection.
     *
     * If not used, Powernest will try to automatically detect the proxy information from the computer's settings.
     *
     * @param proxy_address The address of the proxy.
     * @param server_port The port of the proxy.
     */
    PN2_EXPORTS void PN2API PN2_SetLicenseFunctionsProxy(const char* proxy_address, int server_port);

    /**
     * @brief Resets the proxy information for the functions that require an internet connection.
     *
     * If PN2_SetLicenseFunctionsProxy() has been used before, this function reset this information to the default
     * one, where Powernest2 tries to automatically detect the information.
     */
    PN2_EXPORTS void PN2API PN2_ResetLicenseFunctionsProxy();

    /**
     * @brief Licenses states
     */
    typedef enum
    {
        LICENSE_AVAILABLE = 0,       ///< License is available.
        LICENSE_FULLY_INSTALLED = 1, ///< License is fully installed.
        LICENSE_IN_REVOCATION = 4,   ///< License is in revocation.
        LICENSE_EXPIRED = 5          ///< license is expired.
    } PN2_LICENSE_STATE;

    /**
     * @brief Gets the current state of the license.
     * 
     * This is the state of the license according to our license server. It only changes when network-related
     * functions are called. 
     * The base state is LICENSE_AVAILABLE. After PN2_RegisterLicense() is called, the state changes to LICENSE_FULLY_INSTALLED.
     * Then, when PN2_GenerateUninstallationRequest() is called, the state changes to LICENSE_IN_REVOCATION.
     * It goes back to LICENSE_AVAILABLE after a successful call to PN2_UploadUninstallationConfirmation().
     * 
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param[out] license_out_state location where to store the state of the license. 
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetLicenseState(const char * ndv_filepath, PN2_LICENSE_STATE * license_out_state);

    /**
     * @brief Tells if the license is installed on the machine with the given imprint.
     *
     * It compares the given machine imprint with the one that has been registered on 
     * our license server after a call to PN2_RegisterLicense().
     * 
     * Generating a machine imprint can differ if one has admin privileges or not.
     * If the given machine imprint has been generated differently than during the installation, this function
     * will return false, even if the license is actually installed on this computer.
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param machine_imprint_filepath The path to the file containing information
     *                                 about the computer where the license is potentially installed.
     * @param[out] is_license_installed_out location where to store the result.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_IsLicenseInstalledOnMachine(const char * ndv_filepath, const char * machine_imprint_filepath, PN2_Bool * is_license_installed_out);

    /**
     * @brief Gets the expiration date of the license.
     *
     * This is the expiration date according to our license server. The string representation of the date
     * follows the ISO 8601 standard:
     *   - Licenses limited by a number of days: returns a duration string (e.g. "P60D" for "60 days").
     *   - Licenses with an expiration date: returns a date string (e.g. "2020-02-08" for "February 8th 2020").
     *   - Unlimited licenses: returns a date string with value "2500-12-31".
     *
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param[out] expiration_date_out Expiration date.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetLicenseExpirationDate(const char * ndv_filepath, char expiration_date_out[64]);

    /**
     * @brief Gets the expiration date of the installed license.
     *
     * This is the expiration date set in the installed license file. The string representation of the date
     * follows the ISO 8601 standard ("yyyy-mm-dd"). If more than one license is present in the license file,
     * the latest date is returned. If the license file contains an unlimited license, the date "2500-12-31"
     * is returned. If the license file represents a license limited by a number of days, it returns the
     * end date that has been computed from the installation date.
     *
     * @param license_filepath The path to the installed license file.
     * @param[out] expiration_date_out Expiration date.
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetInstalledLicenseExpirationDate(const char * license_filepath, char expiration_date_out[64]);

    /**
     * @brief Initializes the software license context on the computer.
     * One must have admin privileges to run this function. It initializes private structures and documents
     *
     * for software license handling. This function should only be called once in the lifetime of a computer. 
     * Once it has been called, no other function requires admin privileges anymore (in particular 
     * PN2_InstallStandaloneLicense() and PN2_UninstallStandaloneLicense()). 
     *
     * This function helps integrators of Powernest2 to keep the need for admin privileges to the bare minimum.
     * Generally, this function will be called when installing the software in which Powernest2 is embedded. As a consequence,
     * if the user only gets a Powernest2 license later on, he will be able to install it without the software asking for 
     * admin privileges (that would else be needed in PN2_InstallStandaloneLicense()). 
     *
     * @pre One must have admin privileges to run this function.
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_InitializeLicenseContext();

    /**
     * @brief Writes the file containing local computer information, needed to link a Powernest2 software license with a computer.
     *
     * This function creates a file that represent the computer. This should be created on the computer where the
     * license is to be installed.
     *
     * @param machine_imprint_out_filepath The full path of the resulting machine imprint file. 
     *                                     The file extension is up to the user.
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GenerateMachineImprint(const char * machine_imprint_out_filepath);

    /**
     * @brief Links a Powernest2 software license with a specific computer, and download the resulting installable license.
     *
     * In order to have the license available, the resulting installable license needs to be actually installed
     * on the target computer with PN2_InstallStandaloneLicense().
     *
     * @param machine_imprint_filepath The path to the file containing information
     *                                 about the computer where the license is to be installed.
     * @param ndv_filepath The path to the NDV file (containing the id of the license).
     * @param installable_license_out_filepath The full path of the resulting installable license file.
     *                                         The file extension is up to the user.
     * @return An error code, or 0 if there was no error.
     * @note This function requires an internet connection in order to succeed.
     * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
     * @note A license that is already installed on a computer (even only partially) cannot be installed elsewhere.
     *       You will need to uninstall it before. To uninstall a license, see the following functions:
     *       PN2_GenerateUninstallationRequest(), PN2_UninstallStandaloneLicense(), PN2_UploadUninstallationConfirmation().
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_RegisterLicense(const char * machine_imprint_filepath,
                                                         const char * ndv_filepath,
                                                         const char * installable_license_out_filepath);
     /**
     * @brief Installs a standalone license on a computer.
     * 
     * If PN2_InitializeLicenseContext() has never been called prior to this function, then one may need 
     * admin privileges to run it (depending on the license type).
     *
     * After completing the installation, one can check if the license is properly installed and 
     * seen by Powernest2, by calling first PN2_SetLicensePath() to tell it where to look for 
     * the license, and then by calling PN2_CheckDetectedExe() (in powernest2.h).
     * 
     * @param installable_license_filepath The path to the installable license file.
     * @param license_out_filepath The full path of the resulting license file.
     *                             The file extension is up to the user.
     * @pre Admin privileges may be required only if PN2_InitializeLicenseContext() has never been run before.
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_InstallStandaloneLicense(const char * installable_license_filepath,
                                                                  const char * license_out_filepath);

    /**
    * @brief Installs a floating license on a computer (the "server") .
    *
    * If PN2_InitializeLicenseContext() has never been called on the server prior to this function,
    * then one may need admin privileges to run it (depending on the license type).
    *
    * After completing the installation, one can check if the license is properly installed and
    * seen by Powernest2, by calling first PN2_SetFloatingLicenseServerInfo(),
    * and then by calling PN2_CheckDetectedExe() (in powernest2.h).
    *
    * @param installable_license_filepath The path to the installable license file.
    * @param license_server_contact_port  The port number to contact the Sentinel RMS License Manager service service.
    *                                     By default, the port is 5093 but it may be different in some specific cases.
    * 
    * @pre Admin privileges may be required only if PN2_InitializeLicenseContext() has never been run before.
    * @return An error code, or 0 if there was no error.
    */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_InstallFloatingLicense(const char * installable_license_filepath,
                                                                const int license_server_contact_port);

    /**
    * @brief Marks the license as being in revocation and generate an uninstallation request.
    * @param ndv_filepath The path to the NDV file (containing the id of the license).
    * @param request_out_filepath The full path of the resulting uninstallation request file.
    *                             The file extension is up to the user.
    * @return An error code, or 0 if there was no error.
    * @note This function requires an internet connection in order to succeed.
    * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
    * @note This function requires the license to be installed (partially or not) on a computer in order to succeed.
    */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GenerateUninstallationRequest(const char * ndv_filepath,
                                                                       const char * request_out_filepath);

    /**
     * @brief Uninstalls the standalone license from the computer and generates an uninstallation confirmation.
     * 
     * If PN2_InitializeLicenseContext() has never been called prior to this function, then one may need
     * admin privileges to run it (depending on the license type).
     *
     * Prior to reaching this function, one may have deleted the license file corresponding to the uninstallation 
     * request (the one linked to the ndv used in PN2_GenerateUninstallationRequest()). If this happens, one just needs to re-install
     * the license before uninstalling it. It can be done by re-doing step(s) 3, 2-3, or 1-2-3 depending on the remaining available files 
     * at that time.
     * 
     * @param uninstallation_request_filepath The path to the uninstallation request file.
     * @param license_filepath The path to the installed license file.
     * @param uninstallation_confirmation_out_filepath The full path of the resulting uninstallation confirmation file.
     *                                                 The file extension is up to the user.
     * @pre Admin privileges may be required only if PN2_InitializeLicenseContext() has never been run before.
     * @return An error code, or 0 if there was no error.
     * @note If the machine imprint file used to install this license had been generated by 
     *       a user with admin privileges (when calling PN2_GenerateMachineImprint()), then this
     *       function may have some trouble uninstalling it without admin privileges. In such case,
     *       it could return an error about the machine information not being the one linked with the
     *       license (error -968). If such error happens, and one knows it is the right computer, then 
     *       one can try to run again this function with admin privileges.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_UninstallStandaloneLicense(const char * uninstallation_request_filepath, 
                                                                    const char * license_filepath,
                                                                    const char * uninstallation_confirmation_out_filepath);
    /**
     * @brief Same as PN2_UninstallStandaloneLicense() but for a floating license.
     *
     * See PN2_UninstallStandaloneLicense() description for exhaustive documentation.
     *
     * @param uninstallation_request_filepath The path to the uninstallation request file.
     * @param license_server_contact_port The port number to contact the Sentinel RMS License Manager service service.
    *                                     By default, the port is 5093 but it may be different in some specific cases.
     * @param uninstallation_confirmation_out_filepath The full path of the resulting uninstallation confirmation file.
     *                                                 The file extension is up to the user.
     * 
     * @pre Admin privileges may be required only if PN2_InitializeLicenseContext() has never been run before.
     * @return An error code, or 0 if there was no error.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_UninstallFloatingLicense(const char * uninstallation_request_filepath,
                                                                  const int license_server_contact_port,
                                                                  const char * uninstallation_confirmation_out_filepath);

    /**
    * @brief Uploads the revocation confirmation in order the make the license available again.
    * @param uninstallation_confirmation_filepath The path to the uninstallation confirmation file.
    * @return An error code, or 0 if there was no error.
    * @note This function requires an internet connection in order to succeed.
    * @note This function returns a timeout error if the HTTP request has not returned after the time set by PN2_SetLicenseFunctionsTimeout().
    */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_UploadUninstallationConfirmation(const char * uninstallation_confirmation_filepath);

    /// @endcond
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

