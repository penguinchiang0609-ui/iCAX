/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Powernest", "index.html", [
    [ "Getting started", "index.html", "index" ],
    [ "Examples", "pn_examples.html", "pn_examples" ],
    [ "Powernest software license", "software_license.html", [
      [ "Integrating a cloud version", "software_license.html#autotoc_md4", null ],
      [ "Integrating an offline version", "software_license.html#autotoc_md5", null ]
    ] ],
    [ "Troubleshooting Powernest", "report_issues.html", [
      [ "Invalid Powernest result", "report_issues.html#autotoc_md6", null ],
      [ "Issues related to software licenses", "report_issues.html#autotoc_md7", null ]
    ] ],
    [ "Benchmarking nesting software", "benchmark.html", [
      [ "Example of a benchmark", "benchmark.html#autotoc_md11", null ]
    ] ],
    [ "Frequently Asked Questions", "faq.html", [
      [ "Should I expect breaking changes in the API?", "faq.html#autotoc_md12", null ],
      [ "There is some requirements Powernest does not meet.", "faq.html#autotoc_md13", null ],
      [ "How much computing time should I use?", "faq.html#autotoc_md14", null ],
      [ "How much RAM should my computer have?", "faq.html#autotoc_md15", null ],
      [ "Is there any limits on the part quantities/complexity?", "faq.html#autotoc_md16", null ],
      [ "Is it possible to import DXF files into Powernest?", "faq.html#autotoc_md17", null ],
      [ "How can I integrate Powernest with another language?", "faq.html#autotoc_md18", null ],
      [ "Can I interrupt Powernest when a result is good enough?", "faq.html#autotoc_md19", null ],
      [ "Why do I get different results when running a job twice?", "faq.html#autotoc_md20", null ],
      [ "Why a result is worse when using more resources?", "faq.html#autotoc_md21", null ],
      [ "Are Visual C++ Redistributable necessary?", "faq.html#autotoc_md22", null ],
      [ "How can I define priorities on Sheets?", "faq.html#autotoc_md23", null ],
      [ "How can I obtain the material efficiency of a result?", "faq.html#autotoc_md24", null ],
      [ "How can I represent arcs (bulges, sagitta)?", "faq.html#autotoc_md25", null ]
    ] ],
    [ "Topics", "topics.html", "topics" ],
    [ "Index", "files.html", [
      [ "Headers", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"alma__software__license_8h.html",
"powernest2__dongle_8h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';