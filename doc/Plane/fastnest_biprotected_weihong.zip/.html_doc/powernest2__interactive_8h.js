var powernest2__interactive_8h =
[
    [ "PN2I_Nesting", "powernest2__interactive_8h.html#a7485ae11ca1dbf5b7ed862c8d1872a5c", null ],
    [ "PN2I_CreateNesting", "powernest2__interactive_8h.html#a55f47f81864480a84ca40b6fda4775ef", null ],
    [ "PN2I_DeleteNesting", "powernest2__interactive_8h.html#a533039f1b4f64108edb62fea2c87d6c1", null ],
    [ "PN2I_NestPart", "powernest2__interactive_8h.html#a5c634749e16f75d828fe8d9a51cbbe94", null ],
    [ "PN2I_NestParts", "powernest2__interactive_8h.html#adc763eedbafc7afd31831884d927c4d6", null ],
    [ "PN2I_RemovePart", "powernest2__interactive_8h.html#a799fab636828183470b0fcf62409c2bc", null ],
    [ "PN2I_RemoveParts", "powernest2__interactive_8h.html#ac195cb792b4b3ee2aa9bed2cf36e5fcc", null ],
    [ "PN2I_TryNestPart", "powernest2__interactive_8h.html#ae3db13a3802d9836c6a0301da83455fc", null ],
    [ "PN2I_TryNestPartAround", "powernest2__interactive_8h.html#a7720db02ae4f117525e5a8444d0cb667", null ],
    [ "PN2I_TrySqueezePart", "powernest2__interactive_8h.html#a0eb33bb70381a5d986f3419c541390ab", null ],
    [ "PN2I_DrawSvg", "powernest2__interactive_8h.html#a0cf3487dcf14b20e76a3c8bc0d925ec6", null ]
];