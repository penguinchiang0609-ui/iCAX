var searchData=
[
  ['data_0',['A benchmark should use representative data.',['../benchmark.html#autotoc_md8',1,'']]],
  ['define_20priorities_20on_20sheets_1',['How can I define priorities on Sheets?',['../faq.html#autotoc_md23',1,'']]],
  ['different_20results_20when_20running_20a_20job_20twice_2',['Why do I get different results when running a job twice?',['../faq.html#autotoc_md20',1,'']]],
  ['do_20i_20get_20different_20results_20when_20running_20a_20job_20twice_3',['Why do I get different results when running a job twice?',['../faq.html#autotoc_md20',1,'']]],
  ['does_20not_20meet_4',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['dxf_20files_20into_20powernest_5',['Is it possible to import DXF files into Powernest?',['../faq.html#autotoc_md17',1,'']]]
];
