var searchData=
[
  ['be_20run_20multiple_20times_0',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['benchmark_1',['Example of a benchmark',['../benchmark.html#autotoc_md11',1,'']]],
  ['benchmark_20should_20be_20run_20multiple_20times_2',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['benchmark_20should_20have_20a_20sufficiently_20large_20number_20of_20jobs_3',['A benchmark should have a sufficiently large number of jobs.',['../benchmark.html#autotoc_md9',1,'']]],
  ['benchmark_20should_20use_20representative_20data_4',['A benchmark should use representative data.',['../benchmark.html#autotoc_md8',1,'']]],
  ['benchmarking_20nesting_20software_5',['Benchmarking nesting software',['../benchmark.html',1,'']]],
  ['breaking_20changes_20in_20the_20api_6',['Should I expect breaking changes in the API?',['../faq.html#autotoc_md12',1,'']]],
  ['bulges_20sagitta_7',['How can I represent arcs (bulges, sagitta)?',['../faq.html#autotoc_md25',1,'']]]
];
