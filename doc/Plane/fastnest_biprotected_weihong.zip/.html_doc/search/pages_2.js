var searchData=
[
  ['example_0',['example',['../pn_example_hello_world.html',1,'Hello world example'],['../pn_example_orientations.html',1,'Orientations example'],['../pn_example_protections.html',1,'Protections example'],['../pn_example_user_warnings.html',1,'User warnings example']]],
  ['examples_1',['Examples',['../pn_examples.html',1,'']]]
];
