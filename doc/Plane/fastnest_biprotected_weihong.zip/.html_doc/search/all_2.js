var searchData=
[
  ['c_20redistributable_20necessary_0',['Are Visual C++ Redistributable necessary?',['../faq.html#autotoc_md22',1,'']]],
  ['callbacks_1',['Callbacks',['../group___callbacks.html',1,'']]],
  ['can_20i_20define_20priorities_20on_20sheets_2',['How can I define priorities on Sheets?',['../faq.html#autotoc_md23',1,'']]],
  ['can_20i_20integrate_20powernest_20with_20another_20language_3',['How can I integrate Powernest with another language?',['../faq.html#autotoc_md18',1,'']]],
  ['can_20i_20interrupt_20powernest_20when_20a_20result_20is_20good_20enough_4',['Can I interrupt Powernest when a result is good enough?',['../faq.html#autotoc_md19',1,'']]],
  ['can_20i_20obtain_20the_20material_20efficiency_20of_20a_20result_5',['How can I obtain the material efficiency of a result?',['../faq.html#autotoc_md24',1,'']]],
  ['can_20i_20represent_20arcs_20bulges_20sagitta_6',['How can I represent arcs (bulges, sagitta)?',['../faq.html#autotoc_md25',1,'']]],
  ['changes_20in_20the_20api_7',['Should I expect breaking changes in the API?',['../faq.html#autotoc_md12',1,'']]],
  ['characteristics_8',['License characteristics',['../group___asl_u_m.html#LC',1,'']]],
  ['cloud_20version_9',['Integrating a cloud version',['../software_license.html#autotoc_md4',1,'']]],
  ['common_20line_20cutting_10',['Common-Line Cutting',['../group___common_cut.html',1,'']]],
  ['complexity_11',['Is there any limits on the part quantities/complexity?',['../faq.html#autotoc_md16',1,'']]],
  ['computer_20have_12',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]],
  ['computing_20time_20should_20i_20use_13',['How much computing time should I use?',['../faq.html#autotoc_md14',1,'']]],
  ['concepts_14',['Core concepts',['../index.html#autotoc_md2',1,'']]],
  ['concepts_3a_15',['Glossary and concepts:',['../group___asl_u_m.html#Glossary',1,'']]],
  ['constraints_16',['Constraints',['../group___constraints.html',1,'']]],
  ['content_17',['Library content',['../group___asl_lib.html#AslLC',1,'']]],
  ['contour_18',['Contour',['../group___contour.html',1,'']]],
  ['core_20concepts_19',['Core concepts',['../index.html#autotoc_md2',1,'']]],
  ['cutting_20',['Cutting',['../group___common_cut.html',1,'Common-Line Cutting'],['../group___multi_heads.html',1,'Multi-Heads Cutting']]]
];
