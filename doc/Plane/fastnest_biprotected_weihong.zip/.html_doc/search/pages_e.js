var searchData=
[
  ['warnings_20example_0',['User warnings example',['../pn_example_user_warnings.html',1,'pn_examples']]],
  ['world_20example_1',['Hello world example',['../pn_example_hello_world.html',1,'pn_examples']]]
];
