var searchData=
[
  ['the_20api_0',['Should I expect breaking changes in the API?',['../faq.html#autotoc_md12',1,'']]],
  ['the_20material_20efficiency_20of_20a_20result_1',['How can I obtain the material efficiency of a result?',['../faq.html#autotoc_md24',1,'']]],
  ['the_20part_20quantities_20complexity_2',['Is there any limits on the part quantities/complexity?',['../faq.html#autotoc_md16',1,'']]],
  ['there_20any_20limits_20on_20the_20part_20quantities_20complexity_3',['Is there any limits on the part quantities/complexity?',['../faq.html#autotoc_md16',1,'']]],
  ['there_20is_20some_20requirements_20powernest_20does_20not_20meet_4',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['time_20should_20i_20use_5',['How much computing time should I use?',['../faq.html#autotoc_md14',1,'']]],
  ['times_6',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['to_20import_20dxf_20files_20into_20powernest_7',['Is it possible to import DXF files into Powernest?',['../faq.html#autotoc_md17',1,'']]],
  ['to_20software_20licenses_8',['Issues related to software licenses',['../report_issues.html#autotoc_md7',1,'']]],
  ['troubleshooting_9',['Troubleshooting',['../group___troubleshooting.html',1,'']]],
  ['troubleshooting_20powernest_10',['Troubleshooting Powernest',['../report_issues.html',1,'']]],
  ['tutorial_11',['ASL Tutorial',['../group___asl_lib.html#AslTuto',1,'']]],
  ['twice_12',['Why do I get different results when running a job twice?',['../faq.html#autotoc_md20',1,'']]]
];
