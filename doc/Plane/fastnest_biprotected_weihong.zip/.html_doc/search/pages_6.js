var searchData=
[
  ['license_0',['Powernest software license',['../software_license.html',1,'']]]
];
