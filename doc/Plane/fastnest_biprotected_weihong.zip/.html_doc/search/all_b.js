var searchData=
[
  ['manual_0',['ASL User manual',['../group___asl_u_m.html',1,'']]],
  ['material_1',['Material',['../index.html#autotoc_md0',1,'']]],
  ['material_20efficiency_20of_20a_20result_2',['How can I obtain the material efficiency of a result?',['../faq.html#autotoc_md24',1,'']]],
  ['meet_3',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['more_20resources_4',['Why a result is worse when using more resources?',['../faq.html#autotoc_md21',1,'']]],
  ['much_20computing_20time_20should_20i_20use_5',['How much computing time should I use?',['../faq.html#autotoc_md14',1,'']]],
  ['much_20ram_20should_20my_20computer_20have_6',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]],
  ['multi_20heads_20cutting_7',['Multi-Heads Cutting',['../group___multi_heads.html',1,'']]],
  ['multiple_20times_8',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['my_20computer_20have_9',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]]
];
