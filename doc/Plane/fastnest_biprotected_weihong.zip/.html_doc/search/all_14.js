var searchData=
[
  ['version_0',['version',['../software_license.html#autotoc_md4',1,'Integrating a cloud version'],['../software_license.html#autotoc_md5',1,'Integrating an offline version']]],
  ['visual_20c_20redistributable_20necessary_1',['Are Visual C++ Redistributable necessary?',['../faq.html#autotoc_md22',1,'']]]
];
