var searchData=
[
  ['sagitta_0',['How can I represent arcs (bulges, sagitta)?',['../faq.html#autotoc_md25',1,'']]],
  ['session_1',['Session',['../group___session.html',1,'']]],
  ['shape_2',['Shape',['../group___shape.html',1,'']]],
  ['sheet_3',['Sheet',['../group___sheet.html',1,'']]],
  ['sheets_4',['How can I define priorities on Sheets?',['../faq.html#autotoc_md23',1,'']]],
  ['should_20be_20run_20multiple_20times_5',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['should_20have_20a_20sufficiently_20large_20number_20of_20jobs_6',['A benchmark should have a sufficiently large number of jobs.',['../benchmark.html#autotoc_md9',1,'']]],
  ['should_20i_20expect_20breaking_20changes_20in_20the_20api_7',['Should I expect breaking changes in the API?',['../faq.html#autotoc_md12',1,'']]],
  ['should_20i_20use_8',['How much computing time should I use?',['../faq.html#autotoc_md14',1,'']]],
  ['should_20my_20computer_20have_9',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]],
  ['should_20use_20representative_20data_10',['A benchmark should use representative data.',['../benchmark.html#autotoc_md8',1,'']]],
  ['software_11',['Benchmarking nesting software',['../benchmark.html',1,'']]],
  ['software_20license_12',['Powernest software license',['../software_license.html',1,'']]],
  ['software_20licenses_13',['Issues related to software licenses',['../report_issues.html#autotoc_md7',1,'']]],
  ['some_20requirements_20powernest_20does_20not_20meet_14',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['start_20instructions_20for_20registering_20installing_20or_20unregistering_20a_20license_3a_15',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]],
  ['started_16',['Getting started',['../index.html',1,'']]],
  ['steps_17',['Next steps',['../index.html#autotoc_md3',1,'']]],
  ['sufficiently_20large_20number_20of_20jobs_18',['A benchmark should have a sufficiently large number of jobs.',['../benchmark.html#autotoc_md9',1,'']]]
];
