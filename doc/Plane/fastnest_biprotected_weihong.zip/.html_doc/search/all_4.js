var searchData=
[
  ['efficiency_20of_20a_20result_0',['How can I obtain the material efficiency of a result?',['../faq.html#autotoc_md24',1,'']]],
  ['enough_1',['Can I interrupt Powernest when a result is good enough?',['../faq.html#autotoc_md19',1,'']]],
  ['example_2',['example',['../pn_example_hello_world.html',1,'Hello world example'],['../pn_example_orientations.html',1,'Orientations example'],['../pn_example_protections.html',1,'Protections example'],['../pn_example_user_warnings.html',1,'User warnings example']]],
  ['example_20of_20a_20benchmark_3',['Example of a benchmark',['../benchmark.html#autotoc_md11',1,'']]],
  ['examples_4',['Examples',['../group___asl_lib.html#AslExamples',1,'ASL Examples'],['../pn_examples.html',1,'Examples']]],
  ['expect_20breaking_20changes_20in_20the_20api_5',['Should I expect breaking changes in the API?',['../faq.html#autotoc_md12',1,'']]]
];
