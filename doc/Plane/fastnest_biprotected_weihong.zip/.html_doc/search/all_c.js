var searchData=
[
  ['necessary_0',['Are Visual C++ Redistributable necessary?',['../faq.html#autotoc_md22',1,'']]],
  ['nesting_20software_1',['Benchmarking nesting software',['../benchmark.html',1,'']]],
  ['never_5fglue_2',['NEVER_GLUE',['../group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caeaeaaa3f8917316d4e4351401670a3c5f5',1,'powernest2.h']]],
  ['next_20steps_3',['Next steps',['../index.html#autotoc_md3',1,'']]],
  ['not_20meet_4',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['number_20of_20jobs_5',['A benchmark should have a sufficiently large number of jobs.',['../benchmark.html#autotoc_md9',1,'']]]
];
