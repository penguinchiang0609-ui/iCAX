var searchData=
[
  ['ram_20should_20my_20computer_20have_0',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]],
  ['redistributable_20necessary_1',['Are Visual C++ Redistributable necessary?',['../faq.html#autotoc_md22',1,'']]],
  ['registering_20installing_20or_20unregistering_20a_20license_3a_2',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]],
  ['related_20to_20software_20licenses_3',['Issues related to software licenses',['../report_issues.html#autotoc_md7',1,'']]],
  ['represent_20arcs_20bulges_20sagitta_4',['How can I represent arcs (bulges, sagitta)?',['../faq.html#autotoc_md25',1,'']]],
  ['representative_20data_5',['A benchmark should use representative data.',['../benchmark.html#autotoc_md8',1,'']]],
  ['requirements_20powernest_20does_20not_20meet_6',['There is some requirements Powernest does not meet.',['../faq.html#autotoc_md13',1,'']]],
  ['resources_7',['Why a result is worse when using more resources?',['../faq.html#autotoc_md21',1,'']]],
  ['result_8',['Result',['../group___result.html',1,'']]],
  ['result_9',['result',['../faq.html#autotoc_md24',1,'How can I obtain the material efficiency of a result?'],['../report_issues.html#autotoc_md6',1,'Invalid Powernest result']]],
  ['result_20is_20good_20enough_10',['Can I interrupt Powernest when a result is good enough?',['../faq.html#autotoc_md19',1,'']]],
  ['result_20is_20worse_20when_20using_20more_20resources_11',['Why a result is worse when using more resources?',['../faq.html#autotoc_md21',1,'']]],
  ['results_20when_20running_20a_20job_20twice_12',['Why do I get different results when running a job twice?',['../faq.html#autotoc_md20',1,'']]],
  ['run_20multiple_20times_13',['A benchmark should be run multiple times.',['../benchmark.html#autotoc_md10',1,'']]],
  ['running_20a_20job_20twice_14',['Why do I get different results when running a job twice?',['../faq.html#autotoc_md20',1,'']]]
];
