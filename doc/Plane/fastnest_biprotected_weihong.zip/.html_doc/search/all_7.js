var searchData=
[
  ['have_0',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]],
  ['have_20a_20sufficiently_20large_20number_20of_20jobs_1',['A benchmark should have a sufficiently large number of jobs.',['../benchmark.html#autotoc_md9',1,'']]],
  ['heads_20cutting_2',['Multi-Heads Cutting',['../group___multi_heads.html',1,'']]],
  ['hello_20world_20example_3',['Hello world example',['../pn_example_hello_world.html',1,'pn_examples']]],
  ['how_20can_20i_20define_20priorities_20on_20sheets_4',['How can I define priorities on Sheets?',['../faq.html#autotoc_md23',1,'']]],
  ['how_20can_20i_20integrate_20powernest_20with_20another_20language_5',['How can I integrate Powernest with another language?',['../faq.html#autotoc_md18',1,'']]],
  ['how_20can_20i_20obtain_20the_20material_20efficiency_20of_20a_20result_6',['How can I obtain the material efficiency of a result?',['../faq.html#autotoc_md24',1,'']]],
  ['how_20can_20i_20represent_20arcs_20bulges_20sagitta_7',['How can I represent arcs (bulges, sagitta)?',['../faq.html#autotoc_md25',1,'']]],
  ['how_20much_20computing_20time_20should_20i_20use_8',['How much computing time should I use?',['../faq.html#autotoc_md14',1,'']]],
  ['how_20much_20ram_20should_20my_20computer_20have_9',['How much RAM should my computer have?',['../faq.html#autotoc_md15',1,'']]]
];
