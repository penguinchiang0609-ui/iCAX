var index =
[
    [ "Material", "index.html#autotoc_md0", null ],
    [ "Philosophy", "index.html#autotoc_md1", null ],
    [ "Core concepts", "index.html#autotoc_md2", null ],
    [ "Next steps", "index.html#autotoc_md3", null ]
];