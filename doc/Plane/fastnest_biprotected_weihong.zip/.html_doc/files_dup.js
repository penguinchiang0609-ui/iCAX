var files_dup =
[
    [ "alma_software_license.h", "alma__software__license_8h.html", "alma__software__license_8h" ],
    [ "powernest2.h", "powernest2_8h.html", "powernest2_8h" ],
    [ "powernest2_common_cut.h", "powernest2__common__cut_8h.html", "powernest2__common__cut_8h" ],
    [ "powernest2_dongle.h", "powernest2__dongle_8h.html", "powernest2__dongle_8h" ],
    [ "powernest2_interactive.h", "powernest2__interactive_8h.html", "powernest2__interactive_8h" ],
    [ "powernest2_l_offcut.h", "powernest2__l__offcut_8h.html", "powernest2__l__offcut_8h" ],
    [ "powernest2_license.h", "powernest2__license_8h.html", "powernest2__license_8h" ],
    [ "powernest2_metal.h", "powernest2__metal_8h.html", "powernest2__metal_8h" ],
    [ "powernest2_multiheads.h", "powernest2__multiheads_8h.html", "powernest2__multiheads_8h" ],
    [ "powernest2_objective.h", "powernest2__objective_8h.html", "powernest2__objective_8h" ],
    [ "powernest2_user_warnings.h", "powernest2__user__warnings_8h.html", "powernest2__user__warnings_8h" ]
];