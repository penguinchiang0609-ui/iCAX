var group___objectives =
[
    [ "PN2_SIDE", "group___objectives.html#ga48937953dd3fa17e750a5e3af58b73ba", null ],
    [ "PN2_ActivateLOffcut", "group___objectives.html#gaddb923709efbd91473aad32b942d9bd3", null ],
    [ "PN2_SetLOffcutMinimumUsableHeight", "group___objectives.html#gaa8b432c39c2d6131aed142d2a4c80479", null ],
    [ "PN2_SetMaterialUnitCost", "group___objectives.html#ga7e93143511efe0c6cb7037373e92dedd", null ],
    [ "PN2_SetCuttingUnitCost", "group___objectives.html#ga84a6f3ac9691090a873c6e539e041c88", null ],
    [ "PN2_EnableLayeredCutting", "group___objectives.html#ga68eb1933dea9762b189088ab1783c72d", null ],
    [ "PN2_SetSheetLayoutCost", "group___objectives.html#gafe0008b56ddf6917ef685a905c2b5471", null ],
    [ "PN2_SetSessionOffcutSides", "group___objectives.html#ga2627f18e82e12d644f81afccc9b2404e", null ],
    [ "PN2_SheetSetCost", "group___objectives.html#ga41b79e455762d7d9c3020cb355f68e3e", null ]
];