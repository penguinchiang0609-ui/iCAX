var powernest2__dongle_8h =
[
    [ "PN2_SetSentinelDongleInfos", "powernest2__dongle_8h.html#a499d276b27ba576f3664ac415d490c66", null ],
    [ "PN2_GetDongleId", "powernest2__dongle_8h.html#ab7642a86f2378586e54d93565ae92368", null ]
];