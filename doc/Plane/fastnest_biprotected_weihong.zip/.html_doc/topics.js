var topics =
[
    [ "Orientation", "group___orientation.html", "group___orientation" ],
    [ "Session", "group___session.html", "group___session" ],
    [ "Contour", "group___contour.html", "group___contour" ],
    [ "Shape", "group___shape.html", "group___shape" ],
    [ "Part", "group___part.html", "group___part" ],
    [ "Sheet", "group___sheet.html", "group___sheet" ],
    [ "Result", "group___result.html", "group___result" ],
    [ "Optimization", "group___optimization.html", "group___optimization" ],
    [ "Constraints", "group___constraints.html", "group___constraints" ],
    [ "Callbacks", "group___callbacks.html", "group___callbacks" ],
    [ "Troubleshooting", "group___troubleshooting.html", "group___troubleshooting" ],
    [ "Common-Line Cutting", "group___common_cut.html", "group___common_cut" ],
    [ "Multi-Heads Cutting", "group___multi_heads.html", "group___multi_heads" ],
    [ "Optimization Objectives", "group___objectives.html", "group___objectives" ],
    [ "User Warnings", "group___user_warnings.html", "group___user_warnings" ],
    [ "Licenses", "group___licenses.html", "group___licenses" ]
];