var powernest2__objective_8h =
[
    [ "PN2_SIDE", "group___objectives.html#ga48937953dd3fa17e750a5e3af58b73ba", [
      [ "PN2_RIGHT", "group___objectives.html#gga48937953dd3fa17e750a5e3af58b73baa7a40565b3beb2ec6a11ead057b3a22ae", null ],
      [ "PN2_LEFT", "group___objectives.html#gga48937953dd3fa17e750a5e3af58b73baa5b960e4bbf1f46ddd8ce55e30f08753e", null ],
      [ "PN2_TOP", "group___objectives.html#gga48937953dd3fa17e750a5e3af58b73baafc3927e1467dd297cc906990dbc97584", null ],
      [ "PN2_BOTTOM", "group___objectives.html#gga48937953dd3fa17e750a5e3af58b73baa83169498188fc8b9028e7963d340de57", null ]
    ] ],
    [ "PN2_SetMaterialUnitCost", "group___objectives.html#ga7e93143511efe0c6cb7037373e92dedd", null ],
    [ "PN2_SetCuttingUnitCost", "group___objectives.html#ga84a6f3ac9691090a873c6e539e041c88", null ],
    [ "PN2_EnableLayeredCutting", "group___objectives.html#ga68eb1933dea9762b189088ab1783c72d", null ],
    [ "PN2_SetSheetLayoutCost", "group___objectives.html#gafe0008b56ddf6917ef685a905c2b5471", null ],
    [ "PN2_SetSessionOffcutSides", "group___objectives.html#ga2627f18e82e12d644f81afccc9b2404e", null ],
    [ "PN2_SheetSetCost", "group___objectives.html#ga41b79e455762d7d9c3020cb355f68e3e", null ]
];