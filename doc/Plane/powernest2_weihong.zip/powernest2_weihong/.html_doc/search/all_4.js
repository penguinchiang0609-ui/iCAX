var searchData=
[
  ['efficiency_20of_20a_20result_20any_20other_20metric_0',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['efficient_20results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_1',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['encounter_20an_20issue_20how_20do_20i_20report_20it_2',['I encounter an issue, how do I report it?',['../page.html#autotoc_md12',1,'']]],
  ['exact_20same_20optimization_20twice_3',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['examples_4',['ASL Examples',['../group___asl_lib.html#AslExamples',1,'']]]
];
