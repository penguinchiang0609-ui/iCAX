var searchData=
[
  ['y_0',['y',['../struct_p_n2___point.html#a64ff68be1a4845c39a7b22f1d3132f65',1,'PN2_Point']]],
  ['yields_20more_20efficient_20results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_1',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]]
];
