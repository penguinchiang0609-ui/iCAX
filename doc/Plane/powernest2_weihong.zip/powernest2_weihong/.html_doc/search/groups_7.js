var searchData=
[
  ['result_0',['Result',['../group___result.html',1,'']]]
];
