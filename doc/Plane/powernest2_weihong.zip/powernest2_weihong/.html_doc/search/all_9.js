var searchData=
[
  ['kind_20of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_0',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]]
];
