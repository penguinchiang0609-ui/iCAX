var searchData=
[
  ['have_20dxf_20files_20or_20another_20kind_20of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_0',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['heads_20cutting_1',['Multi-Heads Cutting',['../group___multi_heads.html',1,'']]],
  ['hello_20world_2',['Hello World',['../index.html#autotoc_md4',1,'']]],
  ['home_3',['Home',['../index.html',1,'']]],
  ['how_20can_20i_20call_20the_20api_20with_20my_20language_4',['I do not use C/C++, how can I call the API with my language',['../page.html#autotoc_md6',1,'']]],
  ['how_20can_20i_20use_20them_20with_20powernest_5',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['how_20come_20how_20to_20compare_20two_20solutions_6',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['how_20do_20i_20get_20the_20efficiency_20of_20a_20result_20any_20other_20metric_7',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['how_20do_20i_20report_20it_8',['I encounter an issue, how do I report it?',['../page.html#autotoc_md12',1,'']]],
  ['how_20many_20parts_20can_20i_20nest_20together_20what_20are_20the_20limits_20on_20quantities_20complexity_9',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['how_20much_20computing_20time_20should_20i_20use_20for_20my_20problem_10',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]],
  ['how_20to_20compare_20two_20solutions_11',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]]
];
