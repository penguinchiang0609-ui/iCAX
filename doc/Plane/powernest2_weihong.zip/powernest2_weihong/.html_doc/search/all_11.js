var searchData=
[
  ['sagittas_0',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]],
  ['same_20optimization_20twice_1',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['satisfied_20with_20a_20result_2',['Can I interupt Powernest as soon as I am satisfied with a result?',['../page.html#autotoc_md8',1,'']]],
  ['session_3',['Session',['../group___session.html',1,'']]],
  ['shape_4',['Shape',['../group___shape.html',1,'']]],
  ['sheet_5',['Sheet',['../group___sheet.html',1,'']]],
  ['should_20i_20use_20for_20my_20problem_6',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]],
  ['shown_20in_20the_20documented_20api_7',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['solution_20yields_20more_20efficient_20results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_8',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['solutions_9',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['some_20notions_20of_20geometry_20concerning_20bulges_20sagittas_10',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]],
  ['soon_20as_20i_20am_20satisfied_20with_20a_20result_11',['Can I interupt Powernest as soon as I am satisfied with a result?',['../page.html#autotoc_md8',1,'']]],
  ['start_20instructions_20for_20registering_20installing_20or_20unregistering_20a_20license_3a_12',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]],
  ['started_13',['Getting started',['../index.html#autotoc_md3',1,'']]]
];
