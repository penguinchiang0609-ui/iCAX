var searchData=
[
  ['x_0',['x',['../struct_p_n2___point.html#a77e738fbd296beca3bb00b95f4b22b7a',1,'PN2_Point']]],
  ['x_20concurrent_20solution_20yields_20more_20efficient_20results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_1',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]]
];
