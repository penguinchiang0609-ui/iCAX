var searchData=
[
  ['objectives_0',['Optimization Objectives',['../group___objectives.html',1,'']]],
  ['of_20a_20result_20any_20other_20metric_1',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_2',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['of_20geometry_20concerning_20bulges_20sagittas_3',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]],
  ['of_20priorities_20for_20pn2_5fsheet_4',['Is there any concept of priorities for PN2_Sheet?',['../page.html#autotoc_md18',1,'']]],
  ['on_20quantities_20complexity_5',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['optimization_6',['Optimization',['../group___optimization.html',1,'']]],
  ['optimization_20objectives_7',['Optimization Objectives',['../group___objectives.html',1,'']]],
  ['optimization_20twice_8',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['or_20another_20kind_20of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_9',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['or_20unregistering_20a_20license_3a_10',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]],
  ['orientation_11',['Orientation',['../group___orientation.html',1,'']]],
  ['other_20metric_12',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]]
];
