var searchData=
[
  ['necessary_0',['Under MS Windows, are Visual C++ Redistribuable necessary?',['../page.html#autotoc_md17',1,'']]],
  ['nest_20together_20what_20are_20the_20limits_20on_20quantities_20complexity_1',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['nesting_20features_20shown_20in_20the_20documented_20api_2',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['never_5fglue_3',['NEVER_GLUE',['../group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caeaeaaa3f8917316d4e4351401670a3c5f5',1,'powernest2.h']]],
  ['no_20version_20in_20the_20api_4',['Why is there no version in the API?',['../page.html#autotoc_md14',1,'']]],
  ['not_20use_20c_20c_20how_20can_20i_20call_20the_20api_20with_20my_20language_5',['I do not use C/C++, how can I call the API with my language',['../page.html#autotoc_md6',1,'']]],
  ['notions_20of_20geometry_20concerning_20bulges_20sagittas_6',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]]
];
