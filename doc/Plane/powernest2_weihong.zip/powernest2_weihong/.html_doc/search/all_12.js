var searchData=
[
  ['than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_0',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['the_20api_1',['Why is there no version in the API?',['../page.html#autotoc_md14',1,'']]],
  ['the_20api_20with_20my_20language_2',['I do not use C/C++, how can I call the API with my language',['../page.html#autotoc_md6',1,'']]],
  ['the_20documented_20api_3',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['the_20efficiency_20of_20a_20result_20any_20other_20metric_4',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['the_20exact_20same_20optimization_20twice_5',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['the_20limits_20on_20quantities_20complexity_6',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['the_20nesting_20features_20shown_20in_20the_20documented_20api_7',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['them_20with_20powernest_8',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['there_20any_20concept_20of_20priorities_20for_20pn2_5fsheet_9',['Is there any concept of priorities for PN2_Sheet?',['../page.html#autotoc_md18',1,'']]],
  ['there_20no_20version_20in_20the_20api_10',['Why is there no version in the API?',['../page.html#autotoc_md14',1,'']]],
  ['time_20should_20i_20use_20for_20my_20problem_11',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]],
  ['to_20compare_20two_20solutions_12',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['together_20what_20are_20the_20limits_20on_20quantities_20complexity_13',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['troobleshooting_14',['Troobleshooting',['../group___troobleshooting.html',1,'']]],
  ['tutorial_15',['ASL Tutorial',['../group___asl_lib.html#AslTuto',1,'']]],
  ['twice_16',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['two_20solutions_17',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]]
];
