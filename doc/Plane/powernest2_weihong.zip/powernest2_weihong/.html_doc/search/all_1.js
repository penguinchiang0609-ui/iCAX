var searchData=
[
  ['bulges_20sagittas_0',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]]
];
