var searchData=
[
  ['different_20results_20when_20doing_20the_20exact_20same_20optimization_20twice_0',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['do_20i_20get_20a_20worst_20result_20while_20using_20more_20computing_20ressources_1',['Why do I get a worst result while using more computing ressources?',['../page.html#autotoc_md10',1,'']]],
  ['do_20i_20get_20different_20results_20when_20doing_20the_20exact_20same_20optimization_20twice_2',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['do_20i_20get_20the_20efficiency_20of_20a_20result_20any_20other_20metric_3',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['do_20i_20report_20it_4',['I encounter an issue, how do I report it?',['../page.html#autotoc_md12',1,'']]],
  ['do_20not_20use_20c_20c_20how_20can_20i_20call_20the_20api_20with_20my_20language_5',['I do not use C/C++, how can I call the API with my language',['../page.html#autotoc_md6',1,'']]],
  ['documented_20api_6',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['doing_20the_20exact_20same_20optimization_20twice_7',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]],
  ['dxf_20files_20or_20another_20kind_20of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_8',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]]
];
