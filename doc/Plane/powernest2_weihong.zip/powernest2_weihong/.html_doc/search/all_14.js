var searchData=
[
  ['version_20in_20the_20api_0',['Why is there no version in the API?',['../page.html#autotoc_md14',1,'']]],
  ['visual_20c_20redistribuable_20necessary_1',['Under MS Windows, are Visual C++ Redistribuable necessary?',['../page.html#autotoc_md17',1,'']]]
];
