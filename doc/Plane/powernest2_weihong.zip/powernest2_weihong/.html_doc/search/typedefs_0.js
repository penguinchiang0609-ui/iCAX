var searchData=
[
  ['asl_5fbool_0',['ASL_Bool',['../group___asl_a_p_i.html#ga59666a938a7d9f17a5c8271d08809684',1,'alma_software_license.h']]],
  ['asl_5ferrorcode_1',['ASL_ErrorCode',['../group___asl_a_p_i.html#gad8f78363c32f9129b3bf553be3d1e487',1,'alma_software_license.h']]]
];
