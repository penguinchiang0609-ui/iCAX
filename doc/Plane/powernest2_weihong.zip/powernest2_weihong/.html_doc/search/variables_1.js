var searchData=
[
  ['y_0',['y',['../struct_p_n2___point.html#a64ff68be1a4845c39a7b22f1d3132f65',1,'PN2_Point']]]
];
