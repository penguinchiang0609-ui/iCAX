var searchData=
[
  ['alma_5fsoftware_5flicense_2eh_0',['alma_software_license.h',['../alma__software__license_8h.html',1,'']]]
];
