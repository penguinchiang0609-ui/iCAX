var searchData=
[
  ['redistribuable_20necessary_0',['Under MS Windows, are Visual C++ Redistribuable necessary?',['../page.html#autotoc_md17',1,'']]],
  ['registering_20installing_20or_20unregistering_20a_20license_3a_1',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]],
  ['report_20it_2',['I encounter an issue, how do I report it?',['../page.html#autotoc_md12',1,'']]],
  ['ressources_3',['Why do I get a worst result while using more computing ressources?',['../page.html#autotoc_md10',1,'']]],
  ['result_4',['Result',['../group___result.html',1,'']]],
  ['result_5',['Can I interupt Powernest as soon as I am satisfied with a result?',['../page.html#autotoc_md8',1,'']]],
  ['result_20any_20other_20metric_6',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['result_20while_20using_20more_20computing_20ressources_7',['Why do I get a worst result while using more computing ressources?',['../page.html#autotoc_md10',1,'']]],
  ['results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_8',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['results_20when_20doing_20the_20exact_20same_20optimization_20twice_9',['Why do I get different results when doing the exact same optimization twice?',['../page.html#autotoc_md9',1,'']]]
];
