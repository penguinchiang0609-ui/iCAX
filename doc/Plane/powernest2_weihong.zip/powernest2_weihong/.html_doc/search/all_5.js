var searchData=
[
  ['faq_0',['FAQ',['../page.html',1,'']]],
  ['features_20shown_20in_20the_20documented_20api_1',['Are all the nesting features shown in the documented API?',['../page.html#autotoc_md15',1,'']]],
  ['files_20how_20can_20i_20use_20them_20with_20powernest_2',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['files_20or_20another_20kind_20of_20cad_20files_20how_20can_20i_20use_20them_20with_20powernest_3',['I have DXF files or another kind of CAD files, how can I use them with Powernest?',['../page.html#autotoc_md5',1,'']]],
  ['for_20my_20problem_4',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]],
  ['for_20pn2_5fsheet_5',['Is there any concept of priorities for PN2_Sheet?',['../page.html#autotoc_md18',1,'']]],
  ['for_20registering_20installing_20or_20unregistering_20a_20license_3a_6',['Quick Start instructions for registering, installing or unregistering a license:',['../group___asl_u_m.html#QSI',1,'']]]
];
