var searchData=
[
  ['manual_0',['ASL User manual',['../group___asl_u_m.html',1,'']]],
  ['many_20parts_20can_20i_20nest_20together_20what_20are_20the_20limits_20on_20quantities_20complexity_1',['How many parts can I nest together, what are the limits on quantities/complexity?',['../page.html#autotoc_md13',1,'']]],
  ['material_2',['Material',['../index.html#autotoc_md1',1,'']]],
  ['metric_3',['How do I get the efficiency of a result? Any other metric?',['../page.html#autotoc_md19',1,'']]],
  ['miss_20some_20notions_20of_20geometry_20concerning_20bulges_20sagittas_4',['I miss some notions of geometry concerning bulges, sagittas, ...',['../page.html#autotoc_md16',1,'']]],
  ['more_20computing_20ressources_5',['Why do I get a worst result while using more computing ressources?',['../page.html#autotoc_md10',1,'']]],
  ['more_20efficient_20results_20than_20powernest_20how_20come_20how_20to_20compare_20two_20solutions_6',['X concurrent solution yields more efficient results than Powernest, how come? How to compare two solutions?',['../page.html#autotoc_md11',1,'']]],
  ['ms_20windows_20are_20visual_20c_20redistribuable_20necessary_7',['Under MS Windows, are Visual C++ Redistribuable necessary?',['../page.html#autotoc_md17',1,'']]],
  ['much_20computing_20time_20should_20i_20use_20for_20my_20problem_8',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]],
  ['multi_20heads_20cutting_9',['Multi-Heads Cutting',['../group___multi_heads.html',1,'']]],
  ['my_20language_10',['I do not use C/C++, how can I call the API with my language',['../page.html#autotoc_md6',1,'']]],
  ['my_20problem_11',['How much computing time should I use for my problem',['../page.html#autotoc_md7',1,'']]]
];
