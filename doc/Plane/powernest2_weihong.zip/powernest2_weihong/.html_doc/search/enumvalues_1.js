var searchData=
[
  ['glue_5fon_5fnest_5fmore_5fonly_0',['GLUE_ON_NEST_MORE_ONLY',['../group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caea2c15b9c69de26ea2551b324bb6ae3a80',1,'powernest2.h']]]
];
