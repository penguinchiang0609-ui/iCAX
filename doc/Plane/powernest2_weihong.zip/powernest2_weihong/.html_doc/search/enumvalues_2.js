var searchData=
[
  ['never_5fglue_0',['NEVER_GLUE',['../group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caeaeaaa3f8917316d4e4351401670a3c5f5',1,'powernest2.h']]]
];
