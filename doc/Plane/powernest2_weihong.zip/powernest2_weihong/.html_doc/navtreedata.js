/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Powernest", "index.html", [
    [ "Home", "index.html", "index" ],
    [ "Topics", "topics.html", "topics" ],
    [ "Structs", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ]
    ] ],
    [ "Index", "files.html", [
      [ "Headers", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ],
    [ "FAQ", "page.html", [
      [ "I have DXF files or another kind of CAD files, how can I use them with Powernest?", "page.html#autotoc_md5", null ],
      [ "I do not use C/C++, how can I call the API with my language", "page.html#autotoc_md6", null ],
      [ "How much computing time should I use for my problem", "page.html#autotoc_md7", null ],
      [ "Can I interupt Powernest as soon as I am satisfied with a result?", "page.html#autotoc_md8", null ],
      [ "Why do I get different results when doing the exact same optimization twice?", "page.html#autotoc_md9", null ],
      [ "Why do I get a worst result while using more computing ressources?", "page.html#autotoc_md10", null ],
      [ "X concurrent solution yields more efficient results than Powernest, how come? How to compare two solu...", "page.html#autotoc_md11", null ],
      [ "I encounter an issue, how do I report it?", "page.html#autotoc_md12", null ],
      [ "How many parts can I nest together, what are the limits on quantities/complexity?", "page.html#autotoc_md13", null ],
      [ "Why is there no version in the API?", "page.html#autotoc_md14", null ],
      [ "Are all the nesting features shown in the documented API?", "page.html#autotoc_md15", null ],
      [ "I miss some notions of geometry concerning bulges, sagittas, ...", "page.html#autotoc_md16", null ],
      [ "Under MS Windows, are Visual C++ Redistribuable necessary?", "page.html#autotoc_md17", null ],
      [ "Is there any concept of priorities for PN2_Sheet?", "page.html#autotoc_md18", null ],
      [ "How do I get the efficiency of a result? Any other metric?", "page.html#autotoc_md19", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"alma__software__license_8h.html",
"powernest2__license_8h_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';