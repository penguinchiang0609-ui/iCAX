var group___callbacks =
[
    [ "PN2_UpdateBest", "group___callbacks.html#ga92434067bf9f6290e53b68557f5bc0d5", null ],
    [ "PN2_StopNesting", "group___callbacks.html#gaee65db0e77d5614676490e477b03a63e", null ],
    [ "PN2_MultiUpdateBest", "group___callbacks.html#gad5b63a7d1dabe99f0c258f0437bb3836", null ],
    [ "PN2_SetSessionCallbacks", "group___callbacks.html#gae26788e0dd99198f9241542d73029dd7", null ],
    [ "PN2_SetSessionMultiCallbacks", "group___callbacks.html#gab80b72e1e62cccc1cacaf437c3a918c0", null ]
];