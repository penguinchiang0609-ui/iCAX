var group___licenses =
[
    [ "About AlmaSoftwareLicense Library", "group___asl_lib.html", null ],
    [ "ASL User manual", "group___asl_u_m.html", null ],
    [ "alma_software_license API", "group___asl_a_p_i.html", "group___asl_a_p_i" ],
    [ "powernest2_license API", "group___pn2_license_a_p_i.html", "group___pn2_license_a_p_i" ]
];