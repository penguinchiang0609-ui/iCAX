var powernest2__user__warnings_8h =
[
    [ "PN2_USER_WARNING_CODE", "group___user_warnings.html#gad1a170e59bdb34074876af78908a5322", [
      [ "PN2_NOT_ENOUGH_RAW_SHEETS", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322a4bbce86ffe8ef512025a549e3feb98bc", null ],
      [ "PN2_PART_LARGER_THAN_SHEETS", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322a76b19a8d0e18fd01cd009d2006f7c775", null ],
      [ "PN2_PART_LARGER_THAN_NESTING_WINDOWS", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322ab651990d801060e5009c056331bdf1c1", null ],
      [ "PN2_SHAPE_LARGER_THAN_NESTING_WINDOWS", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322a36e75c2049bc9a87dc5b97cd5370d297", null ],
      [ "PN2_AUTO_INTERSECTING_SHAPE", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322a0a757ac66b8b03c22dc063173c6e1b5a", null ],
      [ "PN2_INVALID_SHAPE_WITH_SPECIAL_EDGES", "group___user_warnings.html#ggad1a170e59bdb34074876af78908a5322ae48e8eb3bfa0159c13164b160c63bce5", null ]
    ] ],
    [ "PN2_USER_WARNING_DATA_ELEMENT_TYPE", "group___user_warnings.html#ga02e83cac0a4b9355ba0c97572916e2bf", [
      [ "PN2_PART_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa1f92cd41ee0b864e143e36f6a657a4ce", null ],
      [ "PN2_SHEET_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfaea6fc495e17a231c7af06a0327066270", null ],
      [ "PN2_SHAPE_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa4c950b95dc2b649b029814fc36a2b2ad", null ],
      [ "PN2_RESULT_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa26c8e03165f77fa09e5f824babcc73db", null ],
      [ "PN2_MULTIRESULT_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa2dd6ffabacfcc6c714502cfaebc8260d", null ],
      [ "PN2_ORIENTATION_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa86ae18223b79fed08e6426dad61aadc5", null ],
      [ "PN2_POINT_TYPE", "group___user_warnings.html#gga02e83cac0a4b9355ba0c97572916e2bfa67e71e468f41d30644761f018f5f2993", null ]
    ] ],
    [ "PN2_GenerateNestWarnings", "group___user_warnings.html#gadd74f5606746c7c3fba0dfa38d2a6744", null ],
    [ "PN2_GetKthUserWarning", "group___user_warnings.html#ga9444f72d8bab60efdc4399bf6c0aefd7", null ],
    [ "PN2_GetKthUserWarningDataElement", "group___user_warnings.html#gad9f6e816d1eeb544bb5523c10f9d11f6", null ]
];