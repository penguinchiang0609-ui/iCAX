var group___result =
[
    [ "PN2_Result", "group___result.html#gacf23c347ec3fd08c13dd8c4038b351a5", null ],
    [ "PN2_MultiResult", "group___result.html#ga9cb116cbd4280a5ead905c008808663d", null ],
    [ "PN2_GetResultInfos", "group___result.html#ga6bc2c3a436f0b9e5b55594ca4c11ec56", null ],
    [ "PN2_GetKthNestedPart", "group___result.html#gaa4cb5f17c96caca68e647809ddcb7952", null ],
    [ "PN2_GetNestedPart", "group___result.html#ga690234eb92d9f47ca374c44cc4c18e32", null ],
    [ "PN2_GetMultiResultInfos", "group___result.html#ga14afe6d438f983c1965a69cf3d26b656", null ],
    [ "PN2_GetResult", "group___result.html#ga4b48ba2456668bcde7d2718364d64d2b", null ],
    [ "PN2_IsSameNesting", "group___result.html#gadebe990c4ced13c12ff16b04dc9b69d4", null ],
    [ "PN2_ConcatenateResults", "group___result.html#gabc5b26dd9d87ac08b49a4844ef6eb44c", null ]
];