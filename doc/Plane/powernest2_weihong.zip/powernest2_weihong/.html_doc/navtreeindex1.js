var NAVTREEINDEX1 =
{
"powernest2__license_8h_source.html":[3,0,4],
"powernest2__metal_8h.html":[3,0,5],
"powernest2__metal_8h_source.html":[3,0,5],
"powernest2__multiheads_8h.html":[3,0,6],
"powernest2__multiheads_8h_source.html":[3,0,6],
"powernest2__objective_8h.html":[3,0,7],
"powernest2__objective_8h_source.html":[3,0,7],
"powernest2__user__warnings_8h.html":[3,0,8],
"powernest2__user__warnings_8h_source.html":[3,0,8],
"protections_8c-example.html":[4,2],
"struct_p_n2___point.html":[2,0,2],
"struct_p_n2___point.html#a64ff68be1a4845c39a7b22f1d3132f65":[2,0,2,1],
"struct_p_n2___point.html#a77e738fbd296beca3bb00b95f4b22b7a":[2,0,2,0],
"topics.html":[1],
"user_warnings_8c-example.html":[4,0]
};
