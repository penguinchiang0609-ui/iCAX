var powernest2__l__offcut_8h =
[
    [ "PN2_ActivateLOffcut", "group___objectives.html#gaddb923709efbd91473aad32b942d9bd3", null ],
    [ "PN2_SetLOffcutMinimumUsableHeight", "group___objectives.html#gaa8b432c39c2d6131aed142d2a4c80479", null ]
];