var group___multi_heads =
[
    [ "PN2_SetCuttingHeadsNumber", "group___multi_heads.html#gadea5d4db40dadff8ca2ad4ca8e95fe7d", null ],
    [ "PN2_SetCuttingHeadsMinimumGap", "group___multi_heads.html#ga191c6691631c5434f27deb929f0f8009", null ],
    [ "PN2_SetCuttingHeadsMaximumGap", "group___multi_heads.html#gae6834b9f27de0b945b2df1175f05d1f7", null ],
    [ "PN2_SetAdditionnalHeadCuttingUnitCost", "group___multi_heads.html#gae2a68db9597efd784553ee3d39c81885", null ],
    [ "PN2_GetPartMultipleHeadsNumber", "group___multi_heads.html#ga713dee6923a61efda9ac9ecc2e30d85a", null ],
    [ "PN2_GetPartMultipleHeadsLinkedPart", "group___multi_heads.html#gaff2b281d5cde13fd26a29a6da86d4488", null ]
];