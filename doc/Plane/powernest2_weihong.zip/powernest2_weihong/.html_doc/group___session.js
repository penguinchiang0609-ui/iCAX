var group___session =
[
    [ "PN2_Session", "group___session.html#gad71da430b4868a64fe3f6a79d3fb2c9d", null ],
    [ "PN2_CreateSession", "group___session.html#ga63427e15371e7f3a8ec54910476a444a", null ],
    [ "PN2_DeleteSession", "group___session.html#gaae7a248310b6383c2e350cde6582296b", null ],
    [ "PN2_SetSessionNbThreads", "group___session.html#ga664922b51f20e9f1bc45c36621749b10", null ],
    [ "PN2_SetSessionMinimizeBoundingBoxArea", "group___session.html#ga1cf40a474038a84c9a0d21d646cf7615", null ]
];