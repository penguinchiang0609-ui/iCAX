var powernest2__common__cut_8h =
[
    [ "PN2_CommonCutType", "group___common_cut.html#gab1547c0a351f3dda5677222716df5162", [
      [ "PN2_NoCommonCut", "group___common_cut.html#ggab1547c0a351f3dda5677222716df5162ac203bf14c7b13fdb81d3281437904fa8", null ],
      [ "PN2_SameShapeCommonCut", "group___common_cut.html#ggab1547c0a351f3dda5677222716df5162a5581519916e279f6683a33908be76fd6", null ],
      [ "PN2_AnyShapeCommonCut", "group___common_cut.html#ggab1547c0a351f3dda5677222716df5162a913c80ef1503cbe3bb7215b6091bbc77", null ]
    ] ],
    [ "PN2_CommonCutClusterConstraint", "group___common_cut.html#ga6f2022315805109eb93de0994a7a5cdc", [
      [ "PN2_DirectionWithoutCommonCut", "group___common_cut.html#gga6f2022315805109eb93de0994a7a5cdca7b58e5e90ff2cf4406bdcf373c39badf", null ],
      [ "PN2_SimpleLineCommonCut", "group___common_cut.html#gga6f2022315805109eb93de0994a7a5cdca40620321ed39ec10aa068bc5429ef8eb", null ],
      [ "PN2_DoubleLineCommonCut", "group___common_cut.html#gga6f2022315805109eb93de0994a7a5cdca282d643eee68844d0dc9fa759f506b2c", null ],
      [ "PN2_MatrixCommonCut", "group___common_cut.html#gga6f2022315805109eb93de0994a7a5cdcaed7d58e53589fb93ad6a2c90a02034d9", null ]
    ] ],
    [ "PN2_SetCommonCutDistance", "group___common_cut.html#ga2e38ed094615a00da0f5086f23a73b45", null ],
    [ "PN2_ShapeSetCommonCutType", "group___common_cut.html#gab6f0175369467efa66e8e9b19e01e8aa", null ],
    [ "PN2_ShapeSetCommonCutMatching", "group___common_cut.html#ga62ba14c96924e56d1b7b6f67e34be47b", null ],
    [ "PN2_ShapeSetMinimumAngleForCommonCut", "group___common_cut.html#gabd824769d8c205df9000e60a1dde2176", null ],
    [ "PN2_ShapeSetMaximumRadiusForCommonCut", "group___common_cut.html#gac6efb12f114c64a7406e3eadcb917818", null ],
    [ "PN2_ShapeSetMinimumHoleAreaForCommonCut", "group___common_cut.html#gafc5fbdc6388de04d1d2c719840b5c7a3", null ],
    [ "PN2_ShapeSetMinimumCommonCutLength", "group___common_cut.html#ga849692fb6eab040f25fbc6dd73bfe1f2", null ],
    [ "PN2_ShapeSetMaxNbPartsInCommonCut", "group___common_cut.html#ga94d57cc1984190f9aefd3ef531b6befe", null ],
    [ "PN2_ShapeSetMaxCommonCutClusterDimension", "group___common_cut.html#ga32103bd4170356654011f828974f27d2", null ],
    [ "PN2_ShapeSetSingleCommonCut", "group___common_cut.html#ga1c923f397ed09760d38f7b08021ce405", null ],
    [ "PN2_ShapeSetClusterConstraintsForCommonCut", "group___common_cut.html#gadc78942ac380da5eb87337ee0c858ba1", null ],
    [ "PN2_IsPartInCommonCut", "group___common_cut.html#ga2516a0cfd5cdc7621d892496a7e64320", null ]
];