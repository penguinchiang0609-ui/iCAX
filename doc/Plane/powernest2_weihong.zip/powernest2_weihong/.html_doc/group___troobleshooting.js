var group___troobleshooting =
[
    [ "PN2_IS_ERROR", "group___troobleshooting.html#ga116ad906bd7fd4e66579c764ed0652e3", null ],
    [ "PN2_LogFunctionCalls", "group___troobleshooting.html#ga20d174329679cf72a7c60813e4801e2a", null ],
    [ "PN2_LogHostSpecs", "group___troobleshooting.html#ga60d7578883f5f5c557e9650c282e280c", null ],
    [ "PN2_LogWarnings", "group___troobleshooting.html#ga9bd2eb1fb610f6817bcc30f52fdecc39", null ],
    [ "PN2_LogInternalWarnings", "group___troobleshooting.html#ga8b7dcd02670acefb3e5f1ae115f59150", null ],
    [ "PN2_DrawSvg", "group___troobleshooting.html#ga8856fa9a462fe2837de6f3979c393f92", null ],
    [ "PN2_ErrorMessage", "group___troobleshooting.html#ga8bb923c27d63d9ecaf6636354fe46ec4", null ],
    [ "PN2_ErrorMessageFromObject", "group___troobleshooting.html#ga6debab212c974ef74af2a69a6d0efdb4", null ],
    [ "PN2_IsObjectError", "group___troobleshooting.html#gac6b07999b500686d494f30ff6d6f2b8a", null ],
    [ "PN2_ErrorCodeFromObject", "group___troobleshooting.html#gac30a6d3ce239540442f1faadb4b51e26", null ],
    [ "PN2_SetOutputReportFile", "group___troobleshooting.html#ga717b10c194dbf4e66947f1c52f50e776", null ],
    [ "PN2_CheckDetectedExe", "group___troobleshooting.html#gad80ea4976851d80b87dd790dfc2e3b80", null ],
    [ "PN2_GetVersion", "group___troobleshooting.html#ga1691112ed720a03991cdf7a96487966b", null ],
    [ "PN2_DrawMultiSvg", "group___troobleshooting.html#gaa6d260afe25b2205191aa0470e94cc95", null ]
];