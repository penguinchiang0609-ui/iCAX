var group___user_warnings =
[
    [ "PN2_DataElement", "group___user_warnings.html#union_p_n2___data_element", null ],
    [ "PN2_USER_WARNING_CODE", "group___user_warnings.html#gad1a170e59bdb34074876af78908a5322", null ],
    [ "PN2_USER_WARNING_DATA_ELEMENT_TYPE", "group___user_warnings.html#ga02e83cac0a4b9355ba0c97572916e2bf", null ],
    [ "PN2_GenerateNestWarnings", "group___user_warnings.html#gadd74f5606746c7c3fba0dfa38d2a6744", null ],
    [ "PN2_GetKthUserWarning", "group___user_warnings.html#ga9444f72d8bab60efdc4399bf6c0aefd7", null ],
    [ "PN2_GetKthUserWarningDataElement", "group___user_warnings.html#gad9f6e816d1eeb544bb5523c10f9d11f6", null ]
];