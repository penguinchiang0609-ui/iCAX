var group___part =
[
    [ "PN2_Part", "group___part.html#ga6d005a3f9a423e047060225d8f9ca72c", null ],
    [ "PN2_PRE_NESTED_GLUE_MODE", "group___part.html#gadbb53e7d18ebd01ce39e9a80ee1d4cae", [
      [ "ALWAYS_GLUE", "group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caeaf8699c7cbdc2f7460ebb9fab126d94f7", null ],
      [ "NEVER_GLUE", "group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caeaeaaa3f8917316d4e4351401670a3c5f5", null ],
      [ "GLUE_ON_NEST_MORE_ONLY", "group___part.html#ggadbb53e7d18ebd01ce39e9a80ee1d4caea2c15b9c69de26ea2551b324bb6ae3a80", null ]
    ] ],
    [ "PN2_AddPart", "group___part.html#ga3b8be6de6e08ffdd78c34efd23d06308", null ],
    [ "PN2_AddSeveralParts", "group___part.html#ga90de0137d5e3faf2b7cbc6b331412e51", null ],
    [ "PN2_PartSetPriority", "group___part.html#gaf6e78dd3a6eff61f2a838412d9b600a0", null ],
    [ "PN2_SetPreNestedGlueMode", "group___part.html#gaea569818a0d00ef9c43624c64fc029f1", null ],
    [ "PN2_SetExclusiveGroups", "group___part.html#gade9080578a879a5b8ea26ed4f27d3649", null ]
];