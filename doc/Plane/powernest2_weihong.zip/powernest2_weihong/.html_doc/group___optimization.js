var group___optimization =
[
    [ "PN2_Nest", "group___optimization.html#ga892eb32dd14c0259e4999ea5ad86c72f", null ],
    [ "PN2_PreNest", "group___optimization.html#ga1e772e6412f64e361381b5ed1b8a12aa", null ],
    [ "PN2_NestMore", "group___optimization.html#gab32fc6e88ec6bfabdb048744e241f819", null ],
    [ "PN2_Shake", "group___optimization.html#ga33067efa27b272c84d800a5a5140864a", null ],
    [ "PN2_PricedNest", "group___optimization.html#gad89d9e047c9da01764a2343c16d163c0", null ],
    [ "PN2_MultiNest", "group___optimization.html#ga8b1b924e75178cb35e0c78d7190663e0", null ],
    [ "PN2_PWSMultiNest", "group___optimization.html#ga9f394adbbff7f03abd43d00d331e5051", null ],
    [ "PN2_MultiPreNest", "group___optimization.html#ga50cf35623859e62c8e8beca009f8fbd4", null ],
    [ "PN2_MultiNestMore", "group___optimization.html#ga93c35e74c5e9ed338cf7bd130269c8f9", null ],
    [ "PN2_CompleteMultiResultWithFillerParts", "group___optimization.html#gacc361eb3c068fc20e18d3e55634abf69", null ],
    [ "PN2_Spread", "group___optimization.html#gab47826792d115260b1ffc148e6317980", null ],
    [ "PN2_SpreadIgnoreBorders", "group___optimization.html#ga4c63489a0a62db7a71fa6addfe7f47a8", null ],
    [ "PN2_Compact", "group___optimization.html#ga57e6522d303e2216f5432e5f8e1b548a", null ]
];