var index =
[
    [ "Introduction", "index.html#autotoc_md0", null ],
    [ "Material", "index.html#autotoc_md1", null ],
    [ "Philosophy", "index.html#autotoc_md2", null ],
    [ "Getting started", "index.html#autotoc_md3", null ],
    [ "Hello World", "index.html#autotoc_md4", null ]
];