var group___sheet =
[
    [ "PN2_Sheet", "group___sheet.html#ga816f784b0bd4a4df5936d3d4e74dca03", null ],
    [ "PN2_AddSheet", "group___sheet.html#ga500e6bef570eeed2f14287bed9c70ec3", null ],
    [ "PN2_SheetAddBorderGaps", "group___sheet.html#gad62dad9edefc0e0b671db6bcfb8d6190", null ],
    [ "PN2_SheetAddDefect", "group___sheet.html#ga328efcef2fbcbdd7598a7d2c6dc595ef", null ],
    [ "PN2_SheetAddDefectFromContour", "group___sheet.html#ga1ac36f2f2205deaf72967b3ea6fc2b75", null ],
    [ "PN2_SheetAddDefectWithOffset", "group___sheet.html#gabc13b4829d517e7167f14c3a2fedbeea", null ],
    [ "PN2_SheetAddDefectFromContourWithOffset", "group___sheet.html#ga2df917c7dce8cb0006ce6fd1e051153d", null ],
    [ "PN2_AddPolygonalSheet", "group___sheet.html#gadd6d5a2f92cf7ac42ab658f9b543b10c", null ],
    [ "PN2_AddPolygonalSheetWithBorderGap", "group___sheet.html#ga62e7195987c0f7067e13c7c108421753", null ],
    [ "PN2_AddSheetFromContour", "group___sheet.html#ga0b5fece01c9d8e032fc50e0d6fc2434c", null ],
    [ "PN2_AddSheetFromContourWithBorderGap", "group___sheet.html#gab5053eed5f249a9d7b7331a205dc35fa", null ],
    [ "PN2_AddMetalSheet", "group___sheet.html#ga0f85953c0569728aedf76ced5b06226b", null ],
    [ "PN2_SetSheetRollingDirection", "group___sheet.html#gab3c93c7f90b5bb1448e2a259d826555e", null ]
];