var group___shape =
[
    [ "PN2_Shape", "group___shape.html#ga3bd51be5108af1764f0fea16ab4eff34", null ],
    [ "PN2_AddShape", "group___shape.html#gac77b07ecdc77896d56c8b7c6311632ec", null ],
    [ "PN2_AddShapeFromContour", "group___shape.html#gacbd5e278641b54713401d558e77298e6", null ],
    [ "PN2_AddComplexShape", "group___shape.html#ga055606a92a201bfcb811d8f24336b640", null ],
    [ "PN2_AddComplexShapeFromContours", "group___shape.html#gaed0abf214f04708ede030cf6c9ea03c7", null ],
    [ "PN2_ShapeAddHole", "group___shape.html#gacae11096490b5c0f0eb008d545cdf7a0", null ],
    [ "PN2_ShapeAddHoleFromContour", "group___shape.html#ga40544d568c56df2f0e0cb21374b274ff", null ],
    [ "PN2_ShapeSetProtectionOffset", "group___shape.html#ga863d75304ff9f6a4e28084a60de745bd", null ],
    [ "PN2_ShapeSetProtectionLine", "group___shape.html#ga1c061551e5c755fb21988b3166c2f956", null ],
    [ "PN2_HoleSetProtectionLine", "group___shape.html#ga386c48079b11196e2de810f49c107768", null ],
    [ "PN2_ComplexShapeSetProtectionLine", "group___shape.html#ga9b8319b0e3b5c7822c63e6e56f18c45d", null ],
    [ "PN2_ShapeSetProtectionLineFromContour", "group___shape.html#gadb443eb30fafd3f586618a30c89c2434", null ],
    [ "PN2_HoleSetProtectionLineFromContour", "group___shape.html#gad99ca4f1c55e481eafbaad1d7837e58e", null ],
    [ "PN2_ComplexShapeSetProtectionLineFromContours", "group___shape.html#gaefe51e88cd8c87b70d9724bb0275eda8", null ],
    [ "PN2_ShapeSetPrice", "group___shape.html#gad94f3ffd556aa770c0a691cae19de290", null ],
    [ "PN2_SetShapeOrientationsAsRelativeToRollingDirection", "group___shape.html#ga2a032f021fe23843241587c9d806da46", null ]
];