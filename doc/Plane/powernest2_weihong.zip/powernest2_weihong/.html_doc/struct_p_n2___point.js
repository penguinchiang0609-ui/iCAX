var struct_p_n2___point =
[
    [ "x", "struct_p_n2___point.html#a77e738fbd296beca3bb00b95f4b22b7a", null ],
    [ "y", "struct_p_n2___point.html#a64ff68be1a4845c39a7b22f1d3132f65", null ]
];