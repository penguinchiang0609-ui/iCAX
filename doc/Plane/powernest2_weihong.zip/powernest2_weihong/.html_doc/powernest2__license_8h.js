var powernest2__license_8h =
[
    [ "PN2_SetLicensePath", "group___pn2_license_a_p_i.html#ga783a2f6498facd5b0676a6dabdefbbe8", null ],
    [ "PN2_SetFloatingLicenseServerInfo", "group___pn2_license_a_p_i.html#gaa763b6bbba6e917b42868c50057795eb", null ],
    [ "PN2_CheckLicense", "group___pn2_license_a_p_i.html#ga855ea0c1a7f842785ca80d1c102a43ec", null ]
];