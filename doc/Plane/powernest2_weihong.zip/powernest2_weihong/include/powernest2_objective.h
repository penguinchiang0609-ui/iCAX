/**
 * @file
 * @author Alma
 * @brief API enabling and controlling PowerNest2 objective (optimization goal)
 */

#ifndef POWERNEST2_OBJECTIVE_H_
#define POWERNEST2_OBJECTIVE_H_

#include "powernest2.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @defgroup Objectives Optimization Objectives
     * @brief Beyond material saving
     *
     * The optimization objective may include other criterions than the material
     * consumption: various cutting costs, nesting-layout setup costs, ...
     *
     * Powernest will minimize the global production cost, ie the sum of all different
     * costs involved.
     *
     * @{
     */
    
    /**
     * @brief Set the unit cost of the material
     *
     * PowerNest2 balances its primary objective, which is reducing the material
     * consumption, with other objectives such as reducing the cutting costs (through
     * common line cutting, layered cutting, multi-heads cutting) and compute a result
     * minimizing the total "cost".
     * 
     * This function gives a cost to the material, which is to be balanced with other
     * costs such as PN2_SetCuttingUnitCost() or PN2_SetSheetLayoutCost()
     *
     * @param session the current session
     * @param cost the cost of a 1x1 surface or material, strictly greater than 0.
     *
     * @return error code, 0 if there was no error
     *
     * @warning The material cost shall be strictly greater than 0
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetMaterialUnitCost(PN2_Session session, double cost);


    /**
     * @brief Set the unit cost of the cut
     *
     * Set the cost of the cutting, to balance with material consumption cost (see
     * PN2_SetMaterialUnitCost()) to compute the nesting minimizing the total "cost".
     * 
     * @param session the current session
     * @param cost the cost for cutting a distance of "1". Must be greater or equal to 0.
     *
     * @return error code, 0 if there was no error
     *
     * @note The cutting cost should also take the lead-in, lead-out cost and any other
     *       cut-related cost in consideration. This can only be done through some rough
     *       approximation.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetCuttingUnitCost(PN2_Session session, double cost);


    /**
     * @brief Multiple identical PN2_Result will be stacked and cut together, dividing
     *        the cutting length by the number of layers.
     *
     * Identical nestings (see PN2_IsSameNesting()) are considered to be cut together
     * within limit of this value. Meaning that the cutting costs will be counted only
     * once for the whole group of identical layouts.
     *
     * Default value is 1.
     * 
     * Higher values are relevant only if cutting multiple sheets are
     * stacked and cut at the same time (for instance in foam or wood industries).
     * 
     * This influences the total cutting cost of multinestings (which uses
     * PN2_SetCuttingUnitCost()). For instance, with a maximum number of sheet layers of
     * 5, only two layouts cuts are taken into account for a multinesting with 10
     * identical nestings.
     *
     * Interaction with other parameters:
     * - This requires a relevant value set by
     *   PN2_SetCuttingUnitCost() and PN2_SetMaterialUnitCost().
     * - Concerning PN2_SetSheetLayoutCost(), the layout cost ignores the existance of
     *   layered cutting. It always behaves like if `layers_max_number == 1`.
     *
     * @param session the current session
     * @param layers_max_number the maximum number of sheet layers cuttable together, greater or equal to 1.
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_EnableLayeredCutting(PN2_Session session, int layers_max_number);


    /**
     * @brief Set the cost per sheet nesting layout
     *
     * This represents the fixed cost of creating a sheet layout different from any
     * other. For instance in a multinesting composed of two identical nestings, this
     * cost will be counted once, whereas a multinesting with two different nestings this
     * cost will be counted twice.
     *
     * Default value is 0. Higher values are relevant if there are cost at each new
     * layout in your cutting process (such as human intervention, program loading time,
     * etc) Such higher values will thus favorize identical nestings production,
     * depending on other costs (see PN2_SetMaterialUnitCost() and
     * PN2_SetCuttingUnitCost()).
     *
     * This requires a relevant value set by PN2_SetCuttingUnitCost() and
     * PN2_SetMaterialUnitCost().
     * 
     * @param session the current session
     * @param cost the cost for creating a new nesting layout, greater or equal to 0
     *
     * @return error code, 0 if there was no error
     *
     * @see PN2_IsSameNesting() for same nestings identification
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSheetLayoutCost(PN2_Session session, double cost);

    
    /** @brief Designates the four sides of a rectangular sheet
     *
     * Mainly used to designate on which side an offcut should be retrieved.
     */
    typedef enum {
        PN2_RIGHT,
        PN2_LEFT,
        PN2_TOP,
        PN2_BOTTOM
    } PN2_SIDE;
    
    /**
     * @brief Select on which sides of a sheet offcuts are retrieved.
     *
     * Default main side is PN2_RIGHT, ie. Powernest considers a straight vertical offcut
     * on the right side of the last nesting.
     * Default "second side" is PN2_TOP: while preserving the offcut on the main side,
     * Powernest will try to optimize the offcut on this second side.
     * This secondary offcut side only applies with a low number of parts,
     * when there is not enough of them to fill the sheet on this dimension.
     * 
     * The two sides must be orthogonal.
     *
     * @note When using the multi-head feature, a PN2_TOP or PN2_BOTTOM main offcut side
     * will result in heads being aligned horizontally instead of vertically.
     *
     * @note When using "L-offcut" optimization, the "minimal usable height" value is
     * applied in the "second_side" dimension.
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetSessionOffcutSides(PN2_Session session,
                                                               PN2_SIDE side,
                                                               PN2_SIDE second_side);
    /// @}


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
