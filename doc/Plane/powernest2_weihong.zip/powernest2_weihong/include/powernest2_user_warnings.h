/**
 * @file
 * @brief Handling of user warnings
 */
 

#ifndef POWERNEST2_USER_WARNINGS_H_
#define POWERNEST2_USER_WARNINGS_H_

#include "powernest2.h"
#include "powernest2_metal.h"

/**
 * @defgroup UserWarnings User Warnings
 * 
 * @brief Allows to obtain warnings that indicate basic infeasibilities in the input.
 *
 * The user-warning retrieval can be performed as follows:
 *  1. Call a function that generates user-warnings (PN2_GenerateNestWarnings())
 *     This function also provides the number of user-warnings generated.
 *  2. Get the k-th user-warning code and its number of associated data-elements (PN2_GetKthUserWarning())
 *  3. Get the k-th data-element associated to a user-warning alongside its type (PN2_GetKthUserWarningDataElement())
 *
 * @{
 *
 * @example user_warnings.c
 */

/**
 * @brief User-warnings related to a session in its globality.
 */
typedef enum {
    PN2_NOT_ENOUGH_RAW_SHEETS, // The surface of the sheets is not large enough to cover all the surface requested by the parts.
    PN2_PART_LARGER_THAN_SHEETS, // (data: part_id) Some part is larger than all the provided sheets.
    PN2_PART_LARGER_THAN_NESTING_WINDOWS, // (data: part_id) Some part is larger than all of its nesting windows.
    PN2_SHAPE_LARGER_THAN_NESTING_WINDOWS, // (data: shape_id) Some shape is larger than all of its nesting windows.
    PN2_AUTO_INTERSECTING_SHAPE, // (data: shape_id) Some shape is auto-intersecting.
    PN2_INVALID_SHAPE_WITH_SPECIAL_EDGES // (data: shape_id) Some shape with special edges is invalid.
} PN2_USER_WARNING_CODE;

/**
 * @brief Indicate the type of a given user-warning data-element
 */
typedef enum {
    PN2_PART_TYPE,
    PN2_SHEET_TYPE,
    PN2_SHAPE_TYPE,
    PN2_RESULT_TYPE,
    PN2_MULTIRESULT_TYPE,
    PN2_ORIENTATION_TYPE,
    PN2_POINT_TYPE
} PN2_USER_WARNING_DATA_ELEMENT_TYPE;

/**
 * @brief Defines a DataElement.
 */
typedef union {
    PN2_Part part;
    PN2_Sheet sheet;
    PN2_Shape shape;
    PN2_Result result;
    PN2_MultiResult multi_result;
    PN2_Orientation orientation;
    PN2_Point point;
} PN2_DataElement;


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /**
     * @brief Generates user warnings for `PN2_Nest` or `PN2_MultiNest` inputs.
     *
     * WARNING: A call to this function removes all previously generated warnings in the session.
     *
     * @param session The session owning the sheet and the parts.
     * @param sheets The sheets where parts will be nested on.
     * @param nb_sheets The number of sheets.
     * @param sheet_quantities Quantity available for each sheet.
     * @param parts The parts to be nested.
     * @param nb_parts The number of parts.
     * @param nb_warnings [OUT] the number of generated warnings by `PN2_GenerateNestWarnings`.
     * @return if there was an error while generating user-warnings.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GenerateNestWarnings(PN2_Session session,
                                                              const PN2_Sheet* sheets,
                                                              int nb_sheets,
                                                              const int * sheet_quantities,
                                                              const PN2_Part* parts,
                                                              int nb_parts,
                                                              int* nb_warnings);


    /**
     * @brief Returns the k-th user-warning code and number of associated data-elements.
     *
     * @param session The session where the generation of warning has been generated.
     * @param warning_index The index of the desired warning.
     * @param user_warning_code [OUT] the k-th user warning code
     * @param nb_data_elements [OUT] the number of data-elements associated to the k-th user warning code
     * @return if there was an error while obtaining the k-th user warning code.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetKthUserWarning(PN2_Session session,
                                                           int warning_index,
                                                           PN2_USER_WARNING_CODE* user_warning_code,
                                                           int* nb_data_elements);


    /**
     * @brief Returns the k-th user-warning data element, for a given user warning index.
     *
     * @param session The session where the generation of warning has been generated.
     * @param warning_index The index of the desired warning.
     * @param element_index The index of the desired warning data-element.
     * @param user_warning_data_element [OUT] the k-th user-warning data-element
     * @param user_warning_data_element_type [OUT] the k-th user-warning data-element type
     * @return if there was an error while obtaining the k-th user warning code.
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_GetKthUserWarningDataElement(PN2_Session session,
                                                                      int warning_index,
                                                                      int element_index,
                                                                      PN2_DataElement* user_warning_data_element,
                                                                      PN2_USER_WARNING_DATA_ELEMENT_TYPE* user_warning_data_element_type);

/// @}
    
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif // POWERNEST_USER_WARNINGS_H_
