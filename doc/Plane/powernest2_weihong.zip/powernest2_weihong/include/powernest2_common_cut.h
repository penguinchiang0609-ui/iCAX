/**
 * @file
 * @author Alma
 * @brief API enabling and controlling PowerNest2 common cut capabilities
 */

#ifndef POWERNEST2_COMMON_CUT_H_
#define POWERNEST2_COMMON_CUT_H_

#include "powernest2.h"


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

    /*************************************************************

                     GLOBAL COMMON CUT PROPERTIES

    *************************************************************/

    /**
     * @defgroup CommonCut Common-Line Cutting
     * @brief Place parts at a kerf distance from each other on straight edges to reduce
     * the cutting length
     *
     * To control the optimization objective between common-line cutting and material
     * saving, the two main cost functions can be found in powernest2_objective.h
     *
     * @see PN2_SetMaterialUnitCost()
     * @see PN2_SetCuttingUnitCost()
     * @{
     */

    /**
     * @brief Set the common cut distance
     * 
     * `common_cut_distance` is usually the kerf diameter of the cutting tool. To allow
     * cutting two parts edges next to each other in a single pass, the protection zone
     * is ignored.
     *
     * `min_inter_part_cutting_distance` is used in cases where parts are in common cut,
     * for close edges which are not in common-cut themselves. In this case, it is
     * necessary to make sure the cut is feasible according to the common cut constraint
     * settings, see below. This value is usually smaller than the protection offset.
     *
     * @param session current session 
     * @param common_cut_distance the common cut distance between two parts (kerf)
     * @param min_inter_part_cutting_distance the minimum distance
     *        between non-common-cut edges belonging to parts in common-cut
     *
     * @return error code, 0 if there was no error
     *
     * @warning The two conditions shall be met:
     * - `common_cut_distance > 1e-3`
     * - `min_inter_part_cutting_distance > 1.0001 * common_cut_distance`
     *
     * @see PN2_ShapeSetCommonCutType() to activate common cut on shapes
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_SetCommonCutDistance(PN2_Session session, double common_cut_distance, double min_inter_part_cutting_distance);


    /*************************************************************

                   PER-SHAPE COMMON CUT PROPERTIES

    *************************************************************/

    /**
     * @brief Defines the kind of common cut allowed for a PN2_Shape
     */
    typedef enum
    {
        PN2_NoCommonCut,            ///< No common cut
        PN2_SameShapeCommonCut,     ///< Common cut only between identical shapes
        PN2_AnyShapeCommonCut       ///< Common cut allowed with any shape
    } PN2_CommonCutType;
    
    /**
     * @brief Allow a shape to be nested in common cut.
     *
     * If PN2_AnyShapeCommonCut is used, this shape will be allowed to
     * be nested in common-cut with any other shape also having
     * PN2_AnyShapeCommonCut.
     *
     * @param session the current session
     * @param shape the shape to which the common cut type is set
     * @param type the kind of common cut allowed for this shape
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetCommonCutType(PN2_Session session, PN2_Shape shape, PN2_CommonCutType type);


    /**
     * @brief Set a "matching" constraint for edges in common-cut
     *
     * For cutting quality reasons, it is often necessary to force edges in common-cut to
     * be "aligned", i.e edges must have the same length and the orthogonal projection of
     * one edges on the other is coincident with the other edge.
     *
     * @note A small shift tolerance is allowed (in the order of min_inter_part_cutting_distance)
     *
     * @param session the current session
     * @param shape the shape to which the matching constraint must be applied
     * @param perfect_only set to 1 if the perfect matching constraint must be applied on
     *        this shape. Default value is 0
     *
     * @return error code, 0 if there was no error
     *
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetCommonCutMatching(PN2_Session session, PN2_Shape shape, PN2_Bool perfect_only);


    /**
     * @brief Set a minimum angle constraint for adjacent edges of a common-cut 
     *
     * When two edges are in common-cut, adjacent edges must diverge quickly enough to
     * avoid cutting deviation. This function allows to set this minimum angle.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param angle in degrees, the minimum angle for adjacent edges of a common cut. Must be > 0
     *
     * @return error code, 0 if there was no error
     *
     * @see PN2_ShapeSetMaximumRadiusForCommonCut() for the arc counterpart
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMinimumAngleForCommonCut(PN2_Session session, PN2_Shape shape, double angle);
    

    /**
     * @brief Set a maximum radius for adjacent edges of a common-cut
     *
     * This is the arc counterpart of PN2_ShapeSetMinimumAngleForCommonCut()
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param radius the maximum radius for adjacent edges of a common cut. Must be > 0
     *
     * @return error code, 0 if there was no error
     *
     * @note arcs are detected when a "regular" polygonization is used
     * @see PN2_ShapeSetMinimumAngleForCommonCut() for the segment counterpart
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMaximumRadiusForCommonCut(PN2_Session session, PN2_Shape shape, double radius);

    
    /**
     * @brief Set a minimum area constraint for new holes induced by common-cut
     *
     * When more than one pair of edges are in common-cut, a hole is
     * created (from a cutting point of view). To be cuttable, this
     * hole must be wide enough to allow proper lead-in/lead-out. This
     * constraint is characterized by a minimum area that must meet
     * such a hole.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param area the minimum area for all holes induced by common-cut. Must be >= 0.
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMinimumHoleAreaForCommonCut(PN2_Session session, PN2_Shape shape, double area);

    /**
     * @brief Set a minimum common-cut length constraint
     *
     * Too short common cut might be irrelevant and counter-productive,
     * a minimal common-cut constraint is used to avoid such case.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param min_common_cut_length the minimal common-cut length to require.
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMinimumCommonCutLength(PN2_Session session, PN2_Shape shape, double min_common_cut_length);


    /**
     * @brief Set the maximum number of parts allowed to be placed together in common cut
     *
     * For different reasons (heating, bumping parts, cutting
     * quality, ...), it is often necessary to avoid large groups of
     * parts in common cut.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param max_number the maximum number of parts nested together in common-cut
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMaxNbPartsInCommonCut(PN2_Session session, PN2_Shape shape, int max_number);


    /**
     * @brief Set the maximum dimension of a cluster of parts placed 
     *
     * Similar to PN2_ShapeSetMaxNbPartsInCommonCut(), it is used for
     * different reasons: heating, bumping parts, cutting quality, ...
     * For those reasons, it is often necessary to avoid large
     * groups of parts in common cut. This function restricts the
     * max(length, height) of the whole cluster to be lower than
     * max_dimension instead of the number of parts in it.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param max_dimension the length of the square so that the whole
     *        cluster of common cut parts fits in it, -1 to set no
     *        limit (default)
     *
     * @return error code, 0 if there was no error
     *
     * @see PN2_ShapeSetMaxNbPartsInCommonCut() for a limit on the
     *      number of parts instead of a limit on the dimension of the
     *      cluster
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetMaxCommonCutClusterDimension(PN2_Session session, PN2_Shape shape, double max_dimension);
    

    /**
     * @brief Allow only a single common cut per pair of parts
     *
     * Depending on the cuttting technology, it is sometimes necessary
     * to limit as much as possible the number of lead-ins, like in
     * oxycutting for instance. Using this function allow only common
     * cut which doesn't introduce new lead-in/lead-out. In pratice
     * this forces common cut between pair of parts, and without
     * introducing holes.
     *
     * This way, a single 8-shaped cutting sequence can be used to cut
     * the pair of parts without extra lead-in.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param single_cc_only set to 1 to enable this mode
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetSingleCommonCut(PN2_Session session, PN2_Shape shape, PN2_Bool single_cc_only);


    /**
     * @brief Defines constraints on the type of common-cut clusters generated by PowerNest2
     */
    typedef enum
    {
        PN2_DirectionWithoutCommonCut,  ///< No common-cut in the given direction, see usage
        PN2_SimpleLineCommonCut,        ///< Common-cut in one direction only
        PN2_DoubleLineCommonCut,        ///< common-cut in one direction, allowing two rows or column in the other direction
        PN2_MatrixCommonCut             ///< No constraints on the common cut
    } PN2_CommonCutClusterConstraint;

    /**
     * @brief Set structural constraints on shapes to be put in common-cuts
     *
     * The main use case is to avoid parts with none of its edges in contact with the
     * skeleton. The constraint applies to the position of parts, not to the direction of
     * the segments in common cuts.
     *
     * @param session the current session
     * @param shape the shape to which this constraint must be applied
     * @param vertical_common_cut the constraint on the vertical
     *        direction (for instance PN2_DoubleLineCommonCut means at
     *        most a two-columns pattern in common cut)
     * @param horizontal_common_cut the same thing in the horizontal direction
     *
     * @note Using PN2_MatrixCommonCut obviously applies in both
     * directions. PN2_DirectionWithoutCommonCut must not be used on
     * both directions.
     *
     * @warning This parameter is ignored in case PN2_AnyShapeCommonCut is used
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_ShapeSetClusterConstraintsForCommonCut(PN2_Session session, PN2_Shape shape,
                                                                                PN2_CommonCutClusterConstraint vertical_common_cut,
                                                                                PN2_CommonCutClusterConstraint horizontal_common_cut);

    /**
     * @brief Determine if a part has at least one of its edge sharing a common-cut with
     *        another part.
     *
     * @param session the current session
     * @param result the nesting result where the part is nested
     * @param part the part for which we want to know if it is nested in common-cut
     * @param[out] in_common_cut is set to 1 if the part is in common_cut in this nesting. Otherwise it is set to 0.
     *
     * @return error code, 0 if there was no error
     */
    PN2_EXPORTS PN2_ErrorCode PN2API PN2_IsPartInCommonCut(PN2_Session session, PN2_Result result, PN2_Part part, PN2_Bool * in_common_cut);


    
    /// @}
    

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
